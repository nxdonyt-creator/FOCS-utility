#requires -Version 5.1
# Read-only observations. Mutation is confined to the separately reviewed control catalog.
function Get-VideoRegistryCatalog {
 $mm='SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'
 $profile='SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
 $kernel='SYSTEM\CurrentControlSet\Control\Session Manager\Kernel'
 $docs='https://learn.microsoft.com/en-us/windows/win32/procthread/multimedia-class-scheduler-service'
 @(
  [pscustomobject]@{Name='SystemResponsiveness';Path=$profile;Kind='DWord';Decision='Optional comparison';Note='The separate MMCSS control compares 10% and 20% CPU reservation for lower-priority work. Effect depends on MMCSS participation and workload. Use Undo for your exact original.';Source=$docs}
  [pscustomobject]@{Name='GPU Priority';Path=($profile+'\Tasks\Games');Kind='DWord';Decision='Leave unchanged';Note='Microsoft documents this task property as unused. Setting it to 8 does not establish a GPU scheduling improvement.';Source=$docs}
  [pscustomobject]@{Name='SFIO Priority';Path=($profile+'\Tasks\Games');Kind='String';Decision='Leave unchanged';Note='Microsoft documents this property as unused.';Source=$docs}
  [pscustomobject]@{Name='Scheduling Category';Path=($profile+'\Tasks\Games');Kind='String';Decision='Leave unchanged';Note='A task profile affects threads registered with MMCSS. It does not prove that every game thread uses this profile.';Source=$docs}
  [pscustomobject]@{Name='Clock Rate';Path=($profile+'\Tasks\Games');Kind='DWord';Decision='Leave unchanged';Note='This is a scheduling hint; its historical guaranteed-rate behavior was removed starting with Windows 7.';Source=$docs}
  [pscustomobject]@{Name='DisablePagingExecutive';Path=$mm;Kind='DWord';Decision='No gaming preset';Note='The cited tracing guidance concerns older Windows stack walking. It does not establish a Windows 11 gaming benefit.';Source='https://learn.microsoft.com/en-us/windows-hardware/test/wpt/kernel-trace-control-api-reference'}
  [pscustomobject]@{Name='LargeSystemCache';Path=$mm;Kind='DWord';Decision='No gaming preset';Note='No current Windows 11 gaming benefit was established in this review. Preserve your existing configuration.';Source='https://www.youtube.com/watch?v=U-U4TLAuYbU'}
  [pscustomobject]@{Name='SecondLevelDataCache';Path=$mm;Kind='DWord';Decision='No gaming preset';Note='Do not infer an optimal cache override from the CPU model or the video. A missing value is not an error.';Source='https://www.youtube.com/watch?v=U-U4TLAuYbU'}
  [pscustomobject]@{Name='ThirdLevelDataCache';Path=$mm;Kind='DWord';Decision='No gaming preset';Note='The review did not establish that this value controls modern L3 scheduling. Neither create nor delete it automatically.';Source='https://www.youtube.com/watch?v=U-U4TLAuYbU'}
  [pscustomobject]@{Name='SvcHostSplitThresholdInKB';Path='SYSTEM\CurrentControlSet\Control';Kind='DWord';Decision='Preserve service isolation';Note='Service separation has reliability and isolation benefits. A lower process count alone is not a latency measurement.';Source='https://learn.microsoft.com/en-us/windows/application-management/svchost-service-refactoring'}
  [pscustomobject]@{Name='NetworkThrottlingIndex';Path=$profile;Kind='DWord';Decision='No gaming preset';Note='The review did not establish a universal game-ping benefit. Use Network measurements to investigate a specific symptom.';Source='https://www.youtube.com/watch?v=U-U4TLAuYbU'}
  [pscustomobject]@{Name='ThreadDpcEnable';Path=$kernel;Kind='DWord';Decision='Keep driver behavior';Note='Zero converts threaded DPCs to ordinary DPCs. Ordinary DPC execution can delay threads and increase latency.';Source='https://learn.microsoft.com/en-us/windows-hardware/drivers/kernel/introduction-to-threaded-dpcs'}
 )
}
function Format-VideoRegistryValue($Value) {
 if(-not $Value.Exists){return 'Not explicitly set (Windows behavior depends on build)'}
 if($Value.Kind -eq 'DWord'){
  $number=[BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$Value.Data),0)
  return ('DWord: {0} (0x{0:X8})' -f $number)
 }
 # Avoid dumping arbitrary or very large registry content in the UI.
 if($Value.Kind -eq 'String'){
  $text=([string]$Value.Data -replace '[\x00-\x1F]',' ')
  if($text.Length -gt 120){$text=$text.Substring(0,120)+'...'}
  return ('String: '+$text)
 }
 return ('Type: '+$Value.Kind+' (content not displayed)')
}
function Get-VideoRegistryReview {
 foreach($item in Get-VideoRegistryCatalog){
  $spec=[pscustomobject]@{Hive='HKLM';Path=$item.Path;Name=$item.Name}
  $current='Unavailable';$status='Read';$note=$item.Note
  try{
   $value=Read-ControlValue $spec
   $current=Format-VideoRegistryValue $value
   if(-not $value.Exists){$status='Not explicitly set'}
   elseif($value.Kind -ne $item.Kind){$status='Unexpected type';$note+=' Expected '+$item.Kind+'; inspect before changing anything.'}
  }catch{$status='Read failed';$note+=' Windows could not read this value. No default was inferred.'}
  [pscustomobject]@{Name=$item.Name;Path=('HKLM\'+$item.Path);Current=$current;Status=$status;Decision=$item.Decision;Note=$note;Source=$item.Source}
 }
}
