@echo off
setlocal EnableExtensions DisableDelayedExpansion
if not exist "%~dp0KKxtti debloat utility.exe" (
 echo KKxtti debloat utility.exe is missing. Extract the entire package first.
 echo Read START HERE.txt. Do not disable antivirus to run the utility.
 pause
 exit /b 1
)
start "" "%~dp0KKxtti debloat utility.exe"
endlocal
