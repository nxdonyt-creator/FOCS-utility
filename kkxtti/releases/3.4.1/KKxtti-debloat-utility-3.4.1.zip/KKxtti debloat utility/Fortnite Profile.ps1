#requires -Version 5.1
function Get-FortnitePotatoCatalog {
 foreach($key in @('ViewDistance','AntiAliasing','Shadow','GlobalIllumination','Reflection','PostProcess','Texture','Effects','Foliage','Shading','Landscape')){[pscustomobject]@{Id=('quality-'+$key);Section='ScalabilityGroups';Key=('sg.'+$key+'Quality');Type='Quality';Target='0'}}
 [pscustomobject]@{Id='render-scale';Section='ScalabilityGroups';Key='sg.ResolutionQuality';Type='Scale';Target='50'}
 foreach($key in @('bMotionBlur','bUseNanite','bUseDynamicResolution')){[pscustomobject]@{Id=$key;Section='/Script/FortniteGame.FortGameUserSettings';Key=$key;Type='Boolean';Target='False'}}
}
function Assert-FortniteValue($Spec,[string]$Value) {
 $n=0.0
 if($Spec.Type -eq 'Boolean'){if($Value -cnotin @('True','False')){throw 'Invalid Fortnite boolean.'};return}
 if(-not [double]::TryParse($Value,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$n) -or [double]::IsNaN($n) -or [double]::IsInfinity($n)){throw 'Invalid Fortnite numeric value.'}
 if($Spec.Type -eq 'Quality' -and ($n -lt 0 -or $n -gt 4 -or $n -ne [math]::Floor($n))){throw 'Unsupported Fortnite quality value.'}
 # 0 is Unreal's default-scale sentinel; retain it exactly when undoing.
 if($Spec.Type -eq 'Scale' -and ($n -lt 0 -or $n -gt 100)){throw 'Unsupported Fortnite resolution scale.'}
}
function Get-FortnitePotatoPreview([int]$Scale=50) {
 if($Scale -notin @(50,67,75,100)){throw 'Choose 50, 67, 75 or 100 percent.'}
 $config=Get-ExactGameConfig 'fortnite';$doc=Read-GameDocument $config.Path
 foreach($spec in Get-FortnitePotatoCatalog){try{$current=(Find-GameField $doc.Text $spec).Value;Assert-FortniteValue $spec $current;[pscustomobject]@{Id=$spec.Id;Name=$spec.Key;Current=$current;Target=$(if($spec.Type -eq 'Scale'){[string]$Scale}else{$spec.Target});Available=$true}}catch{[pscustomobject]@{Id=$spec.Id;Name=$spec.Key;Current='Unavailable';Target=$spec.Target;Available=$false}}}
}
function Set-FortnitePotatoProfile([int]$Scale=50) {
 if($Scale -notin @(50,67,75,100)){throw 'Choose 50, 67, 75 or 100 percent.'}
 $config=Get-ExactGameConfig 'fortnite';Assert-GameClosed 'fortnite';$doc=Read-GameDocument $config.Path;$rows=@();$missing=@()
 foreach($spec in Get-FortnitePotatoCatalog){
  try{$match=Find-GameField $doc.Text $spec}catch{$missing+=$spec.Key;continue}
  Assert-FortniteValue $spec $match.Value;$after=if($spec.Type -eq 'Scale'){[string]$Scale}else{$spec.Target}
  if($match.Value -cne $after){$rows+=[pscustomobject]@{Id=$spec.Id;Before=$match.Value;After=$after}}
 }
 if($missing -contains 'sg.ResolutionQuality'){throw 'This configuration does not expose a unique render-scale key. Set graphics in Fortnite, close it and refresh.'}
 if(-not $rows.Count){return [pscustomobject]@{Status='Already configured';Id='';Count=0}}
 $description=($rows|ForEach-Object {$_.Id+': '+$_.Before+' -> '+$_.After}) -join [Environment]::NewLine
 if(-not(Confirm-Action ('Apply Fortnite in-game low graphics graphics at '+$Scale+'% 3D resolution? Low quality sacrifices image detail, especially at 50%. Display resolution, sensitivity, controls and FPS cap are preserved.'+[Environment]::NewLine+$description+[Environment]::NewLine+'Only existing recognized keys are edited. Unavailable: '+($missing -join ', ')+'. Use Performance rendering and Reflex in Fortnite separately; its renderer is not forced. Reset restores the changed keys to their saved values.') 'APPLY')){return}
 Assert-GameClosed 'fortnite'
 if((Get-BytesHash ([IO.File]::ReadAllBytes($config.Path))) -cne (Get-BytesHash $doc.Bytes)){throw 'Fortnite configuration changed during review.'}
 $saved=New-ControlJournal 'fortnite' $rows;$saved.Journal|Add-Member NoteProperty GameId 'fortnite';$saved.Journal|Add-Member NoteProperty Scale $Scale;Save-ControlJournal $saved.Path $saved.Journal
 [IO.File]::WriteAllBytes((Join-Path (Split-Path -Parent $saved.Path) 'before.ini'),$doc.Bytes)
 $text=$doc.Text;$catalog=@(Get-FortnitePotatoCatalog)
 foreach($row in $rows){$spec=@($catalog|Where-Object Id -ceq $row.Id)[0];$match=Find-GameField $text $spec;$text=$text.Remove($match.Start,$match.Length).Insert($match.Start,$row.After)}
 try{Write-GameDocument $config $doc.Bytes (Convert-GameTextBytes $doc $text);$saved.Journal.Status='Applied';Save-ControlJournal $saved.Path $saved.Journal}catch{$saved.Journal.Status='Recovery needed';Save-ControlJournal $saved.Path $saved.Journal;throw}
 [pscustomobject]@{Status='Applied';Id=$saved.Journal.Id;Count=$rows.Count}
}
function Undo-FortnitePotatoProfile([string]$Id) {
 $saved=Read-ProfileJournal $Id 'fortnite';$j=$saved.Journal
 if($j.GameId -cne 'fortnite' -or $j.Scale -notin @(50,67,75,100)){throw 'Invalid Fortnite preset record.'}
 $catalog=@(Get-FortnitePotatoCatalog);$seen=@{}
 foreach($row in $j.Rows){$spec=@($catalog|Where-Object Id -ceq $row.Id);if($spec.Count -ne 1 -or $seen.ContainsKey([string]$row.Id)){throw 'Invalid/duplicate Fortnite preset key.'};$seen[[string]$row.Id]=$true;Assert-FortniteValue $spec[0] $row.Before;Assert-FortniteValue $spec[0] $row.After;$target=if($spec[0].Type -eq 'Scale'){[string]$j.Scale}else{$spec[0].Target};if($row.After -cne $target){throw 'Saved Fortnite target is not an approved preset.'}}
 Assert-GameClosed 'fortnite'
 if(-not(Confirm-Action 'Reset the in-game low graphics profile to the graphics values saved before applying it? Close Fortnite first. Sensitivity and other unrelated preferences remain as they are; newer conflicting graphics changes stop Reset.' 'RESET')){return}
 $config=Get-ExactGameConfig 'fortnite';$doc=Read-GameDocument $config.Path;$text=$doc.Text
 foreach($row in $j.Rows){$spec=@($catalog|Where-Object Id -ceq $row.Id)[0];$match=Find-GameField $text $spec;if($match.Value -ceq $row.Before){continue};if($match.Value -cne $row.After){throw 'Newer Fortnite graphics settings conflict with Reset. Nothing was overwritten.'};$text=$text.Remove($match.Start,$match.Length).Insert($match.Start,$row.Before)}
 $j.Status='Undoing';Save-ControlJournal $saved.Path $j
 try{if($text -cne $doc.Text){Write-GameDocument $config $doc.Bytes (Convert-GameTextBytes $doc $text)};$j.Status='Undone';Save-ControlJournal $saved.Path $j}catch{$j.Status='Recovery needed';Save-ControlJournal $saved.Path $j;throw}
 [pscustomobject]@{Status='Undone';Id=$Id}
}
