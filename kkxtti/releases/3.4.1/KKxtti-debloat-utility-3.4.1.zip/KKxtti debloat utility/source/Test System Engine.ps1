#requires -Version 5.1
param([string]$Root=(Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference='Stop'
. (Join-Path $Root 'Performance Utility.ps1') -LibraryOnly
. (Join-Path $Root 'Control Engine.ps1');. (Join-Path $Root 'System Engine.ps1')
$script:ControlRoot=Join-Path $PSScriptRoot ('system-fixtures-'+[guid]::NewGuid().ToString('N'))
$script:checks=0;$script:admin=$true;$script:confirm=$true;$script:writes=0
function Check($v,$m){if(-not $v){throw ('FAIL: '+$m)};$script:checks++;Write-Host ('PASS: '+$m)}
function Refuses($b,$p){$caught=$false;try{& $b | Out-Null}catch{$caught=$true;Check ($_.Exception.Message -match $p) ('refused '+$p)};Check $caught 'refusal surfaced'}
function Test-Admin {$script:admin}
function Confirm-Action($Message,$Word){$script:confirm}
$script:state=@{hibernate=[pscustomobject]@{Enabled=$true;Type=2;SizePercent=75};'reserved-storage'=[pscustomobject]@{State='Enabled'};'recall-feature'=[pscustomobject]@{State='Enabled'};'maps-service'=[pscustomobject]@{Start='Automatic'};'media-service'=[pscustomobject]@{Start='Disabled'};'fax-service'=[pscustomobject]@{Start='Manual'}}
function Read-SystemValue($Id){$script:state[$Id]}
function Write-SystemValue($Id,$Value){$script:writes++;$script:state[$Id]=$Value}
$script:normalWrite=${function:Write-SystemValue}
$script:admin=$false;Refuses {Set-SystemControl 'hibernate'} 'administrator';Check ($script:writes -eq 0) 'no write without admin'
$script:admin=$true;$script:confirm=$false;$null=Set-SystemControl 'hibernate';Check ($script:writes -eq 0) 'cancel stops system mutation'
$script:confirm=$true;Refuses {Set-SystemControl 'arbitrary-service'} 'Unknown';Check ($script:writes -eq 0) 'unknown operation cannot reach mutator'
foreach($id in @('hibernate','reserved-storage','recall-feature','maps-service','media-service')){
 $before=Read-SystemValue $id;$r=Set-SystemControl $id;Check ($r.Status -eq 'Applied') ($id+' applied with journal')
 $null=Undo-SystemControl $r.Id;Check (Test-SystemEqual (Read-SystemValue $id) $before) ($id+' exact original restored')
 Refuses {Undo-SystemControl $r.Id} 'another state'
}
Check ($script:state.hibernate.Enabled -and $script:state.hibernate.SizePercent -eq 75) 'custom hibernation size retained by undo'
$r=Set-SystemControl 'maps-service';$script:state['maps-service']=[pscustomobject]@{Start='Disabled'};$n=$script:writes
Refuses {Undo-SystemControl $r.Id} 'conflicts';Check ($script:writes -eq $n) 'external service change not overwritten'
$script:state['maps-service']=[pscustomobject]@{Start='Automatic'};$script:fail=$true
function Write-SystemValue($Id,$Value){& $script:normalWrite $Id $Value;if($script:fail){$script:fail=$false;throw 'Injected partial system write'}}
Refuses {Set-SystemControl 'maps-service'} 'Rolled back'
Set-Item Function:Write-SystemValue $script:normalWrite
Check ($script:state['maps-service'].Start -eq 'Automatic') 'partial system write rolled back'
$n=$script:writes;$r=Set-SystemControl 'fax-service';Check ($r.Status -eq 'Already configured' -and $script:writes -eq $n) 'already-manual service leaves no mutation'
$saved=New-ControlJournal 'system' @([pscustomobject]@{Id='reserved-storage';Before=[pscustomobject]@{State='Enabled'};After=[pscustomobject]@{State='Disabled'}})
$script:state['reserved-storage']=[pscustomobject]@{State='Disabled'};$null=Undo-SystemControl $saved.Journal.Id
Check ($script:state['reserved-storage'].State -eq 'Enabled') 'prepared system operation can be recovered'
$script:original='11111111-1111-1111-1111-111111111111';$script:active=$script:original;$script:plans=@{};$script:plans[$script:original]='Original user plan';$script:nativeCalls=@()
function Get-PowerGuid {$script:active}
function Invoke-Native($Name,$Arguments){
 Check ($Name -eq 'powercfg.exe') 'only powercfg used for plan operation';$script:nativeCalls+=($Arguments -join ' ')
 switch($Arguments[0]){
  '/duplicatescheme'{$script:plans[$Arguments[2]]='Template';$Arguments[2]}
  '/changename'{$script:plans[$Arguments[1]]=$Arguments[2]}
  '/query'{if(-not $script:plans.ContainsKey($Arguments[1])){throw 'Plan absent'};$script:plans[$Arguments[1]]}
  '/list'{$script:plans.Keys -join "`n"}
  '/setactive'{if(-not $script:plans.ContainsKey($Arguments[1])){throw 'Plan absent'};$script:active=$Arguments[1]}
  '/delete'{$script:plans.Remove($Arguments[1])}
  default{throw 'Unexpected native operation'}
 }
}
$r=Set-UltimateTestPlan;Check ($r.Status -eq 'Applied' -and $script:active -ne $script:original) 'separate test plan created and activated'
$created=$script:active;$null=Undo-UltimateTestPlan $r.Id
Check ($script:active -eq $script:original -and -not $script:plans.ContainsKey($created) -and $script:plans.ContainsKey($script:original)) 'undo keeps original and deletes only created plan'
$r=Set-UltimateTestPlan;$created=$script:active;$script:active=$script:original;$script:plans.Remove($created)
$pending=Read-UltimateJournal $r.Id;$pending.Journal.Status='Undoing';Save-ControlJournal $pending.Path $pending.Journal
$n=@($script:nativeCalls | Where-Object {$_ -match '^/(setactive|delete) '}).Count
$null=Undo-UltimateTestPlan $r.Id
Check (@($script:nativeCalls | Where-Object {$_ -match '^/(setactive|delete) '}).Count -eq $n) 'recovery after completed deletion does not mutate plans'
Check ((Get-Content -LiteralPath $pending.Path -Raw | ConvertFrom-Json).Status -eq 'Undone') 'interrupted final journal write can be finalized'
$r=Set-UltimateTestPlan;$created=$script:active;$script:plans[$created]='Edited externally'
Refuses {Undo-UltimateTestPlan $r.Id} 'edited externally';Check ($script:active -eq $created) 'edited test plan left untouched'
$script:plans[$created]='KKxtti Ultimate Performance test';$script:active='22222222-2222-2222-2222-222222222222'
Refuses {Undo-UltimateTestPlan $r.Id} 'Another plan';Check ($script:active -like '22222222*') 'newer external active plan selection preserved'
$script:decryptCalls=0;$script:volumeStatus='FullyEncrypted'
function Get-BitLockerVolume {param($MountPoint,$ErrorAction);[pscustomobject]@{VolumeStatus=$script:volumeStatus;EncryptionPercentage=100}}
function Disable-BitLocker {param($MountPoint,$ErrorAction);$script:decryptCalls++;$script:volumeStatus='DecryptionInProgress'}
$script:confirm=$false;$null=Start-SystemDriveDecryption;Check ($script:decryptCalls -eq 0) 'decryption cancellation makes no request'
$script:confirm=$true;$r=Start-SystemDriveDecryption;Check ($script:decryptCalls -eq 1 -and $r.Status -like 'Decryption requested*') 'decryption reported as requested, not completed'
Refuses {Start-SystemDriveDecryption} 'already converting';Check ($script:decryptCalls -eq 1) 'converting drive not touched again'
$script:volumeStatus='FullyDecrypted';$r=Start-SystemDriveDecryption;Check ($r.Status -eq 'Already decrypted' -and $script:decryptCalls -eq 1) 'already-decrypted drive leaves no request'
Write-Host ('TOTAL: '+$script:checks+' system checks. All OS mutators mocked.')
