#requires -Version 5.1
param([string]$Executable=(Join-Path (Split-Path -Parent $PSScriptRoot) 'KKxtti debloat utility.exe'))
$ErrorActionPreference='Stop'
Add-Type -AssemblyName PresentationFramework
[void][Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $Executable).Path)
$checks=0
function Check($Value,$Message){if(-not $Value){throw ('FAIL: '+$Message)};$script:checks++;Write-Host ('PASS: '+$Message)}
Check ([KKxtti.PeripheralIdentity]::FromRawPath('\\?\HID#vid_046d&pid_c547#fixture#{00000000-0000-0000-0000-000000000000}') -ceq 'HID\VID_046D&PID_C547\FIXTURE') 'raw mouse path matches the PnP instance identity'
Check ([KKxtti.PeripheralIdentity]::FromRawPath('HID\fixture') -ceq 'HID\FIXTURE') 'already normalized device path is retained'
Check ([KKxtti.PeripheralIdentity]::FromRawPath('') -ceq '') 'empty raw identity is not invented'
Check ([KKxtti.PeripheralIdentity]::FromRawPath($null) -ceq '') 'missing raw identity is not invented'
$gate=[KKxtti.Dashboard].GetMethod('PreviewAllows',[Reflection.BindingFlags]'Static,NonPublic')
Check ([bool]$gate.Invoke($null,@('Get-GamingPowerPreview'))) 'read-only preview allows power inspection'
Check ([bool]$gate.Invoke($null,@('Get-NvidiaState -GameId $ProfileGame'))) 'read-only preview allows NVIDIA inspection'
Check (-not [bool]$gate.Invoke($null,@('Set-GamingPowerPlan'))) 'read-only preview blocks power application'
Check (-not [bool]$gate.Invoke($null,@('Reset-KKxttiSavedSettings'))) 'read-only preview blocks Reset'
Check (-not [bool]$gate.Invoke($null,@('New-ReviewedRestorePoint'))) 'read-only preview blocks restore-point creation'
Check (-not [bool]$gate.Invoke($null,@('Get-GamingPowerPreview; Set-GamingPowerPlan'))) 'read-only preview blocks a chained mutation'
Write-Host ('TOTAL: '+$checks+' native identity/preview checks. No window or input capture was started.')
