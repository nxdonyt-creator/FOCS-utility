$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
. (Join-Path $root 'Control Engine.ps1');. (Join-Path $root 'Network Engine.ps1');. (Join-Path $root 'Game Engine.ps1');. (Join-Path $root 'Recovery Engine.ps1')
$script:ControlRoot=Join-Path $PSScriptRoot ('recovery-tests-'+[guid]::NewGuid().ToString('N'))
$script:checks=0;$script:registry=@{};$script:writes=0
function Check($v,$n){if(-not $v){throw ('FAIL: '+$n)};$script:checks++;Write-Host ('PASS: '+$n)}
function Refuses($block,$pattern){$caught=$false;try{& $block | Out-Null}catch{$caught=$true;Check ($_.Exception.Message -match $pattern) ('rejected '+$pattern)};Check $caught 'refused'}
function Read-ControlValue($Spec){$script:registry[$Spec.Path+'|'+$Spec.Name]}
function Write-ControlValue($Spec,$Value){$script:writes++;$script:registry[$Spec.Path+'|'+$Spec.Name]=$Value}
$before=[pscustomobject]@{Exists=$false;Kind='DWord';Data=$null};$after=[pscustomobject]@{Exists=$true;Kind='DWord';Data=1}
$rows=@([pscustomobject]@{Id='game-mode';Index=0;Before=$before;After=$after},[pscustomobject]@{Id='game-mode';Index=1;Before=$before;After=$after})
foreach($row in $rows){$spec=Get-ControlSpec $row;$script:registry[$spec.Path+'|'+$spec.Name]=$before}
$saved=New-ControlJournal 'settings' $rows
$spec=Get-ControlSpec $rows[0];$script:registry[$spec.Path+'|'+$spec.Name]=$after
$plan=@(Get-RecoveryPlan $saved.Journal.Id);Check ($plan[0].Action -eq 'Restore original' -and $plan[1].Action -eq 'Already original') 'partial transaction classified'
$result=Restore-InterruptedChange $saved.Journal.Id;Check ($result.Status -eq 'Undone' -and $script:writes -eq 1) 'only changed row restored'
Check (-not (Read-ControlValue $spec).Exists) 'missing original value restored'
Refuses {Restore-InterruptedChange $saved.Journal.Id} 'not an interrupted'
$saved=New-ControlJournal 'settings' $rows;$script:registry[$spec.Path+'|'+$spec.Name]=[pscustomobject]@{Exists=$true;Kind='DWord';Data=9};$n=$script:writes
Refuses {Restore-InterruptedChange $saved.Journal.Id} 'outside this transaction'
Check ($script:writes -eq $n) 'conflict prevents entire recovery'
$script:registry[$spec.Path+'|'+$spec.Name]=$before
$result=Restore-InterruptedChange $saved.Journal.Id;Check ($result.Status -eq 'Already original') 'no-op recovery marked complete'
$saved=New-ControlJournal 'settings' $rows;$saved.Journal.Status='Undoing';Save-ControlJournal $saved.Path $saved.Journal
Check (@(Get-RecoveryPlan $saved.Journal.Id).Count -eq 2) 'interrupted undo recognized'
$saved.Journal.Rows=@($rows[0],$rows[0]);Save-ControlJournal $saved.Path $saved.Journal
Refuses {Restore-InterruptedChange $saved.Journal.Id} 'Duplicate'
$saved.Journal.Rows=$rows;$saved.Journal.Computer='A DIFFERENT PC';Save-ControlJournal $saved.Path $saved.Journal
Refuses {Restore-InterruptedChange $saved.Journal.Id} 'not an interrupted'
Refuses {Get-RecoveryPlan '../path'} 'Invalid recovery'
# Game recovery, using an isolated config and exact game-path fixture.
$script:fixture=Join-Path $script:ControlRoot 'GameUserSettings.ini'
function Get-GameConfigs {[pscustomobject]@{Id='fortnite';Name='Fixture';Path=$script:fixture;Game='fortnite'}}
function Assert-GameClosed($Game){}
[IO.File]::WriteAllText($script:fixture,"[/Script/FortniteGame.FortGameUserSettings]`r`nFrameRateLimit=240`r`nMouseSensitivity=0.3`r`n")
$saved=New-ControlJournal 'game' @([pscustomobject]@{Id='fps-cap';Before='0.000000';After='240'});$saved.Journal | Add-Member NoteProperty GameId 'fortnite';Save-ControlJournal $saved.Path $saved.Journal
$result=Restore-InterruptedChange $saved.Journal.Id;Check ($result.Status -eq 'Undone') 'game recovery completes'
Check ([IO.File]::ReadAllText($script:fixture).Contains('FrameRateLimit=0.000000')) 'game original value restored'
Check ([IO.File]::ReadAllText($script:fixture).Contains('MouseSensitivity=0.3')) 'game recovery preserves unrelated preferences'
Write-Host ('Recovery: '+$script:checks+' checks passed. Only mock registry and fixture files used.')
