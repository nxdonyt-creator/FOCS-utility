#requires -Version 5.1
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2
. (Join-Path $PSScriptRoot 'Launcher Core.ps1')
$script:realReceive=${function:Receive-KKxttiArchive}
$script:checks=0;$script:downloads=0;$script:starts=0;$script:unblocked=@()
$script:fixture=Join-Path $PSScriptRoot ('fixtures-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($script:fixture)
function Check($v,$m){if(-not $v){throw ('FAIL: '+$m)};$script:checks++;Write-Host ('PASS: '+$m)}
function Refuses($b,$p){$caught=$false;try{& $b | Out-Null}catch{$caught=$true;Check ($_.Exception.Message -match $p) ('refused '+$p)};Check $caught 'refusal surfaced'}
function Assert-KKxttiWindows {}
function Start-KKxttiInterface($Directory){$script:starts++}
function Unblock-File {param($LiteralPath,$ErrorAction);$script:unblocked+=$LiteralPath}
function Receive-KKxttiArchive($Url,$Path){$script:downloads++;Copy-Item -LiteralPath $script:sourceArchive -Destination $Path}
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$package=Join-Path $script:fixture 'KKxtti debloat utility';[void][IO.Directory]::CreateDirectory($package)
$exe=Join-Path $package 'KKxtti debloat utility.exe';[IO.File]::WriteAllText($exe,'Fake test executable; never run')
$scriptFile=Join-Path $package 'fixture.ps1';[IO.File]::WriteAllText($scriptFile,'# fixture only')
$manifest=Join-Path $package 'SHA256SUMS.txt'
$fixtureHashes=@();$fixtureHashes+=((Get-FileHash $exe).Hash+'  KKxtti debloat utility.exe');$fixtureHashes+=((Get-FileHash $scriptFile).Hash+'  fixture.ps1')
[IO.File]::WriteAllLines($manifest,$fixtureHashes,[Text.UTF8Encoding]::new($false))
$manifestHash=(Get-FileHash $manifest).Hash
$script:sourceArchive=Join-Path $script:fixture 'valid.zip'
$zipFile=[IO.File]::Open($script:sourceArchive,[IO.FileMode]::CreateNew)
$validZip=[IO.Compression.ZipArchive]::new($zipFile,[IO.Compression.ZipArchiveMode]::Create,$false)
try{foreach($fixtureFile in Get-ChildItem -LiteralPath $package -File){$entry=$validZip.CreateEntry('KKxtti debloat utility/'+$fixtureFile.Name);$data=$entry.Open();$input=[IO.File]::OpenRead($fixtureFile.FullName);try{$input.CopyTo($data)}finally{$input.Dispose();$data.Dispose()}}}finally{$validZip.Dispose();$zipFile.Dispose()}
$archiveHash=(Get-FileHash $script:sourceArchive).Hash
$cacheRoot=Join-Path $script:fixture 'releases'
$argsFixture=@{Version='3.1.0';ArchiveUrl='https://raw.githubusercontent.com/example/example/main/fixture.zip';ArchiveSha256=$archiveHash;ManifestSha256=$manifestHash;Root=$cacheRoot}
$destination=Invoke-KKxttiLauncher @argsFixture -NoLaunch
Check ($script:downloads -eq 1 -and $script:starts -eq 0) 'download and verify without launching'
Check ((Get-FileHash (Join-Path $destination 'KKxtti debloat utility.exe')).Hash -ceq (Get-FileHash $exe).Hash) 'extracted executable matches trusted manifest'
Check ($script:unblocked.Count -eq 3 -and @($script:unblocked | Where-Object {-not $_.StartsWith($cacheRoot,[StringComparison]::OrdinalIgnoreCase)}).Count -eq 0) 'unblocking limited to verified fixture release files'
$state=Join-Path $destination 'State';[void][IO.Directory]::CreateDirectory($state);$record=Join-Path $state 'fixture-backup.json';[IO.File]::WriteAllText($record,'Preserved fixture backup')
$again=Invoke-KKxttiLauncher @argsFixture
Check ($again -ceq $destination -and $script:downloads -eq 1 -and $script:starts -eq 1) 'cached release reused without a new download'
Check ($script:unblocked.Count -eq 6 -and $record -notin $script:unblocked) 'cached files reverified and unblocked without touching State'
Check ([IO.File]::ReadAllText($record) -ceq 'Preserved fixture backup') 'saved State remains available across launches'
[IO.File]::WriteAllText((Join-Path $destination 'KKxtti debloat utility.exe'),'tampered')
Refuses {Invoke-KKxttiLauncher @argsFixture} 'missing or modified'
Check ($script:starts -eq 1 -and (Test-Path $record)) 'tampered cache does not launch or delete backups'
Copy-Item -LiteralPath $exe -Destination (Join-Path $destination 'KKxtti debloat utility.exe') -Force
$extra=Join-Path $destination 'unexpected.dll';[IO.File]::WriteAllText($extra,'fixture')
Refuses {Invoke-KKxttiLauncher @argsFixture} 'Unexpected file'
Check ($script:starts -eq 1) 'unexpected cached code prevents launch'
$badRoot=Join-Path $script:fixture 'wrong-hash-cache';$badArguments=@{};foreach($key in $argsFixture.Keys){$badArguments[$key]=$argsFixture[$key]};$badArguments.Root=$badRoot;$badArguments.ArchiveSha256='A'*64
Refuses {Invoke-KKxttiLauncher @badArguments} 'ZIP hash mismatch'
Check ($script:starts -eq 1) 'bad ZIP never reaches interface'
Refuses {Invoke-KKxttiLauncher -Version '../bad' -ArchiveSha256 $archiveHash -ManifestSha256 $manifestHash -Root $cacheRoot} 'Invalid pinned'
Refuses {Get-KKxttiManifest $package ('B'*64)} 'manifest does not match'
Refuses {Assert-KKxttiDirectory (Join-Path $script:fixture 'outside') $cacheRoot} 'escaped'
foreach($relative in @('../bad','..\bad','C:\bad','/bad','file:stream','folder//file','folder/./file','NUL.txt','CON','trailing.','trailing ')){Refuses {Assert-KKxttiRelativePath $relative} 'Invalid package path'}
Assert-KKxttiRelativePath 'source/Test script.ps1';Check $true 'ordinary names with spaces allowed'
function New-FixtureZip($Names,$Link=$false,$Large=$false){
 $path=Join-Path $script:fixture ([guid]::NewGuid().ToString('N')+'.zip');$stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew);$z=New-Object IO.Compression.ZipArchive($stream,[IO.Compression.ZipArchiveMode]::Create,$false)
 try{foreach($name in $Names){$entry=$z.CreateEntry($name);if($Link){$entry.ExternalAttributes=0xA0000000};$data=$entry.Open();try{if($Large){$buffer=New-Object byte[] 1048576;for($n=0;$n -lt 51;$n++){$data.Write($buffer,0,$buffer.Length)}}else{$byte=[Text.Encoding]::UTF8.GetBytes('fixture');$data.Write($byte,0,$byte.Length)}}finally{$data.Dispose()}}}finally{$z.Dispose();$stream.Dispose()};$path
}
$required=@('KKxtti debloat utility/KKxtti debloat utility.exe','KKxtti debloat utility/SHA256SUMS.txt')
foreach($badName in @('KKxtti debloat utility/../escape','other-root/extra','KKxtti debloat utility/folder\bad','KKxtti debloat utility/file:stream','KKxtti debloat utility/State/transaction.json')){
 $badZip=New-FixtureZip ($required+@($badName));$target=Join-Path $script:fixture ([guid]::NewGuid().ToString('N'))
 Refuses {Expand-KKxttiPackage $badZip $target} 'Invalid|Unexpected|reserved'
 Check (-not(Test-Path $target)) 'unsafe ZIP refused before extraction'
}
$duplicate=New-FixtureZip ($required+@('KKxtti debloat utility/kkxtti debloat utility.exe'))
Refuses {Expand-KKxttiPackage $duplicate (Join-Path $script:fixture 'duplicate')} 'Duplicate'
$linkZip=New-FixtureZip $required $true
Refuses {Expand-KKxttiPackage $linkZip (Join-Path $script:fixture 'symlink')} 'contains a link'
$largeZip=New-FixtureZip $required $false $true
Refuses {Expand-KKxttiPackage $largeZip (Join-Path $script:fixture 'oversize')} 'size limit'
$missing=New-FixtureZip @('KKxtti debloat utility/readme.txt')
Refuses {Expand-KKxttiPackage $missing (Join-Path $script:fixture 'missing')} 'Required release files'
$linkTarget=Join-Path $script:fixture 'junction-target';[void][IO.Directory]::CreateDirectory($linkTarget)
$junction=Join-Path $script:fixture 'junction';New-Item -ItemType Junction -Path $junction -Target $linkTarget | Out-Null
Refuses {Assert-KKxttiDirectory (Join-Path $junction 'file') $script:fixture} 'link or junction'
function Assert-KKxttiWindows {throw 'Unsupported Windows fixture'}
$priorDownloads=$script:downloads;Refuses {Invoke-KKxttiLauncher @argsFixture} 'Unsupported Windows'
Check ($script:downloads -eq $priorDownloads -and $script:starts -eq 1) 'platform failure stops downloads and starts'
$mockDownload=Join-Path $script:fixture 'mock-network.zip'
Refuses {& $script:realReceive 'http://raw.githubusercontent.com/example/file' $mockDownload} 'Unexpected release download host'
Refuses {& $script:realReceive 'https://example.com/file' $mockDownload} 'Unexpected release download host'
function Invoke-WebRequest {param($Uri,[switch]$UseBasicParsing,$OutFile,$TimeoutSec,$ErrorAction);Check ($UseBasicParsing -and $TimeoutSec -eq 120) 'portable request with bounded timeout';[IO.File]::WriteAllText($OutFile,'mock download')}
$priorTls=[Net.ServicePointManager]::SecurityProtocol
& $script:realReceive 'https://raw.githubusercontent.com/example/file' $mockDownload
Check ([IO.File]::ReadAllText($mockDownload) -ceq 'mock download') 'download result written only to requested fixture'
Check ([Net.ServicePointManager]::SecurityProtocol -eq $priorTls) 'TLS session settings restored after successful request'
function Invoke-WebRequest {param($Uri,[switch]$UseBasicParsing,$OutFile,$TimeoutSec,$ErrorAction);throw 'Fixture request failed'}
Refuses {& $script:realReceive 'https://raw.githubusercontent.com/example/file' $mockDownload} 'Fixture request failed'
Check ([Net.ServicePointManager]::SecurityProtocol -eq $priorTls) 'TLS session settings restored after failed request'
Write-Host ('TOTAL: '+$script:checks+' launcher checks. Downloads/processes mocked; only workspace fixtures created.')
