using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Microsoft.VisualBasic.FileIO;

namespace KKxtti {
 public sealed class FrameStream {
  public string Application,Process,SwapChain,Metric;
  public readonly List<double> Intervals=new List<double>();
  public int Rejected;
  public override string ToString(){return Application+" / PID "+Process+" / "+SwapChain+" / "+Intervals.Count+" frames";}
 }
 public sealed class FrameFile {
  public string Path,Metric; public int Rows,Rejected;
  public readonly List<FrameStream> Streams=new List<FrameStream>();
 }
 public sealed class FrameStats {
  public int Frames;public double Seconds,MeanMs,MedianMs,P95Ms,P99Ms,MaxMs,AverageFps,SlowestOnePercentFps,OverBudgetPercent;
 }
 public static class FrameAnalysis {
  public static readonly string[] Metrics={"MsBetweenPresents","MsBetweenAppStart","CPUFrameTime","FrameTime"};
  public static FrameFile Read(string path,string metric) {
   if(!Metrics.Contains(metric))throw new InvalidDataException("Choose a supported frame-time column.");
   var info=new FileInfo(path);if(!info.Exists||info.Length>100L*1024*1024)throw new InvalidDataException("Choose a CSV file no larger than 100 MB.");
   var result=new FrameFile{Path=info.FullName,Metric=metric};var groups=new Dictionary<string,FrameStream>();
   using(var csv=new TextFieldParser(path)) {
    csv.TextFieldType=FieldType.Delimited;csv.SetDelimiters(",");csv.HasFieldsEnclosedInQuotes=true;csv.TrimWhiteSpace=true;
    string[] header=csv.ReadFields();if(header==null)throw new InvalidDataException("The CSV is empty.");
    if(header.Distinct(StringComparer.OrdinalIgnoreCase).Count()!=header.Length)throw new InvalidDataException("The CSV contains duplicate column names.");
    int column=Array.IndexOf(header,metric);if(column<0)throw new InvalidDataException("The CSV has no "+metric+" column. Choose the matching format and try again. Supported columns: "+String.Join(", ",Metrics)+". Values must be milliseconds.");
    int app=Array.IndexOf(header,"Application"),pid=Array.IndexOf(header,"ProcessID"),swap=Array.IndexOf(header,"SwapChainAddress");
    while(!csv.EndOfData) {
     if(++result.Rows>1000000)throw new InvalidDataException("The CSV exceeds one million rows. Export a shorter capture.");
     string[] row=csv.ReadFields();if(row.Length!=header.Length){result.Rejected++;continue;}
     string a=app<0?"Single series":row[app],p=pid<0?"unknown":row[pid],s=swap<0?"unknown swap chain":row[swap];
     string key=a.Length+":"+a+p.Length+":"+p+s.Length+":"+s;
     FrameStream stream;if(!groups.TryGetValue(key,out stream)){if(groups.Count>=512)throw new InvalidDataException("Too many processes or swap chains. Capture only the game.");stream=new FrameStream{Application=a,Process=p,SwapChain=s,Metric=metric};groups.Add(key,stream);result.Streams.Add(stream);}
     double value;if(!Double.TryParse(row[column],NumberStyles.Float,CultureInfo.InvariantCulture,out value)||Double.IsInfinity(value)||Double.IsNaN(value)||value<=0||value>86400000){result.Rejected++;stream.Rejected++;continue;}
     stream.Intervals.Add(value);
    }
   }
   if(!result.Streams.Any(s=>s.Intervals.Count>0))throw new InvalidDataException("No positive, finite frame-time values were found.");
   return result;
  }
  public static FrameStats Summarize(IEnumerable<double> values,double targetFps) {
   if(Double.IsNaN(targetFps)||Double.IsInfinity(targetFps)||targetFps<1||targetFps>2000)throw new ArgumentOutOfRangeException("targetFps");
   var times=values.ToArray();if(times.Length<2||times.Any(t=>Double.IsNaN(t)||Double.IsInfinity(t)||t<=0||t>86400000))throw new InvalidDataException("At least two valid frame intervals are required.");
   var sorted=times.OrderBy(t=>t).ToArray();int count=times.Length,tail=Math.Max(1,(int)Math.Ceiling(count*.01));double mean=times.Average();
   return new FrameStats{Frames=count,Seconds=times.Sum()/1000.0,MeanMs=mean,MedianMs=count%2==1?sorted[count/2]:(sorted[count/2-1]+sorted[count/2])/2,P95Ms=sorted[(int)Math.Ceiling(count*.95)-1],P99Ms=sorted[(int)Math.Ceiling(count*.99)-1],MaxMs=sorted[count-1],AverageFps=1000/mean,SlowestOnePercentFps=1000/sorted.Skip(count-tail).Average(),OverBudgetPercent=100.0*times.Count(t=>t>1000.0/targetFps)/count};
  }
 }
}
