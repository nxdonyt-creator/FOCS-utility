using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Management.Automation;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Threading;

namespace KKxtti {
 public static class PeripheralIdentity {
  public static string FromRawPath(string path){if(String.IsNullOrEmpty(path))return "";string text=path.StartsWith(@"\\?\")?path.Substring(4):path;string[] parts=text.Split('#');return parts.Length>=3?String.Join(@"\",parts.Take(3)).ToUpperInvariant():text.ToUpperInvariant();}
 }
 public sealed partial class Dashboard {
  sealed class Peripheral {public string Name,Roles,Note;public string[] Ids;public bool Virtual;}
  readonly List<Peripheral> peripherals=new List<Peripheral>();
  readonly Dictionary<IntPtr,string> rawDeviceIds=new Dictionary<IntPtr,string>();
  StackPanel peripheralList;TextBlock peripheralHero,peripheralSummary,peripheralNote;
  string activeMouse="";bool peripheralBusy,peripheralDirty=true;DateTime peripheralDue=DateTime.MinValue,lastMouseUpdate=DateTime.MinValue;
  HwndSource inputSource;IntPtr inputWindow;
  [StructLayout(LayoutKind.Sequential)] struct RawRegistration {public ushort Page,Usage;public uint Flags;public IntPtr Window;}
  [StructLayout(LayoutKind.Sequential)] struct RawHeader {public uint Type,Size;public IntPtr Device,WParam;}
  [DllImport("user32.dll",SetLastError=true)] static extern bool RegisterRawInputDevices(RawRegistration[] devices,uint count,uint size);
  [DllImport("user32.dll")] static extern uint GetRawInputData(IntPtr handle,uint command,out RawHeader header,ref uint size,uint headerSize);
  [DllImport("user32.dll",CharSet=CharSet.Unicode,EntryPoint="GetRawInputDeviceInfoW")] static extern uint RawName(IntPtr device,uint command,StringBuilder data,ref uint size);
  void StartPeripheralDetection() {
   inputWindow=new WindowInteropHelper(this).Handle;inputSource=HwndSource.FromHwnd(inputWindow);if(inputSource==null)return;inputSource.AddHook(InputMessage);
   // Mouse device identity only, never key presses, pointer coordinates or
   // button contents. INPUTSINK permits identity updates while on monitor 2.
   bool ok=RegisterRawInputDevices(new[]{new RawRegistration{Page=1,Usage=2,Flags=0x2100,Window=inputWindow}},1,(uint)Marshal.SizeOf(typeof(RawRegistration)));
   if(!ok)peripheralNote.Text="Connected devices remain available; active-mouse identification is unavailable.";
   RefreshPeripherals();
  }
  void StopPeripheralDetection(){if(inputSource!=null){inputSource.RemoveHook(InputMessage);RegisterRawInputDevices(new[]{new RawRegistration{Page=1,Usage=2,Flags=1,Window=IntPtr.Zero}},1,(uint)Marshal.SizeOf(typeof(RawRegistration)));inputSource=null;}}
  IntPtr InputMessage(IntPtr hwnd,int message,IntPtr wParam,IntPtr lParam,ref bool handled) {
   if(message==0x00FE||message==0x0219){peripheralDirty=true;peripheralDue=DateTime.UtcNow.AddSeconds(1);rawDeviceIds.Clear();}
   if(message==0x00FF&&DateTime.UtcNow-lastMouseUpdate>TimeSpan.FromMilliseconds(250)){
    uint size=(uint)Marshal.SizeOf(typeof(RawHeader));RawHeader header;
    if(GetRawInputData(lParam,0x10000005,out header,ref size,(uint)Marshal.SizeOf(typeof(RawHeader)))!=UInt32.MaxValue&&header.Type==0&&header.Device!=IntPtr.Zero){
     string id;if(!rawDeviceIds.TryGetValue(header.Device,out id)){uint chars=2048;var text=new StringBuilder(2048);uint result=RawName(header.Device,0x20000007,text,ref chars);id=result==UInt32.MaxValue?"":PeripheralIdentity.FromRawPath(text.ToString());rawDeviceIds[header.Device]=id;}
     if(id.Length>0){activeMouse=id;lastMouseUpdate=DateTime.UtcNow;UpdatePeripheralHero();}
    }
   }
   // Leave WM_INPUT unhandled so normal Windows input cleanup still occurs.
   return IntPtr.Zero;
  }
  void TickPeripherals(){if(peripheralDirty&&!peripheralBusy&&DateTime.UtcNow>=peripheralDue)RefreshPeripherals();}
  void BuildPeripheralCards(StackPanel page) {
   page.Children.Add(Text("Connected peripherals",21,null,true));page.Children.Add(Gap(8));
   peripheralNote=Text("Reads present Windows devices and groups their HID interfaces. Move a mouse to identify the device sending input. Polling rate, DPI and switch actuation are not reliably exposed by Windows.",12,"#A2ABC1");page.Children.Add(peripheralNote);
   page.Children.Add(Buttons(Btn("Refresh devices",()=>{peripheralDirty=true;RefreshPeripherals();}),Btn("Windows mouse settings",()=>OpenUri("ms-settings:mousetouchpad"))));
   peripheralList=new StackPanel();page.Children.Add(peripheralList);
  }
  void RefreshPeripherals() {
   if(peripheralBusy||closed)return;peripheralBusy=true;peripheralDirty=false;
   Task.Run(()=>Backend.Run(root,"Get-ConnectedPeripherals",new ActionBridge(this))).ContinueWith(task=>Dispatcher.BeginInvoke(new Action(()=>{
    peripheralBusy=false;if(closed)return;
    if(task.IsFaulted){peripheralNote.Text="Could not read present devices: "+task.Exception.GetBaseException().Message;peripheralHero.Text="Device detection unavailable";peripheralSummary.Text="See Timers & input for details";peripheralDue=DateTime.UtcNow.AddSeconds(30);peripheralDirty=true;return;}
    peripheralNote.Text="Present Windows devices; HID interfaces from the same device are grouped. Move a mouse to identify it on the dashboard. Polling rate and paired wireless models may require the manufacturer's software.";
    peripherals.Clear();foreach(var row in task.Result)peripherals.Add(new Peripheral{Name=Value(row,"Name"),Ids=Value(row,"Ids","").Split('|').Select(v=>v.ToUpperInvariant()).ToArray(),Roles=Value(row,"Roles"),Note=Value(row,"Note"),Virtual=Value(row,"Virtual")=="True"});
    if(!peripherals.Any(p=>p.Ids.Contains(activeMouse)))activeMouse="";RenderPeripherals();UpdatePeripheralHero();
   })));
  }
  void RenderPeripherals() {
   peripheralList.Children.Clear();foreach(var device in peripherals){var body=Stack(Text(device.Name,16,null,true),Gap(6),Text(device.Roles+" HID interfaces"+(device.Virtual?"  /  VIRTUAL":"  /  CONNECTED"),11,"#C9B5FF"),Gap(7),Text(device.Note,12,"#A2ABC1"));var card=Card(body,16);card.Margin=new Thickness(0,0,0,9);peripheralList.Children.Add(card);}
   if(peripherals.Count==0)peripheralList.Children.Add(Card(Text("No mouse or keyboard interfaces were reported. Refresh after connecting a device.",13,"#A2ABC1")));
  }
  void UpdatePeripheralHero() {
   var device=peripherals.FirstOrDefault(p=>p.Ids.Contains(activeMouse));peripheralHero.Text=device==null?"Move a mouse to identify it":device.Name;
   peripheralSummary.Text=device==null?peripherals.Count(p=>!p.Virtual)+" connected device group(s)":"Last mouse used while KKxtti is open";
  }
 }
}
