using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;

namespace KKxtti {
 public sealed partial class Dashboard {
  readonly FrameFile[] frameFiles=new FrameFile[2];readonly ComboBox[] frameStreams=new ComboBox[2];readonly TextBlock[] frameLabels=new TextBlock[2];
  ComboBox frameMetric;TextBox frameTarget;StackPanel frameResults;string comparisonReport;
  void BuildBenchmarks() {
   var page=Page("Benchmarks");
   page.Children.Add(Card(Stack(Pill("COMPARE / KEEP / UNDO"),Gap(12),Text("Did that change actually help?",25,null,true),Gap(8),Text("Import two captures from the same game scene. Compare smoothness and missed frame budgets, then keep the change only if repeated runs agree.",13,"#A2ABC1")),22));page.Children.Add(Gap(18));
   frameMetric=new ComboBox{Height=36,Foreground=Brushes.Black,Padding=new Thickness(8,5,8,5)};foreach(var m in FrameAnalysis.Metrics)frameMetric.Items.Add(m);frameMetric.SelectedIndex=0;AutomationProperties.SetName(frameMetric,"Frame interval CSV column");
   frameTarget=new TextBox{Text="240",Height=36,Padding=new Thickness(9,6,9,6)};AutomationProperties.SetName(frameTarget,"Target FPS");frameTarget.TextChanged+=(s,e)=>InvalidateComparison();
   page.Children.Add(Columns(new UIElement[]{Stack(Label("CSV COLUMN / MILLISECONDS"),Gap(7),frameMetric),Stack(Label("TARGET FPS / FRAME BUDGET"),Gap(7),frameTarget)},3,1));page.Children.Add(Gap(14));
   var panels=new UIElement[2];for(int i=0;i<2;i++){int slot=i;frameLabels[i]=Text("No capture loaded",12,"#A2ABC1");frameStreams[i]=new ComboBox{Height=36,Foreground=Brushes.Black,Padding=new Thickness(6)};AutomationProperties.SetName(frameStreams[i],i==0?"Baseline process and swap chain":"Changed process and swap chain");frameStreams[i].SelectionChanged+=(s,e)=>{InvalidateComparison();};panels[i]=Card(Stack(Pill(i==0?"A / BASELINE":"B / ONE CHANGE"),Gap(12),frameLabels[i],Gap(12),frameStreams[i],Buttons(Btn("Import "+(i==0?"baseline":"comparison")+" CSV",()=>ImportFrames(slot),true))),18);}
   page.Children.Add(Columns(panels));page.Children.Add(Buttons(Btn("Compare captures",()=>CompareFrames(),true),Btn("Save comparison",()=>SaveFrameComparison()),Btn("Capture instructions",()=>OpenLocal("BENCHMARK GUIDE.txt")),Btn("PresentMon project",()=>OpenUri("https://github.com/GameTechDev/PresentMon/releases"))));page.Children.Add(Gap(12));
   frameResults=new StackPanel();page.Children.Add(frameResults);
   page.Children.Add(Gap(16));page.Children.Add(Text("Use the same column, process, swap chain, game settings and capture method. Frame intervals do not measure mouse-to-screen latency. CPU/present cadence can differ from displayed frames, especially with frame generation or dropped presents.",12,"#A2ABC1"));
  }
  async void ImportFrames(int slot) {
   if(busy)return;var picker=new Microsoft.Win32.OpenFileDialog{Title="Choose a frame-time CSV",Filter="CSV captures (*.csv)|*.csv",CheckFileExists=true,Multiselect=false};if(picker.ShowDialog(this)!=true)return;
   string metric=frameMetric.SelectedItem as string;SetBusy(true,"Reading capture…");
   try{var file=await Task.Run(()=>FrameAnalysis.Read(picker.FileName,metric));frameFiles[slot]=file;frameLabels[slot].Text=System.IO.Path.GetFileName(file.Path)+"\n"+file.Rows+" rows  ·  "+file.Rejected+" excluded  ·  "+metric;frameStreams[slot].Items.Clear();foreach(var stream in file.Streams.Where(v=>v.Intervals.Count>0).OrderByDescending(v=>v.Intervals.Count))frameStreams[slot].Items.Add(stream);frameStreams[slot].SelectedIndex=frameStreams[slot].Items.Count==1?0:-1;comparisonReport=null;frameResults.Children.Clear();frameResults.Children.Add(Text(frameStreams[slot].Items.Count>1?"Multiple streams found. Select the game process and matching swap chain explicitly.":"Capture loaded. Load the other run to compare.",13,"#C9B5FF"));Log("Imported local frame-time CSV: "+System.IO.Path.GetFileName(file.Path));}catch(Exception ex){Notice("Could not import capture",ex.Message);}SetBusy(false,"Ready");
  }
  void CompareFrames() {
   if(busy)return;var a=frameStreams[0].SelectedItem as FrameStream;var b=frameStreams[1].SelectedItem as FrameStream;
   if(a==null||b==null){Notice("Choose both captures","Import a baseline and a comparison, then select one process / swap chain in each.");return;}
   if(a.Metric!=b.Metric){Notice("Use matching metrics","The captures use different frame-time columns. Reimport one with the matching column.");return;}
   double target;if(!Double.TryParse(frameTarget.Text,NumberStyles.Float,CultureInfo.CurrentCulture,out target)||Double.IsNaN(target)||Double.IsInfinity(target)||target<1||target>2000){Notice("Choose a frame budget","Enter a target between 1 and 2000 FPS.");return;}
   try {
    var sa=FrameAnalysis.Summarize(a.Intervals,target);var sb=FrameAnalysis.Summarize(b.Intervals,target);frameResults.Children.Clear();
    var report=new StringBuilder();report.AppendLine("KKXTTI FRAME-TIME COMPARISON");report.AppendLine(DateTime.Now.ToString("O"));report.AppendLine("Metric: "+a.Metric+" (milliseconds); target "+target.ToString(CultureInfo.InvariantCulture)+" FPS");report.AppendLine("A: "+frameFiles[0].Path+" / "+a);report.AppendLine("B: "+frameFiles[1].Path+" / "+b);report.AppendLine("Excluded rows A/B: "+a.Rejected+" / "+b.Rejected);
    frameResults.Children.Add(Columns(new UIElement[]{FrameStatCard("A / BASELINE",sa,target),FrameStatCard("B / CHANGED",sb,target)}));
    string delta="Average FPS: "+Signed(100*(sb.AverageFps/sa.AverageFps-1))+"%   ·   1% low: "+Signed(100*(sb.SlowestOnePercentFps/sa.SlowestOnePercentFps-1))+"%   ·   p99 frame time: "+Signed(100*(sb.P99Ms/sa.P99Ms-1))+"%";
    frameResults.Children.Add(Gap(14));frameResults.Children.Add(Text(delta,13,"#D5C4FF"));
    string caution="One pair of runs cannot establish a winner. Repeat A/B/A at least three times with warm shaders and comparable scenes. Higher FPS and lower frame time are usually desirable; inspect variability and visual tradeoffs too.";
    if(a.Application!=b.Application)caution="These captures name different applications. Confirm they represent the same game before comparing.\n\n"+caution;
    if(sa.Frames<1000||sb.Frames<1000||sa.Seconds<60||sb.Seconds<60)caution="Short capture: the 1% tail contains very few samples. Capture at least 60 seconds of representative gameplay.\n\n"+caution;
    frameResults.Children.Add(Gap(8));frameResults.Children.Add(Text(caution,12,"#A2ABC1"));
    report.AppendLine(StatsText("A",sa,target));report.AppendLine(StatsText("B",sb,target));report.AppendLine(delta);report.AppendLine(caution);report.AppendLine("Average FPS = 1000 / mean interval. 1% low = 1000 / mean of the slowest ceil(N * .01) intervals. p95 and p99 use nearest rank. All valid positive intervals are included; long frames are not discarded. Zero/nonfinite/invalid rows are excluded and counted. No input-latency inference.");comparisonReport=report.ToString();
   }catch(Exception ex){Notice("Could not compare",ex.Message);}
  }
  void InvalidateComparison(){comparisonReport=null;if(frameResults!=null){frameResults.Children.Clear();frameResults.Children.Add(Text("Selection changed. Compare captures again to update the results.",12,"#A2ABC1"));}}
  static string Signed(double v){return v.ToString("+0.0;-0.0;0.0",CultureInfo.CurrentCulture);}
  static string StatsText(string name,FrameStats s,double target){return name+": "+s.Frames+" frames / "+s.Seconds.ToString("0.0")+" seconds of valid intervals\nAverage FPS "+s.AverageFps.ToString("0.0")+" / 1% low "+s.SlowestOnePercentFps.ToString("0.0")+"\np95 "+s.P95Ms.ToString("0.00")+" ms / p99 "+s.P99Ms.ToString("0.00")+" ms / worst "+s.MaxMs.ToString("0.00")+" ms\nOver "+(1000/target).ToString("0.00")+" ms budget: "+s.OverBudgetPercent.ToString("0.0")+"%";}
  Border FrameStatCard(string label,FrameStats s,double target){return Card(Stack(Pill(label),Gap(12),Text(s.AverageFps.ToString("0.0")+" FPS",28,null,true),Text("Interval-derived average",11,"#A2ABC1"),Gap(12),Text("1% low  "+s.SlowestOnePercentFps.ToString("0.0")+" FPS",16,"#D5C4FF",true),Gap(8),Text("p99  "+s.P99Ms.ToString("0.00")+" ms   ·   worst  "+s.MaxMs.ToString("0.00")+" ms",12,"#A2ABC1"),Gap(8),Text(s.OverBudgetPercent.ToString("0.0")+"% of intervals miss the "+target.ToString("0")+" FPS budget",12,"#A2ABC1"),Gap(8),Text(s.Frames+" intervals  /  "+s.Seconds.ToString("0.0")+" seconds",11,"#8F9BB5")),18);}
  void SaveFrameComparison(){if(String.IsNullOrEmpty(comparisonReport)){Notice("Compare captures first","Run a comparison before saving the report.");return;}try{string dir=System.IO.Path.Combine(root,"State","benchmarks");Directory.CreateDirectory(dir);string path=System.IO.Path.Combine(dir,DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,6)+".txt");File.WriteAllText(path,comparisonReport,Encoding.UTF8);Log("Saved comparison: "+path);status.Text="Comparison saved in State / benchmarks";}catch(Exception ex){Notice("Could not save",ex.Message);}}
 }
}
