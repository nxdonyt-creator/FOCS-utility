#requires -Version 5.1
param([string]$Root=(Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference='Stop'
. (Join-Path $Root 'Performance Utility.ps1') -LibraryOnly
. (Join-Path $Root 'Control Engine.ps1');. (Join-Path $Root 'Network Engine.ps1');. (Join-Path $Root 'DNS Engine.ps1')
$script:ControlRoot=Join-Path $PSScriptRoot ('dns-fixtures-'+[guid]::NewGuid().ToString('N'));$script:checks=0;$script:writes=0;$script:confirm=$true
function Check($v,$m){if(-not $v){throw ('FAIL: '+$m)};$script:checks++;Write-Host ('PASS: '+$m)}
function Refuses($b,$p){$caught=$false;try{& $b | Out-Null}catch{$caught=$true;Check ($_.Exception.Message -match $p) ('refused '+$p)};Check $caught 'refusal surfaced'}
function Assert-NetworkAdmin {}
function Confirm-Action($Message,$Word){$script:confirm}
$script:adapter=[pscustomobject]@{InterfaceGuid=[guid]'11111111-2222-3333-4444-555555555555';InterfaceDescription='Fixture NIC';Name='Fixture[only]';ifIndex=77;PnPDeviceID='fixture';DriverVersion='1'}
function Get-PhysicalNetworkAdapters {@($script:adapter)}
$script:dns=@{IPv4=[pscustomobject]@{Automatic=$true;Servers=@('192.0.2.1')};IPv6=[pscustomobject]@{Automatic=$false;Servers=@('2001:db8::1')}}
function Read-DnsValue($Adapter,$Family){$script:dns[$Family]}
function Write-DnsValue($Adapter,$Family,$Value){$script:writes++;$script:dns[$Family]=$Value}
$script:normalWrite=${function:Write-DnsValue};$id=[string]$script:adapter.InterfaceGuid
$before4=$script:dns.IPv4;$before6=$script:dns.IPv6
$r=Set-SelectedDnsProfile $id 'cloudflare';Check ($r.Status -eq 'Applied') 'DNS profile journal applied'
Check ($script:dns.IPv4.Servers[0] -eq '1.1.1.1' -and $script:dns.IPv6.Servers[0] -eq '2606:4700:4700::1111') 'both families set to reviewed endpoints'
$null=Undo-SelectedDnsProfile $r.Id
Check ($script:dns.IPv4.Automatic -and -not $script:dns.IPv6.Automatic -and $script:dns.IPv6.Servers[0] -eq '2001:db8::1') 'mixed automatic/static modes exactly restored'
Check (Test-DnsEqual ([pscustomobject]@{Automatic=$true;Servers=@('192.0.2.99')}) $before4) 'DHCP address renewal is not a false conflict'
$script:confirm=$false;$n=$script:writes;$null=Set-SelectedDnsProfile $id 'google';Check ($script:writes -eq $n) 'cancelled DNS review no writes'
$script:confirm=$true;Refuses {Set-SelectedDnsProfile $id 'untrusted-provider'} 'reviewed DNS';Check ($script:writes -eq $n) 'unknown provider rejected'
$r=Set-SelectedDnsProfile $id 'google';$script:dns.IPv6=[pscustomobject]@{Automatic=$false;Servers=@('2001:db8::9')};$n=$script:writes
Refuses {Undo-SelectedDnsProfile $r.Id} 'external DNS';Check ($script:writes -eq $n) 'conflict in second family stops whole restore'
$script:dns=@{IPv4=$before4;IPv6=$before6};$script:writeCount=0
function Write-DnsValue($Adapter,$Family,$Value){$script:writeCount++;& $script:normalWrite $Adapter $Family $Value;if($script:writeCount -eq 2){throw 'Injected second-family failure'}}
Refuses {Set-SelectedDnsProfile $id 'quad9'} 'Rolled back'
Set-Item Function:Write-DnsValue $script:normalWrite
Check ((Test-DnsEqual $script:dns.IPv4 $before4) -and (Test-DnsEqual $script:dns.IPv6 $before6)) 'partial DNS failure rolls back both families including failed one'
$r=Set-SelectedDnsProfile $id 'google';$script:adapter.DriverVersion='2';$n=$script:writes
Refuses {Undo-SelectedDnsProfile $r.Id} 'driver changed';Check ($script:writes -eq $n) 'driver change prevents restore'
Refuses {Undo-SelectedDnsProfile '..\other'} 'Invalid DNS'
Refuses {Assert-DnsValue 'IPv4' ([pscustomobject]@{Automatic=$false;Servers=@('::1')})} 'another address family'
Refuses {Assert-DnsValue 'IPv6' ([pscustomobject]@{Automatic=$false;Servers=@()})} 'Invalid saved'
Refuses {Assert-DnsValue 'IPv4' ([pscustomobject]@{Automatic=$false;Servers=@('bad.address')})} 'Invalid DNS server'
Write-Host ('TOTAL: '+$script:checks+' DNS checks. No physical adapter DNS was modified.')
