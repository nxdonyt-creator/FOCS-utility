#requires -Version 5.1
param([string]$Root=(Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference='Stop'
. (Join-Path $Root 'Performance Utility.ps1') -LibraryOnly
foreach($engine in @('Control Engine.ps1','Game Engine.ps1','System Engine.ps1','Profile Engine.ps1','Fortnite Profile.ps1','Reset Engine.ps1','Peripheral Engine.ps1')){. (Join-Path $Root $engine)}
$script:ControlRoot=Join-Path $PSScriptRoot ('gaming-fixtures-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($script:ControlRoot)
$script:checks=0;$script:admin=$true;$script:confirm=$true;$script:gameOpen=$false
function Check($Value,$Message){if(-not $Value){throw ('FAIL: '+$Message)};$script:checks++;Write-Host ('PASS: '+$Message)}
function Refuses($Block,$Pattern){$caught=$false;try{& $Block|Out-Null}catch{$caught=$true;Check ($_.Exception.Message -match $Pattern) ('refused '+$Pattern)};Check $caught 'failure surfaced'}
function Test-Admin {$script:admin}
function Confirm-Action($Message,$Word){$script:confirm}
function Assert-GameClosed($Game){if($script:gameOpen){throw 'Close the game'}}

# Driver sessions: staged settings, commit failure and inherited/local recovery.
$script:nvState=@{};$script:nvSaves=0;$script:nvFail=$false
function New-NvValue([bool]$Local,[uint32]$Value,[bool]$Found=$true){[pscustomobject]@{Local=$Local;Value=$Value;Found=$Found}}
foreach($spec in Get-NvidiaCatalog){$script:nvState[[string]$spec.Id]=New-NvValue $false 0 $false}
$script:nvState['274197361']=New-NvValue $true 5
$originalNv=($script:nvState|ConvertTo-Json -Depth 5)
function Open-NvidiaSession($GameId){
 if($GameId -cnotin @('fortnite','siege')){throw 'Unsupported NVIDIA game'}
 $obj=[pscustomobject]@{ProfileName='Fixture profile';Pending=@{}}
 $obj|Add-Member ScriptMethod Get {param([uint32]$Id);$script:nvState[[string]$Id]}
 $obj|Add-Member ScriptMethod Set {param([uint32]$Id,[uint32]$Value);$this.Pending[[string]$Id]=New-NvValue $true $Value}
 $obj|Add-Member ScriptMethod Remove {param([uint32]$Id);$this.Pending[[string]$Id]=New-NvValue $false 0 $false}
 $obj|Add-Member ScriptMethod Save {$script:nvSaves++;if($script:nvFail){$script:nvFail=$false;throw 'Injected NVIDIA save failure'};foreach($key in $this.Pending.Keys){$script:nvState[$key]=$this.Pending[$key]}}
 $obj|Add-Member ScriptMethod Dispose {}
 $obj
}
$script:admin=$false;Refuses {Set-NvidiaPerformanceProfile 'fortnite'} 'administrator';Check ($script:nvSaves -eq 0) 'driver not written without admin';$script:admin=$true
$script:confirm=$false;$null=Set-NvidiaPerformanceProfile 'fortnite';Check ($script:nvSaves -eq 0) 'cancelled NVIDIA review writes nothing';$script:confirm=$true
$script:gameOpen=$true;Refuses {Set-NvidiaPerformanceProfile 'fortnite'} 'Close the game';$script:gameOpen=$false
$n=Set-NvidiaPerformanceProfile 'fortnite';Check ($n.Status -eq 'Applied' -and $script:nvSaves -eq 1) 'game profile staged and saved once'
foreach($spec in Get-NvidiaCatalog){Check ($script:nvState[[string]$spec.Id].Local -and $script:nvState[[string]$spec.Id].Value -eq $spec.Target) ('driver target '+$spec.Name)}
$none=Set-NvidiaPerformanceProfile 'fortnite';Check ($none.Status -eq 'Already configured' -and $script:nvSaves -eq 1) 'already configured driver profile leaves no new mutation'
$null=Undo-NvidiaProfile $n.Id;Check (($script:nvState|ConvertTo-Json -Depth 5) -ceq $originalNv) 'reset restores local value and removes only introduced overrides'
$n=Set-NvidiaPerformanceProfile 'fortnite';$script:nvState['274197361']=New-NvValue $true 3;$before=$script:nvSaves
Refuses {Undo-NvidiaProfile $n.Id} 'conflicts';Check ($script:nvSaves -eq $before) 'conflicting driver reset has no committed write'
$script:nvState['274197361']=New-NvValue $true 1;$null=Undo-NvidiaProfile $n.Id
$script:nvFail=$true;Refuses {Set-NvidiaPerformanceProfile 'fortnite'} 'save failure'
$pending=@(Get-KKxttiResetRecords|Where-Object Kind -eq 'nvidia'|Select-Object -First 1)[0];Check ($pending.Status -eq 'Recovery needed') 'failed driver save remains recoverable'
$before=$script:nvSaves;$null=Undo-NvidiaProfile $pending.Id;Check ($script:nvSaves -eq $before) 'unsaved driver session recovery performs no unnecessary commit'
$n=Set-NvidiaPerformanceProfile 'fortnite';$saved=Read-ProfileJournal $n.Id 'nvidia';$saved.Journal.Rows[0].Id=123;Save-ControlJournal $saved.Path $saved.Journal
Refuses {Undo-NvidiaProfile $n.Id} 'Invalid/duplicate';$saved.Journal.Status='Test invalid record';Save-ControlJournal $saved.Path $saved.Journal
foreach($spec in Get-NvidiaCatalog){$script:nvState[[string]$spec.Id]=New-NvValue $false 0 $false}

# A real fixture INI is edited atomically; real game discovery is overridden.
$script:gamePath=Join-Path $script:ControlRoot 'fixture.ini'
function Get-GameConfigs {[pscustomobject]@{Id='fortnite';Name='Fixture';Game='fortnite';Path=$script:gamePath}}
$fixture=@('[ScalabilityGroups]','sg.ResolutionQuality=100','sg.ViewDistanceQuality=3','sg.ShadowQuality=2','sg.TextureQuality=3','sg.ShadingQuality=3','sg.LandscapeQuality=2','[/Script/FortniteGame.FortGameUserSettings]','bMotionBlur=True','bUseNanite=True','bUseDynamicResolution=True','FrameRateLimit=240.000000','MouseSensitivity=0.123','[Other]','Unrelated=keep') -join "`r`n"
[IO.File]::WriteAllText($script:gamePath,$fixture,[Text.UTF8Encoding]::new($true));$originalBytes=[IO.File]::ReadAllBytes($script:gamePath)
$preview=@(Get-FortnitePotatoPreview 50);Check (@($preview|Where-Object Available).Count -eq 9) 'preview reports supported existing graphics keys and missing ones'
$script:confirm=$false;$null=Set-FortnitePotatoProfile 50;Check ((Get-BytesHash ([IO.File]::ReadAllBytes($script:gamePath))) -ceq (Get-BytesHash $originalBytes)) 'cancelled graphics review preserves every byte';$script:confirm=$true
Refuses {Set-FortnitePotatoProfile 12} 'Choose';$script:gameOpen=$true;Refuses {Set-FortnitePotatoProfile 50} 'Close';$script:gameOpen=$false
$f=Set-FortnitePotatoProfile 50;$changed=[IO.File]::ReadAllText($script:gamePath)
Check ($f.Count -eq 9 -and $changed.Contains('sg.ResolutionQuality=50') -and $changed.Contains('sg.ShadingQuality=0')) 'Potato changes existing quality groups and render scale'
Check ($changed.Contains('MouseSensitivity=0.123') -and $changed.Contains('FrameRateLimit=240.000000') -and $changed.Contains('Unrelated=keep')) 'graphics profile preserves sensitivity cap and unrelated sections'
$null=Undo-FortnitePotatoProfile $f.Id;Check ((Get-BytesHash ([IO.File]::ReadAllBytes($script:gamePath))) -ceq (Get-BytesHash $originalBytes)) 'graphics reset restores original bytes and BOM'
$f=Set-FortnitePotatoProfile 67;$changed=[IO.File]::ReadAllText($script:gamePath).Replace('sg.TextureQuality=0','sg.TextureQuality=1');[IO.File]::WriteAllText($script:gamePath,$changed,[Text.UTF8Encoding]::new($true));$hash=Get-BytesHash ([IO.File]::ReadAllBytes($script:gamePath))
Refuses {Undo-FortnitePotatoProfile $f.Id} 'conflict';Check ((Get-BytesHash ([IO.File]::ReadAllBytes($script:gamePath))) -ceq $hash) 'one conflicting graphics key stops the entire reset'
[IO.File]::WriteAllText($script:gamePath,$changed.Replace('sg.TextureQuality=1','sg.TextureQuality=0'),[Text.UTF8Encoding]::new($true));$null=Undo-FortnitePotatoProfile $f.Id
[IO.File]::WriteAllText($script:gamePath,$fixture.Replace('sg.ResolutionQuality=100','sg.ResolutionQuality=100'+"`r`n"+'sg.ResolutionQuality=50'),[Text.UTF8Encoding]::new($true));Refuses {Set-FortnitePotatoProfile} 'unique render-scale'
[IO.File]::WriteAllBytes($script:gamePath,$originalBytes)
$item=Get-Item -LiteralPath $script:gamePath;$item.IsReadOnly=$true;try{Refuses {Set-FortnitePotatoProfile} 'read-only'}finally{$item.IsReadOnly=$false}
$pending=@(Get-KKxttiResetRecords|Where-Object Kind -eq 'fortnite'|Select-Object -First 1)[0];$null=Undo-FortnitePotatoProfile $pending.Id
Check ((Get-BytesHash ([IO.File]::ReadAllBytes($script:gamePath))) -ceq (Get-BytesHash $originalBytes)) 'failed graphics write recovers without modifying original file'

# Every power write is mocked. Fingerprints include hidden settings.
$script:active='11111111-1111-1111-1111-111111111111';$script:initialPlan=$script:active;$script:plans=@{};$script:plans[$script:active]=@{Name='Original';Values=@{}};$script:powerCalls=@();$script:missingPower='';$script:failPower=''
foreach($spec in Get-GamingPowerCatalog){$script:plans[$script:active].Values[$spec.Key]=42}
function Assert-GamingPowerDesktop {}
function Get-PowerGuid {$script:active}
function Read-GamingPowerValue($Plan,$Spec){if($Spec.Key -ceq $script:missingPower){throw 'Unavailable'};$script:plans[$Plan].Values[$Spec.Key]}
function Invoke-Native($Name,$Arguments){
 if($Name -cne 'powercfg.exe'){throw 'Unexpected native tool'};$script:powerCalls+=($Arguments -join ' ')
 switch($Arguments[0]){
  '/duplicatescheme'{$script:plans[$Arguments[2]]=@{Name='Clone';Values=$script:plans[$Arguments[1]].Values.Clone()}}
  '/changename'{$script:plans[$Arguments[1]].Name=$Arguments[2]}
  '/setacvalueindex'{if($Arguments[3] -ceq $script:failPower){throw 'Injected power write failure'};$script:plans[$Arguments[1]].Values[$Arguments[3]]=[uint32]$Arguments[4]}
  '/getactivescheme'{$script:active}
  '/qh' {($script:plans[$Arguments[1]].Name)+(($script:plans[$Arguments[1]].Values.Keys|Sort-Object|ForEach-Object {$_+':'+$script:plans[$Arguments[1]].Values[$_]}) -join '|')}
  '/query'{$script:plans[$Arguments[1]].Name}
  '/list'{$script:plans.Keys -join ' '}
  '/setactive'{$script:active=$Arguments[1]}
  '/delete'{$script:plans.Remove($Arguments[1])}
  default{throw 'Unexpected power operation'}
 }
}
$script:confirm=$false;$null=Set-GamingPowerPlan;Check ($script:plans.Count -eq 1) 'cancelled power review creates no plan';$script:confirm=$true
$power=Set-GamingPowerPlan;Check ($power.Status -eq 'Applied' -and $script:plans.Count -eq 2) 'custom power plan created separately'
foreach($spec in Get-GamingPowerCatalog){Check ($script:plans[$power.Plan].Values[$spec.Key] -eq $spec.Value) ('custom power setting '+$spec.Name)}
Check (@($script:powerCalls|Where-Object {$_ -like '/setdc*'}).Count -eq 0) 'battery settings never written'
Check ($script:plans[$script:initialPlan].Values.Values -notcontains 100) 'original power values untouched'
$null=Undo-UltimateTestPlan $power.Id;Check ($script:active -eq $script:initialPlan -and $script:plans.Count -eq 1) 'custom power reset restores old plan and deletes only created plan'
$power=Set-GamingPowerPlan;$hidden=(Get-GamingPowerCatalog|Where-Object Value -eq 2).Key;$script:plans[$power.Plan].Values[$hidden]=0
Refuses {Undo-UltimateTestPlan $power.Id} 'edited externally';Check ($script:active -eq $power.Plan) 'external hidden-power change blocks deletion'
$script:plans[$power.Plan].Values[$hidden]=2;$null=Undo-UltimateTestPlan $power.Id
$script:missingPower=$hidden;$power=Set-GamingPowerPlan;Check ($script:plans[$power.Plan].Values[$hidden] -eq 42) 'unsupported optional power setting is skipped';$null=Undo-UltimateTestPlan $power.Id;$script:missingPower=''
$script:failPower=$hidden;Refuses {Set-GamingPowerPlan} 'Injected power write failure';$script:failPower=''
Check ($script:active -ceq $script:initialPlan) 'failed custom power configuration leaves original plan active'
Check ($script:plans.Count -eq 2) 'unfingerprinted incomplete plan retained for inspection instead of unsafe deletion'

# Restore-point creator success, cancellation and Windows frequency failure.
$script:restoreCalls=0;$script:points=@();$script:createPoint=$true
function Get-ComputerRestorePoint {param($ErrorAction);$script:points}
function Checkpoint-Computer {param($Description,$RestorePointType,$ErrorAction);$script:restoreCalls++;if($script:createPoint){$script:points+=[pscustomobject]@{SequenceNumber=$script:restoreCalls;Description=$Description}}}
$script:confirm=$false;$null=New-ReviewedRestorePoint;Check ($script:restoreCalls -eq 0) 'restore-point cancellation does not call Windows';$script:confirm=$true
$rp=New-ReviewedRestorePoint;Check ($rp.Status -eq 'Created' -and $script:restoreCalls -eq 1) 'restore-point success requires newly observed point'
$script:createPoint=$false;Refuses {New-ReviewedRestorePoint} 'did not create';Check ($script:restoreCalls -eq 2) 'frequency restriction is surfaced, not reported as success'

# Reset ordering, no non-reversible operations, and early stop on conflict.
$priorRoot=$script:ControlRoot;$script:ControlRoot=Join-Path $priorRoot 'reset-records';[void][IO.Directory]::CreateDirectory($script:ControlRoot)
$first=New-ControlJournal 'settings' @([pscustomobject]@{Id='fixture'});$first.Journal.Status='Applied';$first.Journal.Created='2026-10-09T12:00:00+00:00';Save-ControlJournal $first.Path $first.Journal
$second=New-ControlJournal 'dns' @([pscustomobject]@{Id='fixture'});$second.Journal.Status='Applied';$second.Journal.Created='2026-10-10T12:00:00+00:00';Save-ControlJournal $second.Path $second.Journal
$removed=New-ControlJournal 'apps' @([pscustomobject]@{Id='fixture'});$removed.Journal.Status='Applied';Save-ControlJournal $removed.Path $removed.Journal
$listed=@(Get-KKxttiResetRecords);Check ($listed.Count -eq 2 -and ($listed.Kind -join ',') -ceq 'dns,settings') 'actual reset inventory excludes app removal and sorts journal timestamps'
$second.Journal.Computer='DIFFERENT-PC';Save-ControlJournal $second.Path $second.Journal;Refuses {Get-KKxttiResetRecords} 'different account/PC';$script:ControlRoot=$priorRoot
$profile=New-ControlJournal 'nvidia' @([pscustomobject]@{Id='fixture'});$profile.Journal.Status='Applied';$profile.Journal.Computer='DIFFERENT-PC';Save-ControlJournal $profile.Path $profile.Journal
Refuses {Read-ProfileJournal $profile.Journal.Id 'nvidia'} 'account and PC'
$profile.Journal.Computer=$env:COMPUTERNAME;Save-ControlJournal $profile.Path $profile.Journal;[IO.File]::WriteAllText($profile.Path,('x'*2097153));Refuses {Read-ProfileJournal $profile.Journal.Id 'nvidia'} 'too large'
$script:undoOrder=@();$script:stopKind='';$script:resetRows=@([pscustomobject]@{Id='new';Kind='fortnite';Status='Applied'},[pscustomobject]@{Id='old';Kind='nvidia';Status='Applied'})
function Get-KKxttiResetRecords {$script:resetRows}
function Invoke-KKxttiUndoRecord($Record){if($Record.Kind -ceq $script:stopKind){throw 'Fixture conflict'};$script:undoOrder+=$Record.Id}
$script:confirm=$false;$null=Reset-KKxttiSavedSettings;Check ($script:undoOrder.Count -eq 0) 'Reset all cancellation changes nothing';$script:confirm=$true
$r=Reset-KKxttiSavedSettings;Check ($r.Count -eq 2 -and ($script:undoOrder -join ',') -ceq 'new,old') 'Reset all follows reviewed newest-first order'
$script:undoOrder=@();$script:stopKind='nvidia';Refuses {Reset-KKxttiSavedSettings} 'after 1 completed';Check (($script:undoOrder -join ',') -ceq 'new') 'Reset all reports partial completion and stops on conflict'
$script:resetRows[0].Status='Recovery needed';$script:undoOrder=@();Refuses {Reset-KKxttiSavedSettings} 'individual recovery';Check ($script:undoOrder.Count -eq 0) 'Reset all blocks interrupted history before any mutation'

# Peripheral enumeration: present-only fixtures, composite de-duplication,
# truthful receiver names and device disappearance on refresh.
function Get-PnpDeviceProperty {param($InstanceId,$KeyName,$ErrorAction);[pscustomobject]@{KeyName='DEVPKEY_Device_FriendlyName';Type='Empty'}}
Check ((Get-PeripheralProperties 'fixture').Count -eq 0) 'missing PnP Data property is ignored under strict mode'
function Get-PeripheralNodes {@([pscustomobject]@{InstanceId='HID\MOUSE1';FriendlyName='HID-compliant mouse';Class='Mouse'},[pscustomobject]@{InstanceId='HID\KEYS1';FriendlyName='HID Keyboard Device';Class='Keyboard'},[pscustomobject]@{InstanceId='HID\RECEIVER';FriendlyName='HID-compliant mouse';Class='Mouse'})}
function Get-PeripheralProperties($Id){switch($Id){'HID\MOUSE1'{@{'DEVPKEY_Device_ContainerId'='one';'DEVPKEY_Device_Parent'='USB\MOUSE'}}'HID\KEYS1'{@{'DEVPKEY_Device_ContainerId'='one';'DEVPKEY_Device_Parent'='USB\MOUSE'}}'USB\MOUSE'{@{'DEVPKEY_Device_BusReportedDeviceDesc'='Fixture gaming mouse'}}'HID\RECEIVER'{@{'DEVPKEY_Device_ContainerId'='two';'DEVPKEY_Device_FriendlyName'='LIGHTSPEED Receiver'}}default{@{}}}}
$devices=@(Get-ConnectedPeripherals);Check ($devices.Count -eq 2) 'composite mouse and keyboard interfaces grouped once'
$mouse=@($devices|Where-Object Name -eq 'Fixture gaming mouse')[0];Check ($mouse.Roles -match 'Mouse' -and $mouse.Roles -match 'Keyboard') 'composite interface roles retained without inventing a second keyboard'
$receiver=@($devices|Where-Object Receiver)[0];Check ($receiver.Name -ceq 'LIGHTSPEED Receiver' -and $receiver.Note -like '*not reported reliably*') 'wireless receiver is not mislabeled as a guessed paired mouse'
function Get-PeripheralNodes {@()};Check (@(Get-ConnectedPeripherals).Count -eq 0) 'disconnected devices vanish on refresh'
Check (Test-GenericPeripheralName 'USB Receiver') 'generic receiver description does not outrank the product name'
Write-Host ('TOTAL: '+$script:checks+' gaming/profile/peripheral/reset checks. All Windows and NVIDIA mutations mocked; INI edits use fixtures only.')
