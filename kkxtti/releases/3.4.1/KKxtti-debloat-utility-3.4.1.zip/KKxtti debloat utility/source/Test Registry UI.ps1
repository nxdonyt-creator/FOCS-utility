#requires -Version 5.1
param([string]$Executable=(Join-Path (Split-Path -Parent $PSScriptRoot) 'KKxtti debloat utility.exe'))
$ErrorActionPreference='Stop'
Add-Type -AssemblyName PresentationFramework
$assembly=[Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $Executable).Path)
$script:checks=0
function Check($Ok,$Message){if(-not $Ok){throw ('FAIL: '+$Message)};$script:checks++;Write-Host ('PASS: '+$Message)}
Check ($assembly.GetName().Version.ToString() -eq '3.3.0.0') 'Executable assembly version is 3.3.0.0'
$window=New-Object KKxtti.Dashboard -ArgumentList @($false,$true)
try {
 Check ($window.Title -match '3.3.0') 'Window title exposes the release version'
 $flags=[Reflection.BindingFlags]'Instance,NonPublic'
 $pages=[KKxtti.Dashboard].GetField('pages',$flags).GetValue($window)
 Check ($pages.ContainsKey('Performance') -and $pages.ContainsKey('Benchmarks')) 'Performance and comparison pages construct'
 $list=[KKxtti.Dashboard].GetField('registryReviewList',$flags).GetValue($window)
 Check ($null -ne $list -and $list.Children.Count -eq 0) 'Review waits for an explicit inspection'
 $summary=[KKxtti.Dashboard].GetField('registryReviewSummary',$flags).GetValue($window)
 Check ($summary.Text -match '12 registry values') 'Review instructions are included in the compiled UI'
} finally {$window.Close()}
Write-Host ('TOTAL: '+$script:checks+' native UI construction checks. No window was shown and no settings action was invoked.')
