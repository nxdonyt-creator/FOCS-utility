#requires -Version 5.1
param([string]$Root=(Split-Path -Parent $PSScriptRoot),[string]$FixtureRoot=$PSScriptRoot)
$ErrorActionPreference='Stop'
. (Join-Path $Root 'Performance Utility.ps1') -LibraryOnly
. (Join-Path $Root 'Control Engine.ps1')
. (Join-Path $Root 'Registry Review.ps1')
$script:ControlRoot=Join-Path $FixtureRoot ('registry-review-'+[guid]::NewGuid().ToString('N'))
$script:values=@{};$script:admin=$true;$script:writeCount=0;$script:checks=0
function Check($Ok,$Message){if(-not $Ok){throw ('FAIL: '+$Message)};$script:checks++;Write-Host ('PASS: '+$Message)}
function Refuses($Code,$Pattern){$caught=$false;try{& $Code | Out-Null}catch{$caught=$true;Check ($_.Exception.Message -match $Pattern) ('Refused: '+$Pattern)};Check $caught 'Refusal surfaced'}
function Test-Admin {$script:admin}
function Get-ControlPlatform {[pscustomobject]@{Build=26200;Edition='Professional'}}
function Key($Spec){$Spec.Path+'|'+$Spec.Name}
function Read-ControlValue($Spec){if($Spec.Name -eq $script:failRead){throw 'Injected read failure'};$key=Key $Spec;if($script:values.ContainsKey($key)){$script:values[$key]}else{[pscustomobject]@{Exists=$false;Kind='DWord';Data=$null}}}
function Write-ControlValue($Spec,$Value){$script:writeCount++;$script:values[(Key $Spec)]=$Value}
$script:failRead=''
$rows=@(Get-VideoRegistryReview)
Check ($rows.Count -eq 12) 'Twelve allowlisted observations'
Check (@($rows | Where-Object Status -eq 'Not explicitly set').Count -eq 12) 'Absence stays unknown rather than becoming a guessed default'
Check ($script:writeCount -eq 0 -and -not(Test-Path -LiteralPath $script:ControlRoot)) 'Inspection creates no changes or journals'
$spec=(@(Get-ControlCatalog | Where-Object Id -eq 'mmcss-reservation')[0]).Values[0]
$key=Key $spec
$script:values[$key]=[pscustomobject]@{Exists=$true;Kind='String';Data='20'}
Check ((Get-VideoRegistryReview | Where-Object Name -eq 'SystemResponsiveness').Status -eq 'Unexpected type') 'Unexpected registry types are surfaced'
$network=Get-VideoRegistryCatalog | Where-Object Name -eq 'NetworkThrottlingIndex'
$script:values[(Key $network)]=[pscustomobject]@{Exists=$true;Kind='DWord';Data=-1}
Check ((Get-VideoRegistryReview | Where-Object Name -eq 'NetworkThrottlingIndex').Current -match '4294967295 \(0xFFFFFFFF\)') 'Unsigned DWORD values are displayed correctly'
$script:failRead='LargeSystemCache';$rows=@(Get-VideoRegistryReview)
Check ($rows.Count -eq 12 -and ($rows | Where-Object Name -eq 'LargeSystemCache').Status -eq 'Read failed') 'One inaccessible value does not hide the rest of the review'
$script:failRead=''
$script:values=@{};$script:admin=$false
Refuses {Set-ControlSettings @('mmcss-reservation') $true} 'Administrator'
Check ($script:writeCount -eq 0) 'Administrative requirement enforced before write'
$script:admin=$true
foreach($before in @([pscustomobject]@{Exists=$false;Kind='DWord';Data=$null},[pscustomobject]@{Exists=$true;Kind='DWord';Data=37},[pscustomobject]@{Exists=$true;Kind='String';Data='original fixture'})){
 $script:values[$key]=$before
 $change=Set-ControlSettings @('mmcss-reservation') $true
 Check ((Read-ControlValue $spec).Data -eq 10 -and (Read-ControlValue $spec).Kind -eq 'DWord') 'On writes decimal ten only'
 $other=Set-ControlSettings @('mmcss-reservation') $false
 Check ((Read-ControlValue $spec).Data -eq 20) 'Off is the explicit twenty-percent comparison'
 $null=Undo-ControlSettings $other.Id
 Check ((Read-ControlValue $spec).Data -eq 10) 'Undo of Off returns to the preceding experiment'
 $null=Undo-ControlSettings $change.Id
 Check (Test-ControlEqual (Read-ControlValue $spec) $before) 'Undo restores exact original value, type or absence'
}
$change=Set-ControlSettings @('mmcss-reservation') $true
$script:values[$key]=[pscustomobject]@{Exists=$true;Kind='DWord';Data=30}
$writes=$script:writeCount
Refuses {Undo-ControlSettings $change.Id} 'newer or external'
Check ($script:writeCount -eq $writes -and (Read-ControlValue $spec).Data -eq 30) 'External edits survive a conflicting Undo'
Write-Host ('TOTAL: '+$script:checks+' registry review checks. All Windows registry reads/writes mocked.')
