#requires -Version 5.1
param([string]$Root=(Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference='Stop'
. (Join-Path $Root 'Performance Utility.ps1') -LibraryOnly
. (Join-Path $Root 'Control Engine.ps1');. (Join-Path $Root 'Installer Engine.ps1')
$script:ControlRoot=Join-Path $PSScriptRoot ('installer-fixtures-'+[guid]::NewGuid().ToString('N'));$script:checks=0;$script:processCalls=@();$script:code=0;$script:installed=$true
function Check($v,$m){if(-not $v){throw ('FAIL: '+$m)};$script:checks++;Write-Host ('PASS: '+$m)}
function Refuses($b,$p){$caught=$false;try{& $b | Out-Null}catch{$caught=$true;Check ($_.Exception.Message -match $p) ('refused '+$p)};Check $caught 'refusal surfaced'}
function Get-TrustedWinget {'C:\Fixture\winget.exe'}
$script:official=$true
function Invoke-InstallerProcess($Path,$Arguments){
 $script:processCalls+=,$Arguments
 if($Arguments[0] -eq 'source'){[pscustomobject]@{Code=0;Output=$(if($script:official){'{"Name":"winget","Arg":"https://cdn.winget.microsoft.com/cache","Type":"Microsoft.PreIndexed.Package","Identifier":"Microsoft.Winget.Source_8wekyb3d8bbwe"}'}else{'{"Name":"winget","Arg":"https://attacker.invalid/cache","Type":"Microsoft.PreIndexed.Package","Identifier":"Microsoft.Winget.Source_8wekyb3d8bbwe"}'});Error=''}}
 else{[pscustomobject]@{Code=$script:code;Output='Fixture installer result';Error=''}}
}
function Get-InstallerStates {foreach($id in @('discord','epic')){[pscustomobject]@{Id=$id;State=$(if($script:installed){'Installed (inventory)'}else{'Not detected'})}}}
function Install-OfficialChromium {[pscustomobject]@{Status='Cancelled'}}
$r=@(Install-ManagedTools @('discord','epic'));Check ($r.Count -eq 2 -and @($r | Where-Object Status -like 'Installed*').Count -eq 2) 'separate per-app installation results'
$calls=@($script:processCalls | Where-Object {$_[0] -eq 'install'})
Check ($calls.Count -eq 2) 'two selected apps get two exact installs'
foreach($a in $calls){Check ($a -contains '--exact' -and $a -contains '--source' -and $a -contains 'winget' -and $a -contains '--no-upgrade') 'exact official source and no incidental upgrade';Check (@($a | Where-Object {$_ -match 'ignore|force|allow-reboot'}).Count -eq 0) 'security and reboot bypass flags absent'}
$script:official=$false;$n=$script:processCalls.Count
Refuses {Install-ManagedTools @('discord')} 'not the official';Check (@($script:processCalls | Select-Object -Skip $n | Where-Object {$_[0] -eq 'install'}).Count -eq 0) 'tampered winget source refused before install'
$script:official=$true;$script:code=1;$r=@(Install-ManagedTools @('epic'));Check ($r[0].Status -like 'Failed*' -and $r[0].Error -match 'exit 1') 'nonzero installation exit reported failed'
$script:code=[BitConverter]::ToInt32([BitConverter]::GetBytes([uint32]::Parse('8A150061',[Globalization.NumberStyles]::HexNumber)),0)
$r=@(Install-ManagedTools @('discord'));Check ($r[0].Status -like 'Installed*') 'already-installed WinGet status accepted only with inventory confirmation'
$script:installed=$false;$r=@(Install-ManagedTools @('discord'));Check ($r[0].Status -like 'Failed*') 'already-installed status not trusted without matching inventory'
Refuses {Install-ManagedTools @('discord','arbitrary-command')} 'Unknown installer'
$script:code=0;$script:installed=$true;$r=@(Install-ManagedTools @('chromium','discord'));Check ($r[0].Status -eq 'Cancelled' -and $r[1].Status -eq 'Not started (cancelled)') 'Chromium cancellation stops remaining apps'
$script:metadataBad=$false
function Invoke-RestMethod {param($Uri,$TimeoutSec);if($Uri -like '*LAST_CHANGE'){'1234567'}else{[pscustomobject]@{bucket=$(if($script:metadataBad){'evil'}else{'chromium-browser-snapshots'});name='Win_x64/1234567/chrome-win.zip';size='1048576';generation='123456789';md5Hash='AAAAAAAAAAAAAAAAAAAAAA=='}}}
$plan=Get-ChromiumPlan;Check ($plan.Url -eq 'https://storage.googleapis.com/chromium-browser-snapshots/Win_x64/1234567/chrome-win.zip?generation=123456789') 'download URL pinned to verified official object generation'
$script:metadataBad=$true;Refuses {Get-ChromiumPlan} 'Unexpected Chromium object'
Add-Type -AssemblyName System.IO.Compression;Add-Type -AssemblyName System.IO.Compression.FileSystem
function Make-Zip($Names,$Name){
 $path=Join-Path $script:ControlRoot ($Name+'.zip');$null=New-Item -ItemType Directory -Path $script:ControlRoot -Force
 $z=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Create)
 try{foreach($entry in $Names){$e=$z.CreateEntry($entry);$writer=[IO.StreamWriter]::new($e.Open());try{$writer.Write('Fixture only; never execute.')}finally{$writer.Dispose()}}}finally{$z.Dispose()};$path
}
$zip=Make-Zip @('chrome-win/chrome.exe','chrome-win/locales/test.pak') 'valid';$dest=Join-Path $script:ControlRoot 'valid-extract';$null=New-Item -ItemType Directory -Path $dest
Expand-ReviewedChromium $zip $dest;Check (Test-Path -LiteralPath (Join-Path $dest 'chrome-win\chrome.exe')) 'valid archive extracts only into fixture destination'
foreach($name in @('chrome-win/../escape.exe','../escape.exe','chrome-win/C:evil.exe','chrome-win\escape.exe')){
 $zip=Make-Zip @('chrome-win/chrome.exe',$name) ([guid]::NewGuid().ToString('N'));$dest=Join-Path $script:ControlRoot ([guid]::NewGuid().ToString('N'));$null=New-Item -ItemType Directory -Path $dest
 Refuses {Expand-ReviewedChromium $zip $dest} 'archive path';Check (@(Get-ChildItem -LiteralPath $dest).Count -eq 0) 'bad path rejected before extraction'
}
$zip=Make-Zip @('chrome-win/chrome.exe','chrome-win/chrome.exe') 'duplicate';Refuses {Expand-ReviewedChromium $zip (Join-Path $script:ControlRoot 'duplicate-extract')} 'duplicate'
$zip=Make-Zip @('chrome-win/data.pak') 'no-exe';Refuses {Expand-ReviewedChromium $zip (Join-Path $script:ControlRoot 'no-exe-extract')} 'does not contain'
Refuses {Assert-InstallerDirectory (Join-Path $script:ControlRoot '..\escape') $script:ControlRoot} 'escaped'
Write-Host ('TOTAL: '+$script:checks+' installer checks. App installers and network downloads mocked; ZIP extraction uses disposable fixtures only.')
