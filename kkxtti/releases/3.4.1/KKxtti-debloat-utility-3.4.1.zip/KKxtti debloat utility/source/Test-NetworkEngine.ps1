$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
. (Join-Path $root 'Control Engine.ps1')
. (Join-Path $root 'Network Engine.ps1')
$script:ControlRoot=Join-Path $PSScriptRoot ('network-tests-'+[guid]::NewGuid().ToString('N'))
$script:checks=0
function Check($condition,$name){if(-not $condition){throw ('FAIL: '+$name)};$script:checks++;Write-Host ('PASS: '+$name)}
function Refuses($block,$pattern){$caught=$false;try{& $block | Out-Null}catch{$caught=$true;Check ($_.Exception.Message -match $pattern) ('rejected: '+$pattern)};Check $caught 'operation refused'}
function Assert-NetworkAdmin {}
$script:adapter=[pscustomobject]@{Name='Ethernet [test]';InterfaceGuid='11111111-2222-3333-4444-555555555555';InterfaceDescription='Fixture adapter';PnPDeviceID='TEST-NOT-A-DEVICE';DriverVersion='1.0';Status='Up';ifIndex=3}
$script:properties=@()
foreach($c in Get-NetworkCatalog){foreach($key in $c.Keys){$script:properties+=[pscustomobject]@{RegistryKeyword=$key;RegistryValue=@($c.Off);ValidRegistryValues=@($c.On,$c.Off);DisplayName=$c.Name;DisplayValue=$c.Off}}}
$script:writeCount=0;$script:restarts=0;$script:failAt=0;$script:ignoreWrite=$false
function Get-PhysicalNetworkAdapters {$script:adapter}
function Get-NetAdapterAdvancedProperty {param($Name,$ErrorAction);Check ($Name -eq 'Ethernet `[test`]') 'adapter name wildcard characters escaped';$script:properties}
function Set-NetAdapterAdvancedProperty {param($InputObject,$RegistryValue,[switch]$NoRestart,$ErrorAction);if(-not $NoRestart){throw 'Unexpected reconnect requested'};$script:writeCount++;if(-not $script:ignoreWrite){$InputObject.RegistryValue=@($RegistryValue)};if($script:failAt -eq $script:writeCount){throw 'Injected driver failure'}}
function Restart-NetAdapter {param($InputObject,$Confirm,$ErrorAction);$script:restarts++}
$id=$script:adapter.InterfaceGuid
# Read escaped selector once, then suppress repetitive selector assertions.
$states=@(Get-NetworkSettingStates $id)
Check ($states.Count -eq 5) 'five reviewed controls enumerated'
function Get-NetAdapterAdvancedProperty {param($Name,$ErrorAction);if($Name -ne 'Ethernet `[test`]'){throw 'Unsafe adapter selector'};$script:properties}
Check (@($states | Where-Object Supported).Count -eq 5) 'supported values detected from driver metadata'
$a=Set-NetworkSettings $id @('nic-rss') $true
Check ($a.Status -eq 'Applied' -and $a.NeedsReconnect) 'RSS saved with reconnect requirement'
Check ($script:restarts -eq 0) 'setting a switch never restarts the adapter'
Check ((Get-NetworkSettingStates $id | Where-Object Id -eq 'nic-rss').State -eq 'On') 'configured network state read back'
$b=Set-NetworkSettings $id @('nic-rss') $false
Refuses {Undo-NetworkSettings $a.Id} 'newer or external'
$null=Undo-NetworkSettings $b.Id
Check ((Get-NetworkSettingStates $id | Where-Object Id -eq 'nic-rss').State -eq 'On') 'undo later switch restores earlier value'
$null=Undo-NetworkSettings $a.Id
Check ((Get-NetworkSettingStates $id | Where-Object Id -eq 'nic-rss').State -eq 'Off') 'undo restores exact original value'
Refuses {Undo-NetworkSettings $a.Id} 'not an applied'
$count=$script:writeCount
Refuses {Set-NetworkSettings $id @('nic-rss','arbitrary-setting') $true} 'Unknown network setting'
Check ($script:writeCount -eq $count) 'invalid batch rejected before any driver write'
$p=$script:properties | Where-Object RegistryKeyword -eq '*UDPChecksumOffloadIPv6'
$old=$p.ValidRegistryValues;$p.ValidRegistryValues=@('0')
Check (-not (Get-NetworkSettingStates $id | Where-Object Id -eq 'nic-checksum').Supported) 'partial unsupported checksum group disabled'
Refuses {Set-NetworkSettings $id @('nic-rss','nic-checksum') $true} 'Unsupported driver value'
Check ($script:writeCount -eq $count) 'unsupported batch changes nothing'
$p.ValidRegistryValues=$old
$script:failAt=$script:writeCount+3
Refuses {Set-NetworkSettings $id @('nic-checksum') $true} 'rolled back'
$script:failAt=0
Check ((Get-NetworkSettingStates $id | Where-Object Id -eq 'nic-checksum').State -eq 'Off') 'mid-group failure rolls all attempted writes back'
$script:ignoreWrite=$true
Refuses {Set-NetworkSettings $id @('nic-rss') $true} 'readback failed'
$script:ignoreWrite=$false
Check ((Get-NetworkSettingStates $id | Where-Object Id -eq 'nic-rss').State -eq 'Off') 'silent write failure is not reported as on'
$a=Set-NetworkSettings $id @('nic-checksum','nic-rss','nic-lso') $true
Check ($a.Count -eq 8) 'baseline stores eight driver properties'
$script:adapter.DriverVersion='2.0'
Refuses {Undo-NetworkSettings $a.Id} 'adapter or driver changed'
$script:adapter.DriverVersion='1.0'
$p=$script:properties | Where-Object RegistryKeyword -eq '*RSS';$p.RegistryValue=@('0')
Refuses {Undo-NetworkSettings $a.Id} 'newer or external'
$p.RegistryValue=@('1')
$null=Undo-NetworkSettings $a.Id
Check (@(Get-NetworkSettingStates $id | Where-Object {$_.Id -in @('nic-rss','nic-checksum','nic-lso') -and $_.State -eq 'Off'}).Count -eq 3) 'whole baseline restores original properties'
$save=${function:Save-ControlJournal}
function Save-ControlJournal($Path,$Journal){throw 'Injected journal failure'}
$count=$script:writeCount
Refuses {Set-NetworkSettings $id @('nic-rss') $true} 'journal failure'
Set-Item Function:Save-ControlJournal $save
Check ($script:writeCount -eq $count) 'journal failure prevents writes'
Refuses {Set-NetworkSettings 'not-a-guid' @('nic-rss') $true} 'Invalid network adapter'
Refuses {Undo-NetworkSettings '..\path'} 'valid network backup'
$null=Restart-SelectedNetworkAdapter $id
Check ($script:restarts -eq 1) 'explicit reconnect targets one adapter'
function Find-NetRoute {param($RemoteIPAddress,$ErrorAction);[pscustomobject]@{InterfaceIndex=3}}
Assert-NetworkProbeRoute $id '1.1.1.1'
Check $true 'probe allows a matching route'
function Find-NetRoute {param($RemoteIPAddress,$ErrorAction);[pscustomobject]@{InterfaceIndex=9}}
Refuses {Assert-NetworkProbeRoute $id '1.1.1.1'} 'different adapter or VPN'
$samples=@(0,10,20 | ForEach-Object {[pscustomobject]@{Status='Success';Milliseconds=$_}})+@([pscustomobject]@{Status='TimedOut';Milliseconds=$null})+@(30,40 | ForEach-Object {[pscustomobject]@{Status='Success';Milliseconds=$_}})
$s=Get-ProbeSummary $samples 'Fixture'
Check ($s.Sent -eq 6 -and $s.Replies -eq 5) 'failed probes stay in denominator'
Check ([math]::Abs($s.LossPercent-16.6666667) -lt .001) 'loss percentage is correct'
Check ($s.MedianMs -eq 20 -and $s.AverageMs -eq 20 -and $s.P95Ms -eq 40) 'median mean and nearest-rank p95 correct'
Check ($s.JitterMs -eq 10) 'jitter excludes gaps across lost probes'
$s=Get-ProbeSummary @([pscustomobject]@{Status='TimedOut';Milliseconds=$null}) 'Fixture'
Check ($s.LossPercent -eq 100 -and $null -eq $s.AverageMs -and $null -eq $s.P95Ms) 'no replies are unavailable, not zero latency'
$s=Get-ProbeSummary @() 'Fixture'
Check ($s.Sent -eq 0 -and $null -eq $s.LossPercent) 'cancelled-before-first-probe is not reported as 100 percent loss'
Write-Host ('TOTAL: '+$script:checks+' checks passed. Adapter operations were mocked; no real network setting changed.')
