param([string]$UtilityPath)
$ErrorActionPreference='Stop'
. $UtilityPath -LibraryOnly
$workRoot = Join-Path $PSScriptRoot ('verification-' + [guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($workRoot)
$script:StateRoot = Join-Path $workRoot 'State'
function Assert($Condition,[string]$Name) { if (-not $Condition) { throw "FAIL: $Name" }; Write-Output "PASS: $Name" }
function Assert-Throws([scriptblock]$Action,[string]$Name) { $threw=$false; try { & $Action } catch { $threw=$true }; Assert $threw $Name }
$guid='{11111111-2222-3333-4444-555555555555}'
$sample="Windows Boot Loader`r`nidentifier $guid`r`nuseplatformclock Yes`r`ndisabledynamictick No`r`nnumproc 16`r`n"
$parsed=ConvertFrom-BootText $sample
Assert ($parsed.Values.useplatformclock -eq 'yes' -and $null -eq $parsed.Values.useplatformtick -and $parsed.Values.numproc -eq '16') 'Boot values and absence parsed'
Assert-Throws { ConvertFrom-BootText "identifier $guid`nuseplatformclock Oui" } 'Unknown/localized BCD value fails closed'
$bad=$parsed | ConvertTo-Json -Depth 5 | ConvertFrom-Json
$bad.Values.numproc='16 & injected'
Assert-Throws { Test-BootState $bad } 'Unsafe saved value rejected'
Assert ((@(Select-Indices '1, 3,1' 4) -join ',') -eq '0,2') 'App selections deduplicated'
Assert-Throws { Select-Indices '0,999' 4 } 'Out-of-range app choices rejected'
Assert-Throws { Select-Indices '1;cmd' 4 } 'Non-numeric app input rejected'
Assert (@($script:AppAllowlist | Where-Object { $_ -match 'WindowsStore|DesktopAppInstaller|GamingServices|SecHealthUI|Client.CBS|VCLibs' }).Count -eq 0) 'Critical apps absent from removal allowlist'

# Native mutation paths below use in-memory doubles only.
function Require-Admin {}
function Require-BootWritable {}
function Confirm-Action { return $true }
$script:FakeBoot=$parsed | ConvertTo-Json -Depth 5 | ConvertFrom-Json
$script:NativeCalls=[Collections.Generic.List[string]]::new()
$script:DeleteCount=0
$script:FailSecondDelete=$false
$script:FailExport=$false
$script:FakePower='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'
function Get-BootState { return ($script:FakeBoot | ConvertTo-Json -Depth 6 | ConvertFrom-Json) }
function Invoke-Native([string]$Name,[string[]]$Arguments) {
 $script:NativeCalls.Add($Name+' '+($Arguments -join ' '))
 if ($Name -eq 'bcdedit.exe') {
  switch ($Arguments[0]) {
   '/export' {
    if ($script:FailExport) {throw 'Simulated backup failure'}
    if (-not $Arguments[1].StartsWith($workRoot,[StringComparison]::OrdinalIgnoreCase)) {throw 'Test path escape'}
    [IO.File]::WriteAllText($Arguments[1],'FAKE BCD BACKUP - TEST ONLY')
   }
   '/deletevalue' {
    $script:DeleteCount++
    if ($script:FailSecondDelete -and $script:DeleteCount -eq 2) {throw 'Simulated native failure'}
    if ($Arguments[2] -notin $script:BootKeys) {throw 'Unknown BCD key'}
    $script:FakeBoot.Values.($Arguments[2])=$null
   }
   '/set' {
    if ($Arguments[2] -notin $script:BootKeys) {throw 'Unknown BCD key'}
    $script:FakeBoot.Values.($Arguments[2])=$Arguments[3]
   }
   default {throw 'Unexpected mock BCD action'}
  }
  return 'OK'
 }
 if ($Name -eq 'powercfg.exe') {
  switch ($Arguments[0]) {
   '/getactivescheme' {return ('Power Scheme GUID: '+$script:FakePower)}
   '/list' {return ($script:FakePower+' 381b4222-f694-41f0-9685-ff5bb260df2e 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee')}
   '/setactive' {$script:FakePower=$Arguments[1]; return 'OK'}
  }
 }
 throw 'Unexpected mock native execution'
}
$desired=$parsed | ConvertTo-Json -Depth 5 | ConvertFrom-Json
foreach ($key in $script:BootKeys) {$desired.Values.$key=$null}
Set-BootState $desired
Assert (@($script:FakeBoot.Values.PSObject.Properties | Where-Object {$null -ne $_.Value}).Count -eq 0) 'Default boot reset changes only recorded overrides'
Set-BootState $parsed
Assert ($script:FakeBoot.Values.useplatformclock -eq 'yes' -and $script:FakeBoot.Values.numproc -eq '16' -and $null -eq $script:FakeBoot.Values.useplatformtick) 'Boot restore preserves values and absence'
$other=$parsed | ConvertTo-Json -Depth 5 | ConvertFrom-Json
$other.BootId='{99999999-2222-3333-4444-555555555555}'
$beforeCount=$script:NativeCalls.Count
Assert-Throws {Set-BootState $other} 'Foreign boot-entry backup blocked'
Assert ($beforeCount -eq $script:NativeCalls.Count) 'Foreign backup executes no native command'
$script:FakeBoot=$parsed | ConvertTo-Json -Depth 5 | ConvertFrom-Json
$script:FailSecondDelete=$true
$script:DeleteCount=0
Assert-Throws {Reset-BootOverrides} 'Failed reset reports failure'
Assert ($script:FakeBoot.Values.useplatformclock -eq 'yes' -and $script:FakeBoot.Values.numproc -eq '16') 'Partial boot failure rolls back changed values'
Assert (@(Get-ChildItem -LiteralPath $script:StateRoot -Recurse -Filter BCD-store.bak).Count -eq 1) 'BCD export exists before attempted edits'
$script:FailSecondDelete=$false
$script:FailExport=$true
$beforeCount=$script:NativeCalls.Count
Assert-Throws {Reset-BootOverrides} 'Failed backup aborts boot reset'
$newCalls=@($script:NativeCalls | Select-Object -Skip $beforeCount)
Assert (@($newCalls | Where-Object {$_ -match '/set|/deletevalue'}).Count -eq 0) 'No boot mutations after failed backup'
$script:FailExport=$false
function Read-Host {return '1'}
Set-TestPowerPlan
Assert ($script:FakePower -eq '381b4222-f694-41f0-9685-ff5bb260df2e') 'Power comparison selects requested plan'
$script:PowerBackup=(Get-ChildItem -LiteralPath $script:StateRoot -Directory | Where-Object Name -like 'power-*' | Select-Object -First 1).FullName
function Select-State {return $script:PowerBackup}
Undo-Power
Assert ($script:FakePower -eq 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee') 'Power Undo restores custom plan exactly'

# Mock app data and removal; never call the actual Appx cmdlets.
$script:RemovedApps=[Collections.Generic.List[string]]::new()
function Get-AppxPackage {
 foreach ($name in @('Microsoft.BingWeather','Microsoft.GetHelp','Microsoft.WindowsStore','Microsoft.GamingServices')) {
  [pscustomobject]@{Name=$name;PackageFullName=($name+'_test');PackageFamilyName=$name;IsFramework=$false;NonRemovable=$false}
 }
 [pscustomobject]@{Name='Microsoft.Getstarted';PackageFullName='Framework_test';PackageFamilyName='Framework';IsFramework=$true;NonRemovable=$false}
 [pscustomobject]@{Name='Microsoft.People';PackageFullName='Protected_test';PackageFamilyName='Protected';IsFramework=$false;NonRemovable=$true}
}
function Remove-AppxPackage([string]$Package,[string]$ErrorAction) {$script:RemovedApps.Add($Package)}
Assert (@(Get-RemovableApps).Count -eq 2) 'App inventory excludes critical, framework and nonremovable packages'
function Read-Host {return '2'}
Remove-SelectedApps
Assert ($script:RemovedApps.Count -eq 1 -and $script:RemovedApps[0] -eq 'Microsoft.GetHelp_test') 'Only explicitly selected package is removed'
$manifest=Get-ChildItem -LiteralPath $script:StateRoot -Recurse -Filter selected-apps.json
Assert ($null -ne $manifest -and (Get-Content -LiteralPath $manifest.FullName -Raw) -match 'Microsoft.GetHelp') 'Selected package manifest saved'
function Read-Host {return 'ALL'}
function Confirm-Action {return $false}
Remove-SelectedApps
Assert ($script:RemovedApps.Count -eq 1) 'Cancelled bulk uninstall removes nothing'

# Check the real bundled runtime hashes, cancel before launching, then test
# the tamper rejection using a fake hash response rather than altering files.
$script:LaunchCount=0
function Start-Process {$script:LaunchCount++}
Open-Inspector
Assert ($script:LaunchCount -eq 0) 'Bundled helper hashes pass and cancellation prevents launch'
function Get-FileHash {return [pscustomobject]@{Hash='INVALID'}}
Assert-Throws {Open-Inspector} 'Changed helper digest is rejected'
Assert ($script:LaunchCount -eq 0) 'Changed helper is never launched'

$temp=Join-Path $workRoot 'TempFixture'
$outside=Join-Path $workRoot 'Outside'
[void][IO.Directory]::CreateDirectory($temp)
[void][IO.Directory]::CreateDirectory($outside)
$old=Join-Path $temp 'old.txt'
$recent=Join-Path $temp 'recent.txt'
$external=Join-Path $outside 'keep.txt'
foreach($file in @($old,$recent,$external)) {[IO.File]::WriteAllText($file,'fixture')}
[IO.File]::SetLastWriteTime($old,(Get-Date).AddDays(-10))
[IO.File]::SetLastWriteTime($external,(Get-Date).AddDays(-10))
$cutoff=(Get-Date).AddDays(-7)
$eligible=@(Get-OldTempFiles $temp $cutoff)
Assert ($eligible.Count -eq 1 -and $eligible[0].FullName -eq $old) 'Temp preview excludes recent files'
Assert (-not (Test-TempPath $temp $external)) 'Cleanup rejects paths outside root'
$link=Join-Path $temp 'outside-link'
[void](New-Item -ItemType Junction -Path $link -Target $outside)
Assert (@(Get-OldTempFiles $temp $cutoff).Count -eq 1) 'Cleanup skips junction traversal'
Assert (-not (Test-TempPath $temp (Join-Path $link 'keep.txt'))) 'Deletion recheck rejects junction path'
Assert ([IO.File]::Exists($external)) 'Outside fixture remains intact'
Write-Output 'All tests finished. No real native mutations or app removals were invoked.'
