#requires -Version 5.1
param([string]$Package=(Split-Path -Parent $PSScriptRoot),[string]$OutputDirectory=$env:TEMP)
$ErrorActionPreference='Stop'
if([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA'){throw 'Run this read-only UI smoke check with powershell.exe -STA.'}
$Package=(Resolve-Path -LiteralPath $Package).Path
$exe=Join-Path $Package 'KKxtti debloat utility.exe'
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
[void][Reflection.Assembly]::LoadFrom($exe)
$code=@'
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
public static class StartupUiCheck {
 static BindingFlags flags=BindingFlags.Instance|BindingFlags.NonPublic;
 static object Field(object o,string n){return o.GetType().GetField(n,flags).GetValue(o);}
 static void Call(object o,string n,params object[] args){o.GetType().GetMethod(n,flags).Invoke(o,args);}
 static void Check(bool ok,string message,List<string> lines){if(!ok)throw new Exception("FAIL: "+message);lines.Add("PASS: "+message);}
 static void Pump(){var frame=new DispatcherFrame();Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,new Action(()=>frame.Continue=false));Dispatcher.PushFrame(frame);Thread.Sleep(20);}
 public static string[] Run(string root,string output) {
  var lines=new List<string>();
  var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};
  var window=new KKxtti.Dashboard(false,true);
  window.GetType().GetField("root",flags).SetValue(window,root);
  string failure=null;
  app.DispatcherUnhandledException+=(s,e)=>{failure=e.Exception.Message;e.Handled=true;};
  var watchdog=new DispatcherTimer{Interval=TimeSpan.FromMilliseconds(100)};
  watchdog.Tick+=(s,e)=>{foreach(Window dialog in window.OwnedWindows){failure="Unexpected dialog: "+dialog.Title;dialog.Close();}};
  try {
   Check(KKxtti.PackageTrust.Prepare(root,message=>false),"verified package starts without a repeated prompt",lines);
   window.ShowActivated=false;window.ShowInTaskbar=false;window.Opacity=0;window.Left=-30000;window.Top=-30000;
   watchdog.Start();window.Show();
   var timeout=Stopwatch.StartNew();
   do {Pump();if(failure!=null)throw new Exception(failure);}while(((bool)Field(window,"busy")||(bool)Field(window,"peripheralBusy"))&&timeout.Elapsed.TotalSeconds<120);
   Check(!(bool)Field(window,"busy")&&!(bool)Field(window,"peripheralBusy"),"dashboard background reads complete",lines);
   string cpu=((TextBlock)Field(window,"heroCpu")).Text,gpu=((TextBlock)Field(window,"gpuTitle")).Text;
   Check(!cpu.Contains("Detecting")&&!cpu.Contains("Unavailable"),"CPU label populated: "+cpu,lines);
   Check(!gpu.Contains("Detecting")&&!gpu.Contains("Unavailable"),"GPU label populated: "+gpu,lines);
   Check(!((TextBlock)Field(window,"powerValue")).Text.Contains("Reading"),"active power label populated",lines);
   Check(((IList)Field(window,"peripherals")).Count>0,"peripheral cards populated",lines);
   window.Dispatcher.BeginInvoke(new Action(()=>Call(window,"Navigate","Performance")));timeout.Restart();
   do {Pump();if(failure!=null)throw new Exception(failure);}while((!(bool)Field(window,"controlsLoaded")||(bool)Field(window,"busy"))&&timeout.Elapsed.TotalSeconds<120);
   Check((bool)Field(window,"controlsLoaded")&&((IList)Field(window,"controls")).Count==104,"Performance displays all 104 switch states",lines);
   Check(((TextBlock)Field(window,"status")).Text.Contains("Finished"),"switch read finishes without an error dialog",lines);
   Check(!(bool)window.GetType().GetMethod("PreviewAllows",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,new object[]{"Set-GamingPowerPlan"}),"read-only preview rejects power-plan mutation",lines);
   Call(window,"Navigate","Dashboard");window.Hide();window.Opacity=1;
   var content=(FrameworkElement)window.Content;content.Measure(new Size(1280,850));content.Arrange(new Rect(0,0,1280,850));content.UpdateLayout();
   var visual=new DrawingVisual();using(var drawing=visual.RenderOpen()){drawing.DrawRectangle(window.Background,null,new Rect(0,0,1280,850));drawing.DrawRectangle(new VisualBrush(content),null,new Rect(0,0,1280,850));}
   var bitmap=new RenderTargetBitmap(1280,850,96,96,PixelFormats.Pbgra32);bitmap.Render(visual);
   var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));
   using(var stream=File.Create(Path.Combine(output,"startup-dashboard-3.4.1.png")))encoder.Save(stream);
   Check(failure==null,"dashboard renders with no startup exception",lines);
   return lines.ToArray();
  } finally {watchdog.Stop();window.GetType().GetField("busy",flags).SetValue(window,false);window.Close();app.Shutdown();}
 }
}
'@
$refs=@($exe,[Windows.Application].Assembly.Location,[Windows.Media.Visual].Assembly.Location,[Windows.Threading.Dispatcher].Assembly.Location,'System.dll','System.Core.dll','System.Xaml.dll')
$tempSource=Join-Path $OutputDirectory ('ui-smoke-'+[guid]::NewGuid().ToString('N')+'.cs')
$tempDll=[IO.Path]::ChangeExtension($tempSource,'.dll')
[IO.File]::WriteAllText($tempSource,$code,[Text.UTF8Encoding]::new($false))
$argsCompiler=@('/nologo','/target:library','/platform:x64',('/out:'+$tempDll))
foreach($reference in $refs){$argsCompiler+=('/reference:'+$reference)}
$argsCompiler+=$tempSource
& (Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe') $argsCompiler
if($LASTEXITCODE -ne 0){throw 'UI smoke harness compilation failed'}
[void][Reflection.Assembly]::LoadFrom($tempDll)
[StartupUiCheck]::Run($Package,$OutputDirectory) | ForEach-Object {Write-Host $_}
Write-Host 'TOTAL: 10 native WPF startup checks; real reads only, no setting actions invoked.'
