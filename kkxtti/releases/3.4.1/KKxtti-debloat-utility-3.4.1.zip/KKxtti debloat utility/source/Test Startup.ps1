#requires -Version 5.1
param([string]$Package=(Split-Path -Parent $PSScriptRoot),[string]$ScratchRoot=$env:TEMP)
$ErrorActionPreference='Stop'
$checks=0
function Check($Value,$Message){if(-not $Value){throw ('FAIL: '+$Message)};$script:checks++;Write-Host ('PASS: '+$Message)}
function Refuses([scriptblock]$Action,[string]$Pattern){$caught=$false;try{& $Action|Out-Null}catch{$caught=$true;Check ($_.Exception.Message -match $Pattern) ('refused '+$Pattern)};Check $caught 'failure surfaced'}
$beforePolicy=Get-ExecutionPolicy -List | ConvertTo-Json -Compress
$fixture=Join-Path $ScratchRoot ('kkxtti-startup-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($fixture)
Get-ChildItem -LiteralPath $Package -Force | Copy-Item -Destination $fixture -Recurse
Add-Type -AssemblyName PresentationFramework
[void][Reflection.Assembly]::LoadFrom((Join-Path $fixture 'KKxtti debloat utility.exe'))
$files=[KKxtti.PackageTrust]::Verify($fixture)
Check ($files.Count -gt 40) 'embedded code/data inventory verifies'
$engine=Join-Path $fixture 'Performance Utility.ps1'
$catalog=Join-Path $fixture 'Control Catalog.json'
$original=[IO.File]::ReadAllBytes($catalog)
$engineHash=(Get-FileHash -LiteralPath $engine).Hash
Set-Content -LiteralPath $engine -Stream Zone.Identifier -Value "[ZoneTransfer]`r`nZoneId=3"
Check ([KKxtti.PackageTrust]::BlockedFiles($files).Count -eq 1) 'NTFS Internet marker detected'
# Reproduce the original failure under the actual RemoteSigned policy.
Check ([KKxtti.PackageTrust]::ReadPolicy() -eq 'RemoteSigned') 'host uses RemoteSigned for the reproduction'
Refuses { [KKxtti.Backend]::Run($fixture,'Get-ControlStates',$null) } 'not digitally signed'
Check (-not [KKxtti.PackageTrust]::Prepare($fixture,[Func[string,bool]]{param($message) $false})) 'declining trust cancels startup'
Check ([KKxtti.PackageTrust]::BlockedFiles($files).Count -eq 1) 'decline leaves download marker intact'
[IO.File]::WriteAllText($catalog,'tampered fixture')
$script:prompts=0
Refuses {[KKxtti.PackageTrust]::Prepare($fixture,[Func[string,bool]]{param($message) $script:prompts++;$true})} 'modified'
Check ($script:prompts -eq 0 -and [KKxtti.PackageTrust]::BlockedFiles([string[]]@($engine)).Count -eq 1) 'tampered package is rejected before prompting or unblocking'
[IO.File]::WriteAllBytes($catalog,$original)
Move-Item -LiteralPath $catalog -Destination ($catalog+'.saved')
Refuses {[KKxtti.PackageTrust]::Verify($fixture)} 'missing'
Move-Item -LiteralPath ($catalog+'.saved') -Destination $catalog
$state=Join-Path $fixture 'State';[void][IO.Directory]::CreateDirectory($state)
$stateFile=Join-Path $state 'fixture.ps1';[IO.File]::WriteAllText($stateFile,'# never execute')
Set-Content -LiteralPath $stateFile -Stream Zone.Identifier -Value "[ZoneTransfer]`r`nZoneId=3"
# Modifications while the prompt is open must be caught by the second check.
Refuses {[KKxtti.PackageTrust]::Prepare($fixture,[Func[string,bool]]{param($message) [IO.File]::WriteAllText($catalog,'changed during prompt');$true})} 'modified'
Check ([KKxtti.PackageTrust]::BlockedFiles([string[]]@($engine)).Count -eq 1) 'changed-during-prompt package remains blocked'
[IO.File]::WriteAllBytes($catalog,$original)
foreach($file in $files){Set-Content -LiteralPath $file -Stream Zone.Identifier -Value "[ZoneTransfer]`r`nZoneId=3"}
Check ([KKxtti.PackageTrust]::BlockedFiles($files).Count -eq $files.Count) 'simulated Explorer extraction marks every packaged input'
Check ([KKxtti.PackageTrust]::Prepare($fixture,[Func[string,bool]]{param($message) $true})) 'accepted verified package is prepared'
Check ([KKxtti.PackageTrust]::BlockedFiles($files).Count -eq 0) 'verified download markers removed'
Check ([KKxtti.PackageTrust]::BlockedFiles([string[]]@($stateFile)).Count -eq 1) 'State content is never unblocked'
Check ((Get-FileHash -LiteralPath $engine).Hash -ceq $engineHash) 'unblocking preserves script contents'
$script:prompts=0
Check ([KKxtti.PackageTrust]::Prepare($fixture,[Func[string,bool]]{param($message) $script:prompts++;$false})) 'subsequent clean startup succeeds'
Check ($script:prompts -eq 0) 'clean startup does not repeat the trust prompt'
Refuses {[KKxtti.PackageTrust]::RequireAllowedPolicy([Microsoft.PowerShell.ExecutionPolicy]::AllSigned)} 'requires signed'
Refuses {[KKxtti.PackageTrust]::RequireAllowedPolicy([Microsoft.PowerShell.ExecutionPolicy]::Restricted)} 'restricted'
Check ((Get-ExecutionPolicy -List|ConvertTo-Json -Compress) -ceq $beforePolicy) 'execution policies unchanged'
$result=[KKxtti.Backend]::Run($fixture,'Get-ControlStates',$null)
Check ($result.Count -eq 104) 'all 104 real switch states load after preparation'
$result=[KKxtti.Backend]::Run($fixture,'Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty Name',$null)
Check ($result.Count -eq 1 -and -not [string]::IsNullOrWhiteSpace($result[0].ToString())) 'real CPU inventory loads'
$result=[KKxtti.Backend]::Run($fixture,'Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name',$null)
Check ($result.Count -ge 1) 'real GPU inventory loads'
$result=[KKxtti.Backend]::Run($fixture,"Invoke-Native 'powercfg.exe' @('/getactivescheme')",$null)
Check ($result.Count -ge 1) 'active power plan is readable'
$result=[KKxtti.Backend]::Run($fixture,'Get-ConnectedPeripherals',$null)
Check ($result.Count -ge 1) 'present peripheral inventory loads'
Check ((Get-ExecutionPolicy -List|ConvertTo-Json -Compress) -ceq $beforePolicy) 'read-only smoke leaves execution policies unchanged'
Write-Host ('TOTAL: '+$checks+' startup checks. Only disposable package files/markers changed; real hardware and switch queries were read-only.')
Write-Host ('Fixture: '+$fixture)
