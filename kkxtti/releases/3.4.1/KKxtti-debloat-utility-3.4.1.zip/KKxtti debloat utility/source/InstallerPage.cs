using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Management.Automation;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;

namespace KKxtti {
 public sealed partial class Dashboard {
  sealed class InstallChoice {public string Id,Name,Package,Publisher,Source,Note,State;public bool Selected;}
  readonly List<InstallChoice> installChoices=new List<InstallChoice>();
  StackPanel installerList;
  TextBlock installSummary;
  Button installButton;
  bool installersLoaded;
  void BuildInstallers(){
   var page=Page("App installer");
   page.Children.Add(Card(Stack(Pill("APPS / VERIFIED SOURCES"),Gap(12),Text("Ready for your next session.",25,null,true),Gap(8),Text("Select Chromium, Discord and Epic Games Launcher. Review each source, then install together. Results are recorded per app.",13,"#A2ABC1")),22));
   page.Children.Add(Gap(16));
   installSummary=Text("Read your installed app inventory to get started.",12,"#A2ABC1");page.Children.Add(installSummary);
   installButton=Btn("Review selected apps",()=>ReviewInstallers(),true);installButton.IsEnabled=false;
   page.Children.Add(Buttons(installButton,Btn("Select all three",()=>{foreach(var c in installChoices)c.Selected=true;RenderInstallers();}),Btn("Clear",()=>{foreach(var c in installChoices)c.Selected=false;RenderInstallers();}),Btn("Refresh inventory",()=>LoadInstallers())));
   installerList=new StackPanel();page.Children.Add(installerList);
   page.Children.Add(Gap(14));page.Children.Add(Card(Stack(Text("Chromium needs manual updates",16,null,true),Gap(8),Text("The Chromium project publishes development snapshots without automatic updating. KKxtti installs an official Win_x64 snapshot and checks its pinned Google object generation, length and MD5 before extraction; it records SHA-256 locally. This establishes download integrity and provenance, not a guarantee of a bug-free browser. Your existing browser data is kept.",13,"#A2ABC1"),Buttons(Btn("Chromium documentation",()=>OpenUri("https://www.chromium.org/getting-involved/download-chromium/")),Btn("Get Microsoft App Installer",()=>OpenUri("ms-windows-store://pdp/?ProductId=9NBLGGH4NNS1")))),20));
  }
  void LoadInstallers(){if(busy)return;Work("Read app installation inventory","Get-InstallerStates",r=>{var selected=new HashSet<string>(installChoices.Where(c=>c.Selected).Select(c=>c.Id));installChoices.Clear();foreach(var p in r)installChoices.Add(new InstallChoice{Id=Value(p,"Id"),Name=Value(p,"Name"),Package=Value(p,"Package"),Publisher=Value(p,"Publisher"),Source=Value(p,"Source"),Note=Value(p,"Note"),State=Value(p,"State"),Selected=selected.Contains(Value(p,"Id"))});installersLoaded=true;RenderInstallers();});}
  void RenderInstallers(){
   installerList.Children.Clear();foreach(var choice in installChoices){var c=choice;var select=new CheckBox{Content="Select for installation",IsChecked=c.Selected,Foreground=muted,HorizontalAlignment=HorizontalAlignment.Left,Margin=new Thickness(0,0,0,8)};AutomationProperties.SetName(select,"Install "+c.Name);select.Checked+=(s,e)=>{c.Selected=true;UpdateInstallerSelection();};select.Unchecked+=(s,e)=>{c.Selected=false;UpdateInstallerSelection();};
    var card=Card(Stack(Text(c.Name,20,null,true),Gap(6),Text(c.State+"  ·  "+c.Publisher,11,"#C5B3E8"),Gap(10),Text(c.Note,13,"#A2ABC1"),Gap(12),select,Buttons(Btn("Official site",()=>OpenUri(c.Source)))),20);card.Margin=new Thickness(0,0,0,12);installerList.Children.Add(card);
   }UpdateInstallerSelection();
  }
  void UpdateInstallerSelection(){int count=installChoices.Count(c=>c.Selected);installButton.IsEnabled=count>0;installButton.Content="Review selected apps ("+count+")";installSummary.Text=count+" selected  ·  No apps install until you confirm  ·  WinGet security checks stay enabled";}
  void ReviewInstallers(){
   if(busy)return;var selected=installChoices.Where(c=>c.Selected).ToArray();if(selected.Length==0)return;
   if(!Review("Install "+selected.Length+" app(s)","Confirmation accepts the selected package and Microsoft WinGet source license agreements. Apps can show their own UAC or installer prompts. No automatic reboot is requested. Existing installed WinGet apps are not upgraded by this action. Chromium has an additional manual-update acknowledgement.",selected.Select(c=>c.Name+" / "+c.Package+"\n"+c.Source+"\n"+c.Note).ToArray(),"Install selected apps"))return;
   Work("Install selected apps","Install-ManagedTools -Ids $InstallerIds",r=>{foreach(var p in r)Log(Value(p,"Id")+": "+Value(p,"Status")+" "+Value(p,"Error"));Notice("Installation results",String.Join("\n\n",r.Select(p=>Value(p,"Id")+" / "+Value(p,"Status")+(Value(p,"Error").Length>0?"\n"+Value(p,"Error"):""))));installersLoaded=false;Dispatcher.BeginInvoke(new Action(()=>LoadInstallers()));},null,new Dictionary<string,object>{{"InstallerIds",selected.Select(c=>c.Id).ToArray()}});
  }
 }
}
