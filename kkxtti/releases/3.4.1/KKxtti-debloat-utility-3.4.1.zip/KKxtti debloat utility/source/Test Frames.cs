using System;
using System.IO;
using System.Linq;
using KKxtti;
class FrameTests {
 static int n; static void Check(bool ok,string name){if(!ok)throw new Exception(name);n++;Console.WriteLine("PASS: "+name);}
 static void Refuses(Action action,string name){bool caught=false;try{action();}catch{caught=true;}Check(caught,name);}
 static void Main(string[] args){string dir=args[0];Directory.CreateDirectory(dir);string p=Path.Combine(dir,"frames.csv");
 var equal=FrameAnalysis.Summarize(new[]{4.0,4.0,4.0,4.0},240);Check(equal.AverageFps==250&&equal.SlowestOnePercentFps==250,"constant cadence yields 250 FPS");Check(equal.OverBudgetPercent==0,"frames under budget");
 var tail=FrameAnalysis.Summarize(Enumerable.Repeat(4.0,99).Concat(new[]{40.0}),240);Check(tail.P99Ms==4&&tail.MaxMs==40&&tail.SlowestOnePercentFps==25,"1 percent low distinct from reciprocal p99");Check(tail.OverBudgetPercent==1,"one slow frame misses budget");Check(Math.Abs(tail.AverageFps-1000.0/4.36)<0.0001,"average from mean milliseconds");
 var even=FrameAnalysis.Summarize(new[]{1.0,3.0,5.0,7.0},240);Check(even.MedianMs==4&&even.P95Ms==7,"median and nearest-rank percentile");
 Refuses(()=>FrameAnalysis.Summarize(new[]{0.0,4.0},240),"zero intervals rejected");Refuses(()=>FrameAnalysis.Summarize(new[]{Double.NaN,4.0},240),"NaN rejected");Refuses(()=>FrameAnalysis.Summarize(new[]{Double.PositiveInfinity,4.0},240),"infinity rejected");Refuses(()=>FrameAnalysis.Summarize(new[]{4.0},240),"insufficient frames rejected");Refuses(()=>FrameAnalysis.Summarize(new[]{4.0,5.0},Double.NaN),"invalid target rejected");
 File.WriteAllText(p,"Application,ProcessID,SwapChainAddress,MsBetweenPresents,Unused\r\n\"Game, client.exe\",12,0x1,4,\"quoted \"\"text\"\"\"\r\n\"Game, client.exe\",12,0x1,5,\"two\r\nlines\"\r\nGame.exe,13,0x1,8,x\r\nGame.exe,13,0x2,9,x\r\nGame.exe,13,0x2,0,x\r\nGame.exe,13,0x2,NaN,x\r\nwrong,row\r\n");
 var file=FrameAnalysis.Read(p,"MsBetweenPresents");Check(file.Streams.Count==3,"process and swapchain grouping");Check(file.Streams[0].Application=="Game, client.exe"&&file.Streams[0].Intervals.Count==2,"quoted CSV and embedded newline parsed");Check(file.Rejected==3,"invalid and malformed rows counted");Check(file.Rows==7,"logical CSV rows counted");
 Refuses(()=>FrameAnalysis.Read(p,"FrameTime"),"missing metric rejected");Refuses(()=>FrameAnalysis.Read(p,"arbitrary"),"unsupported metric rejected");
 File.WriteAllText(p,"FrameTime,FrameTime\n4,5\n");Refuses(()=>FrameAnalysis.Read(p,"FrameTime"),"duplicate headers rejected");File.WriteAllText(p,"FrameTime\n0\nNaN\n");Refuses(()=>FrameAnalysis.Read(p,"FrameTime"),"no valid data rejected");
 File.WriteAllText(p,"FrameTime\n4.5\n5.5\n");var previous=System.Globalization.CultureInfo.CurrentCulture;System.Globalization.CultureInfo.CurrentCulture=new System.Globalization.CultureInfo("de-DE");try{Check(FrameAnalysis.Read(p,"FrameTime").Streams[0].Intervals[0]==4.5,"CSV parsing independent of Windows decimal locale");}finally{System.Globalization.CultureInfo.CurrentCulture=previous;}
 File.WriteAllText(Path.Combine(dir,"sample-baseline.csv"),"Application,ProcessID,SwapChainAddress,MsBetweenPresents\n"+String.Join("\n",Enumerable.Range(0,3000).Select(i=>"TEST FIXTURE.exe,1,0x1,"+(i%200==0?"25":"4"))));
 File.WriteAllText(Path.Combine(dir,"sample-changed.csv"),"Application,ProcessID,SwapChainAddress,MsBetweenPresents\n"+String.Join("\n",Enumerable.Range(0,3000).Select(i=>"TEST FIXTURE.exe,2,0x1,"+(i%200==0?"20":"3.8"))));
 Console.WriteLine("Frame analysis: "+n+" checks passed. Synthetic inputs only.");
 }
}
