$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
. (Join-Path $root 'Control Engine.ps1')
. (Join-Path $root 'Game Engine.ps1')
$script:ControlRoot=Join-Path $PSScriptRoot ('game-tests-'+[guid]::NewGuid().ToString('N'))
$null=New-Item -ItemType Directory -Path $script:ControlRoot
$script:fixture=Join-Path $script:ControlRoot 'GameUserSettings.ini'
$script:checks=0
function Check($condition,$name){if(-not $condition){throw ('FAIL: '+$name)};$script:checks++;Write-Host ('PASS: '+$name)}
function Refuses($block,$pattern){$caught=$false;try{& $block | Out-Null}catch{$caught=$true;Check ($_.Exception.Message -match $pattern) ('rejected: '+$pattern)};Check $caught 'operation refused'}
function Get-GameConfigs {[pscustomobject]@{Id='fortnite';Name='Fixture';Path=$script:fixture;Game='fortnite'}}
function Assert-GameClosed($Game){if($script:running){throw 'Close the game first.'}}
$original="; Fixture comment`r`n[/Script/FortniteGame.FortGameUserSettings]`r`nbUseVSync=False`r`nFrameRateLimit=0.000000`r`nbShowFPS=True`r`nMouseSensitivity=0.15`r`n[Other]`r`nFrameRateLimit=13`r`n"
[IO.File]::WriteAllText($script:fixture,$original,[Text.UTF8Encoding]::new($true))
$before=[IO.File]::ReadAllBytes($script:fixture)
$states=@(Get-GameState 'fortnite');Check ($states.Count -eq 3) 'three supported Fortnite settings'
$nochange=Set-GameSetting 'fortnite' 'fps-cap' '0';Check ($nochange.Status -eq 'Already configured') 'numeric equivalent is a no-op'
$change=Set-GameSetting 'fortnite' 'fps-cap' '240'
Check ($change.Status -eq 'Applied') 'cap saved'
$after=[IO.File]::ReadAllText($script:fixture)
Check ($after.Contains("FrameRateLimit=240`r`n")) 'correct section cap changed'
Check ($after.Contains("[Other]`r`nFrameRateLimit=13")) 'other section preserved'
Check ($after.Contains('MouseSensitivity=0.15')) 'sensitivity preserved'
Check ([IO.File]::ReadAllBytes($script:fixture)[0] -eq 239) 'UTF8 BOM preserved'
Check (Test-Path -LiteralPath (Join-Path $script:ControlRoot ('State\'+$change.Id+'\before.ini'))) 'full original file backed up'
Undo-GameSetting $change.Id | Out-Null
Check ((Get-BytesHash ([IO.File]::ReadAllBytes($script:fixture))) -eq (Get-BytesHash $before)) 'undo restores original bytes'
$change=Set-GameSetting 'fortnite' 'vsync' 'True'
$text=[IO.File]::ReadAllText($script:fixture).Replace('MouseSensitivity=0.15','MouseSensitivity=0.27')
[IO.File]::WriteAllText($script:fixture,$text,[Text.UTF8Encoding]::new($true))
Undo-GameSetting $change.Id | Out-Null
Check ([IO.File]::ReadAllText($script:fixture).Contains('MouseSensitivity=0.27')) 'undo preserves later unrelated change'
$change=Set-GameSetting 'fortnite' 'fps-cap' '300'
$text=[IO.File]::ReadAllText($script:fixture).Replace('FrameRateLimit=300','FrameRateLimit=360')
[IO.File]::WriteAllText($script:fixture,$text,[Text.UTF8Encoding]::new($true))
Refuses {Undo-GameSetting $change.Id} 'newer change'
Check ([IO.File]::ReadAllText($script:fixture).Contains('FrameRateLimit=360')) 'conflict leaves file unchanged'
Refuses {Set-GameSetting 'fortnite' 'fps-cap' '999'} 'supported frame cap'
Refuses {Set-GameSetting 'fortnite' 'fps-cap' 'NaN'} 'Invalid saved'
Refuses {Set-GameSetting 'fortnite' 'path' 'C:\'} 'Unsupported'
Refuses {Set-GameSetting '../escape' 'fps-cap' '240'} 'Invalid game'
Refuses {Undo-GameSetting '../escape'} 'Invalid game backup'
$script:running=$true
Refuses {Set-GameSetting 'fortnite' 'vsync' 'True'} 'Close the game'
$script:running=$false
$item=Get-Item -LiteralPath $script:fixture;$item.IsReadOnly=$true
try{Refuses {Set-GameSetting 'fortnite' 'vsync' 'True'} 'read-only'}finally{$item.IsReadOnly=$false}
[IO.File]::WriteAllText($script:fixture,$original+"[/Script/FortniteGame.FortGameUserSettings]`r`nFrameRateLimit=20`r`n")
Refuses {Set-GameSetting 'fortnite' 'fps-cap' '240'} 'Expected one existing'
foreach($encoding in @([Text.UTF8Encoding]::new($false),[Text.UnicodeEncoding]::new($false,$true),[Text.UnicodeEncoding]::new($true,$true))){[IO.File]::WriteAllText($script:fixture,$original,$encoding);$before=[IO.File]::ReadAllBytes($script:fixture);$change=Set-GameSetting 'fortnite' 'show-fps' 'False';Undo-GameSetting $change.Id | Out-Null;Check ((Get-BytesHash ([IO.File]::ReadAllBytes($script:fixture))) -eq (Get-BytesHash $before)) ('encoding exact restore: '+$encoding.WebName)}
Write-Host ('Game engine: '+$script:checks+' checks passed. Only fixture files were modified.')
