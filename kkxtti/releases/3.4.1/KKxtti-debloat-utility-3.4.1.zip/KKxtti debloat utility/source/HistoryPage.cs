using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;

namespace KKxtti {
 public sealed partial class Dashboard {
  sealed class SavedRecord {public DirectoryInfo Folder;public string Kind,Status,Detail;public bool CanUndo,NeedsRecovery;}
  SavedRecord[] ReadSavedRecords() {
   var rows=new List<SavedRecord>();
   foreach(var dir in SavedFolders()) {
    var record=new SavedRecord{Folder=dir,Kind=dir.Name.Split('-')[0],Status="Saved files",Detail="Open this folder to inspect its contents."};
    string transaction=System.IO.Path.Combine(dir.FullName,"transaction.json");
    try {
     if((dir.Attributes&FileAttributes.ReparsePoint)!=0)continue;
     if(File.Exists(transaction)) {
      var file=new FileInfo(transaction);if(file.Length>2000000||(file.Attributes&FileAttributes.ReparsePoint)!=0)throw new InvalidDataException("Invalid record size or link.");
      var json=new JavaScriptSerializer{MaxJsonLength=2000000};var data=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(transaction));
      object raw;record.Status=data.TryGetValue("Status",out raw)?Convert.ToString(raw):"Unknown";
      record.CanUndo=record.Status=="Applied"&&new[]{"settings","network","game","system","ultimate","dns","nvidia","fortnite"}.Contains(record.Kind);
      record.NeedsRecovery=new[]{"Prepared","Undoing","Recovery needed"}.Contains(record.Status)&&new[]{"settings","network","game","system","ultimate","dns","nvidia","fortnite"}.Contains(record.Kind);
      record.Detail=record.Kind=="apps"?"Removal record only; app data was not backed up.":record.Kind=="install"?"App installation results. Use Installed apps to uninstall; no automatic undo.":record.Kind=="decryption"?"Decryption request. Monitor BitLocker; no automatic encryption undo.":record.Kind=="latency"?"Network measurement record; no system change.":record.Kind=="dns"?"Adapter DNS modes and server lists. Restore needs administrator access.":record.Kind=="network"?"Adapter configuration. Restore may require reconnecting.":record.Kind=="nvidia"?"Saved per-game NVIDIA overrides. Close the game and other profile editors before Reset.":record.Kind=="fortnite"?"Saved Fortnite graphics values. Close Fortnite before Reset.":record.Kind=="game"?"Game setting. Close the game before restoring.":record.Kind=="system"?"Optional system control. Restore needs administrator access.":record.Kind=="ultimate"?"Original active plan and utility-created test plan. Restore needs administrator access.":"Windows preferences. Undo preserves the saved original values.";
     } else if(File.Exists(System.IO.Path.Combine(dir.FullName,"before.json"))&&(record.Kind=="power"||record.Kind=="boot")){record.CanUndo=true;record.Status="Snapshot";record.Detail="Legacy "+record.Kind+" snapshot. Review before restoring.";}
    }catch{record.Status="Unreadable record";record.Detail="Inspect the files manually; automatic restore is unavailable.";record.CanUndo=false;record.NeedsRecovery=false;}
    rows.Add(record);
   }
   return rows.ToArray();
  }
  void RefreshBackupCount() {
   var rows=ReadSavedRecords();int undo=rows.Count(r=>r.CanUndo),recovery=rows.Count(r=>r.NeedsRecovery);
   backupValue.Text=recovery>0?recovery+" change(s) need recovery review":undo>0?undo+" saved change"+(undo==1?"":"s")+" can be restored":"No active changes saved";
  }
  void RefreshBackups() {
   backupsList.Children.Clear();RefreshBackupCount();var records=ReadSavedRecords();
   if(records.Length==0){backupsList.Children.Add(Card(Stack(Text("Your saved changes will appear here",17,null,true),Gap(8),Text("Switches, game settings and adapter changes create an undo. Measurements and app removals create records with their own status.",13,"#A2ABC1"))));return;}
   foreach(var record in records) {
    var r=record;var row=new DockPanel();var actions=new WrapPanel{MaxWidth=290};actions.Children.Add(Btn("Open files",()=>OpenUri(r.Folder.FullName)));
    if(r.CanUndo){var restore=Btn("Restore",()=>{if(r.Kind=="settings")UndoSettings(r.Folder.Name);else if(r.Kind=="network")UndoNetwork(r.Folder.Name);else if(r.Kind=="game")UndoGame(r.Folder.Name);else if(r.Kind=="system")UndoSystem(r.Folder.Name);else if(r.Kind=="ultimate")UndoUltimate(r.Folder.Name);else if(r.Kind=="dns")UndoDns(r.Folder.Name);else if(r.Kind=="nvidia")UndoNvidia(r.Folder.Name);else if(r.Kind=="fortnite")UndoPotato(r.Folder.Name);else RestoreFolder(r.Folder.FullName,r.Kind);});restore.Margin=new Thickness(8,0,0,0);actions.Children.Add(restore);}
    if(r.NeedsRecovery){var recover=Btn("Review recovery",()=>ReviewRecovery(r.Folder.Name),true);recover.Margin=new Thickness(8,0,0,0);actions.Children.Add(recover);}
    DockPanel.SetDock(actions,Dock.Right);row.Children.Add(actions);var label=Text(r.Folder.Name,12,null,true);label.Margin=new Thickness(0,0,12,0);row.Children.Add(Stack(label,Gap(6),Text(r.Status+"  ·  "+r.Folder.LastWriteTime.ToString("dd MMM yyyy  HH:mm"),11,r.NeedsRecovery?"#FFC79F":"#C5B3E8"),Gap(5),Text(r.Detail,11,"#8F9BB5")));
    var card=Card(row,17);card.Margin=new Thickness(0,0,0,10);backupsList.Children.Add(card);
   }
  }
  void ReviewRecovery(string id) {
   if(id.StartsWith("nvidia-")){UndoNvidia(id);return;}
   if(id.StartsWith("fortnite-")){UndoPotato(id);return;}
   if(id.StartsWith("system-")){UndoSystem(id);return;}
   if(id.StartsWith("dns-")){UndoDns(id);return;}
   if(id.StartsWith("ultimate-")){UndoUltimate(id);return;}
   if(busy)return;Work("Inspect interrupted change","Get-RecoveryPlan -Id $RecoveryId",r=>{
    bool conflict=r.Any(p=>Value(p,"Action")=="Conflict - stop");string[] lines=r.Select(p=>Value(p,"Key")+"  /  "+Value(p,"Action")).ToArray();
    Dispatcher.BeginInvoke(new Action(()=>{if(conflict){Notice("Recovery needs your review","A setting no longer matches either saved value. No changes were made. Inspect the saved files and current settings.\n\n"+String.Join("\n",lines));return;}
     if(!Review("Recover an interrupted change","Restore the original values for this transaction. Values already original stay as they are. The app checks again before writing. Network recovery requires administrator access and a later reconnect; game recovery requires the game closed.",lines,"Restore original values"))return;
     if(id.StartsWith("network-")&&!RequireAdmin())return;Work("Recover interrupted change","Restore-InterruptedChange -Id $RecoveryId",v=>{controlsLoaded=false;networkLoaded=false;gameLoaded=false;},null,new Dictionary<string,object>{{"RecoveryId",id}});
    }));
   },null,new Dictionary<string,object>{{"RecoveryId",id}});
  }
 }
}
