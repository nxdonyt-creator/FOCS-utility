using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace KKxtti {
 public sealed partial class Dashboard {
  StackPanel registryReviewList;
  TextBlock registryReviewSummary;
  void BuildRegistryReview(StackPanel page) {
   registryReviewSummary=Text("Inspect 12 registry values discussed in the video. Presence alone does not establish a problem or a performance gain.",12,"#A2ABC1");
   registryReviewList=new StackPanel();
   var details=new Expander{Header="Current values and review",Foreground=ink,Margin=new Thickness(0,12,0,0),Content=registryReviewList};
   page.Children.Add(Card(Stack(Pill("NEW IN 3.3 / REGISTRY REVIEW"),Gap(12),Text("Review the claim. Measure the result.",22,null,true),Gap(9),registryReviewSummary,
    Buttons(Btn("Inspect registry values",()=>{details.IsExpanded=true;LoadRegistryReview();},true),Btn("Review MMCSS 10% comparison",()=>ReviewMmcssComparison()),Btn("Compare frame times",()=>Navigate("Benchmarks")),Btn("Read video review",()=>OpenLocal("VIDEO REVIEW.txt")),Btn("All 104 tweak decisions",()=>OpenLocal("TWEAK AUDIT.html"))),details),20));
   page.Children.Add(Gap(18));
  }
  void LoadRegistryReview() {
   Work("Inspect video registry values","Get-VideoRegistryReview",result=>{
    registryReviewList.Children.Clear();
    foreach(var item in result){
     string source=Value(item,"Source");
     var card=Card(Stack(Text(Value(item,"Name"),15,null,true),Gap(6),Text(Value(item,"Current"),12,"#C9B5FF"),Gap(6),Text(Value(item,"Decision")+" / "+Value(item,"Status"),11,"#A2ABC1"),Gap(6),Text(Value(item,"Note"),12,"#A2ABC1"),Gap(6),Text(Value(item,"Path"),10,"#8F9BB5"),Buttons(Btn("Source",()=>OpenUri(source)))),14);
     card.Margin=new Thickness(0,0,0,9);registryReviewList.Children.Add(card);
    }
    int failed=result.Count(item=>Value(item,"Status")=="Read failed");
    registryReviewSummary.Text=result.Count+" values inspected / "+failed+" unavailable. This inspection reads settings; use a repeatable game capture to assess performance.";
   });
  }
  void ReviewMmcssComparison() {
   if(readOnlyPreview){Notice("Read-only preview","Settings changes are disabled in this testing session.");return;}
   if(busy)return;
   if(!controlsLoaded){Work("Read comparison control","Get-ControlStates",result=>{ReadControls(result);RenderControls();Dispatcher.BeginInvoke(new Action(ReviewMmcssComparison));});return;}
   ReviewPreset("MMCSS scheduling comparison",new[]{"mmcss-reservation"});
  }
 }
}
