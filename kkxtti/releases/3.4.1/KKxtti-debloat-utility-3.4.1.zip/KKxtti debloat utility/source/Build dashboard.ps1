﻿#requires -Version 5.1
param([string]$OutputPath)
$ErrorActionPreference='Stop'
if(-not $OutputPath){$OutputPath=Join-Path (Split-Path -Parent $PSScriptRoot) 'KKxtti debloat utility.exe'}
$framework=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$compiler=Join-Path $framework 'csc.exe'
$automation=Get-ChildItem -LiteralPath (Join-Path $env:WINDIR 'Microsoft.NET\assembly\GAC_MSIL\System.Management.Automation') -Recurse -Filter System.Management.Automation.dll | Select-Object -First 1 -ExpandProperty FullName
if(-not $automation){throw 'Windows PowerShell 5.1 assembly not found.'}
$references=@('System.dll','System.Web.Extensions.dll','System.Core.dll','System.Xaml.dll',(Join-Path $framework 'Microsoft.VisualBasic.dll'),"$framework\WPF\WindowsBase.dll","$framework\WPF\PresentationCore.dll","$framework\WPF\PresentationFramework.dll",$automation)
$arguments=@('/nologo','/target:winexe','/platform:x64','/optimize+',('/out:'+$OutputPath),('/win32manifest:'+(Join-Path $PSScriptRoot 'app.manifest')))
foreach($reference in $references){$arguments+=('/reference:'+$reference)}
$arguments+='/reference:System.Windows.Forms.dll'
$arguments+='/reference:System.Drawing.dll'
$arguments+=(Join-Path $PSScriptRoot 'Dashboard.cs')
$arguments+=(Join-Path $PSScriptRoot 'AssemblyInfo.cs')
$arguments+=(Join-Path $PSScriptRoot 'ControlCenter.cs')
$arguments+=(Join-Path $PSScriptRoot 'NetworkPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'FrameAnalysis.cs')
$arguments+=(Join-Path $PSScriptRoot 'BenchmarkPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'GamePage.cs')
$arguments+=(Join-Path $PSScriptRoot 'HistoryPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'SystemPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'InstallerPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'NvidiaApi.cs')
$arguments+=(Join-Path $PSScriptRoot 'ProfilePage.cs')
$arguments+=(Join-Path $PSScriptRoot 'PeripheralPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'RegistryReviewPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'PackageTrust.cs')
# Bind packaged executable code/data to this build; exclude the main EXE to
# avoid circular hashes. The external launcher verifies the complete archive.
$packageRoot=Split-Path -Parent $PSScriptRoot
$extensions=@('.ps1','.psm1','.psd1','.ps1xml','.cs','.json','.dll','.exe','.config','.xaml','.cmd')
$mainExe=Join-Path $packageRoot 'KKxtti debloat utility.exe'
$inputs=@(Get-ChildItem -LiteralPath $packageRoot -Recurse -File | Where-Object {
 $_.Extension -in $extensions -and $_.FullName -ne $mainExe -and $_.FullName -ne $OutputPath -and $_.FullName -notlike ($packageRoot+'\State\*')
} | Sort-Object FullName)
$records=@($inputs | ForEach-Object {(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash+'  '+$_.FullName.Substring($packageRoot.Length+1).Replace('\','/')})
$resource=[IO.Path]::GetTempFileName()
try {
 [IO.File]::WriteAllLines($resource,$records,[Text.UTF8Encoding]::new($false))
 $arguments+=('/resource:'+$resource+',KKxtti.RuntimeHashes')
 & $compiler $arguments
 if($LASTEXITCODE -ne 0){throw 'Dashboard compilation failed.'}
} finally {Remove-Item -LiteralPath $resource -Force}
