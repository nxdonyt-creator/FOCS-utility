using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Management.Automation;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;
using System.Windows.Media;

namespace KKxtti {
 public sealed partial class Dashboard {
  sealed class GameProfile {public string Id,Name,Game;public override string ToString(){return Name;}}
  ComboBox gameProfile,gameCap;StackPanel gameSettings;TextBlock gameNote;bool gameLoaded,gameLoading;
  void BuildGames() {
   var page=Page("Games");
   BuildPotatoProfile(page);
   page.Children.Add(Columns(new UIElement[]{InfoCard("Fortnite","Compare the current Performance renderer, warm shaders and Reflex. Change caps below without editing an INI by hand.","COMPETITIVE PLAYBOOK",Btn("Fortnite starting profile",()=>ShowGame(false))),InfoCard("Rainbow Six Siege","Keep the resolution and sensitivity you prefer. Compare caps in representative scenes and preserve required anti-cheat security features.","COMPETITIVE PLAYBOOK",Btn("Siege starting profile",()=>ShowGame(true)))}));page.Children.Add(Gap(20));
   page.Children.Add(Text("Your saved game settings",21,null,true));page.Children.Add(Gap(8));page.Children.Add(Text("Close the game before changing a setting. KKxtti edits only existing reviewed keys, saves their previous values, and preserves your other preferences.",13,"#A2ABC1"));page.Children.Add(Gap(12));
   gameProfile=new ComboBox{Height=38,Padding=new Thickness(9,6,9,6),Foreground=Brushes.Black};AutomationProperties.SetName(gameProfile,"Installed game profile");gameProfile.SelectionChanged+=(s,e)=>{if(!gameLoading&&!busy)LoadGameSettings();};
   page.Children.Add(Columns(new UIElement[]{gameProfile,Btn("Refresh games",()=>LoadGames())},4,1));page.Children.Add(Gap(14));gameNote=Text("Read a game profile to see its current settings.",12,"#A2ABC1");page.Children.Add(gameNote);page.Children.Add(Gap(12));gameSettings=new StackPanel();page.Children.Add(gameSettings);
   page.Children.Add(Gap(18));page.Children.Add(InfoCard("A cap you can sustain","Choose caps using this PC\u0027s actual display, sync mode and demanding scenes. Compare a sustainable cap with unlimited; no fixed cap is recommended for every setup.","TEST ONE CHANGE",Btn("Compare frame times",()=>Navigate("Benchmarks"),true),Btn("Restore a saved change",()=>Navigate("Backups")),Btn("Full gaming guide",()=>OpenLocal("GAMING GUIDE.txt"))));
  }
  void LoadGames() {
   if(busy)return;var previous=gameProfile.SelectedItem as GameProfile;Work("Find game configurations","Get-GameConfigs",r=>{gameLoading=true;gameProfile.Items.Clear();foreach(var p in r)gameProfile.Items.Add(new GameProfile{Id=Value(p,"Id"),Name=Value(p,"Name"),Game=Value(p,"Game")});gameProfile.SelectedItem=gameProfile.Items.Cast<GameProfile>().FirstOrDefault(g=>previous!=null&&g.Id==previous.Id)??gameProfile.Items.Cast<GameProfile>().FirstOrDefault();gameLoading=false;gameLoaded=true;Dispatcher.BeginInvoke(new Action(()=>LoadGameSettings()));});
  }
  void LoadGameSettings() {
   if(busy)return;gameSettings.Children.Clear();var g=gameProfile.SelectedItem as GameProfile;if(g==null){gameNote.Text="No supported configuration found. Start and close Fortnite or Siege once, then refresh.";return;}
   Work("Read game settings","Get-GameState -GameId $GameId",r=>RenderGameSettings(g,r),null,new Dictionary<string,object>{{"GameId",g.Id}});
  }
  void RenderGameSettings(GameProfile g,Collection<PSObject> r) {
   gameSettings.Children.Clear();gameNote.Text="Saved configuration for "+g.Name+". The game or cloud sync can rewrite it; verify in-game after launch.";
   foreach(var p in r.Where(v=>Value(v,"Id")!="fps-cap")) {
    string id=Value(p,"Id"),current=Value(p,"Value"),label=id=="vsync"?"V-Sync":"Show FPS counter";bool available=Value(p,"Available")=="True",enabled=current=="True"||current=="1"||current=="2";
    var toggle=new ToggleButton{Width=48,Height=26,IsChecked=enabled,IsEnabled=available,Style=(Style)XamlReader.Parse(SwitchStyle)};AutomationProperties.SetName(toggle,g.Name+" "+label);
    toggle.Click+=(s,e)=>{bool value=toggle.IsChecked==true;toggle.IsChecked=enabled;if(!busy)SaveGameSetting(g.Id,id,g.Game=="fortnite"?(value?"True":"False"):(value?"1":"0"),label);};
    var head=new DockPanel();DockPanel.SetDock(toggle,Dock.Right);head.Children.Add(toggle);head.Children.Add(Text(label,16,null,true));
    string explanation=id=="vsync"?"Off is the starting point for your adaptive-sync-off competitive setup; tearing is possible. On favors synchronization and can add latency.":"Display the game's FPS counter. This does not measure end-to-end input latency.";
    var card=Card(Stack(head,Gap(9),Text(explanation,12,"#A2ABC1"),Gap(7),Text("Current: "+current,11,"#C9B5FF")),17);card.Margin=new Thickness(0,0,0,10);gameSettings.Children.Add(card);
   }
   var cap=r.FirstOrDefault(v=>Value(v,"Id")=="fps-cap");bool capAvailable=cap!=null&&Value(cap,"Available")=="True";
   gameCap=new ComboBox{Height=37,Padding=new Thickness(8,5,8,5),Foreground=Brushes.Black};AutomationProperties.SetName(gameCap,"Game FPS cap");foreach(int n in new[]{0,120,144,165,180,200,240,300,360,480})gameCap.Items.Add(n==0?"Unlimited":n.ToString());gameCap.SelectedIndex=0;
   if(capAvailable){double value;if(Double.TryParse(Value(cap,"Value"),System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out value)){string item=value==0?"Unlimited":value.ToString("0",System.Globalization.CultureInfo.InvariantCulture);if(gameCap.Items.Contains(item))gameCap.SelectedItem=item;else gameCap.SelectedIndex=-1;}}
   var apply=Btn("Save cap",()=>{string value=gameCap.SelectedItem as string;if(value!=null)SaveGameSetting(g.Id,"fps-cap",value=="Unlimited"?"0":value,"Game frame cap");},true);apply.IsEnabled=capAvailable;
   gameSettings.Children.Add(Card(Stack(Text("Frame-rate limit",17,null,true),Gap(8),Text("Current: "+(cap==null?"Unavailable":Value(cap,"Value"))+"  ·  0 means unlimited. Choose one limiter; check for an additional NVIDIA driver cap.",12,"#A2ABC1"),Gap(12),Columns(new UIElement[]{gameCap,apply},3,1)),17));
  }
  void SaveGameSetting(string game,string field,string value,string label) {
   if(busy)return;Work(label,"Set-GameSetting -GameId $GameId -Field $GameField -Value $GameValue",r=>{Log(label+": "+(r.Count==0?"Completed":Value(r[0],"Status")));Dispatcher.BeginInvoke(new Action(()=>LoadGameSettings()));},null,new Dictionary<string,object>{{"GameId",game},{"GameField",field},{"GameValue",value}});
  }
  void UndoGame(string id) {
   if(busy)return;if(!Review("Restore game setting","Close the game first. Restore the saved key while preserving other settings. If that key changed again, KKxtti stops instead of overwriting it.",new[]{id},"Restore game setting"))return;
   Work("Restore game setting","Undo-GameSetting -Id $UndoId",r=>{gameLoaded=false;},null,new Dictionary<string,object>{{"UndoId",id}});
  }
 }
}
