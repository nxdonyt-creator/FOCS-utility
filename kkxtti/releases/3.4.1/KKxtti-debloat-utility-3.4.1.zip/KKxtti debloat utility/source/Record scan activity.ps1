#requires -Version 5.1
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path -Parent $PSScriptRoot) 'Performance Utility.ps1') -LibraryOnly
Record-DefenderImpact
