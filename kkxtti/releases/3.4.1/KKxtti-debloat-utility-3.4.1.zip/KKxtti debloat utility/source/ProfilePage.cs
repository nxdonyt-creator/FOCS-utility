using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;

namespace KKxtti {
 public sealed partial class Dashboard {
  static bool PreviewAllows(string command){
   if(command.StartsWith("Get-",StringComparison.Ordinal)&&!command.Contains(";")&&!command.Contains("\n"))return true;
   if(command=="Invoke-Native 'powercfg.exe' @('/getactivescheme')")return true;
   return command.StartsWith("\r\n$cpu=Get-CimInstance Win32_Processor",StringComparison.Ordinal)||command.StartsWith("\n$cpu=Get-CimInstance Win32_Processor",StringComparison.Ordinal);
  }
  ComboBox nvidiaGame,potatoScale,nvidiaPotatoLod;TextBlock nvidiaPreview,potatoPreview,powerPreview,nvidiaPotatoPreview;
  string SelectedNvidiaGame(){return nvidiaGame.SelectedIndex==1?"siege":"fortnite";}
  int SelectedPotatoScale(){return potatoScale.SelectedItem==null?50:(int)potatoScale.SelectedItem;}
  void BuildProfileTools(StackPanel page) {
   powerPreview=Text("Customizes supported AC power settings on this PC. Saves the original plan and leaves sleep, display and battery choices intact.",12,"#A2ABC1");
   var power=Card(Stack(Pill("CUSTOM POWER PLAN"),Gap(12),Text("KKxtti Ultimate Gaming",21,null,true),Gap(9),powerPreview,Gap(9),Text("Full CPU performance ceiling, boost enabled and a performance preference, with idle downclocking allowed. Optional settings are skipped when unavailable. Compare heat and frame times before keeping it.",12,"#A2ABC1"),Buttons(Btn("Inspect this PC",()=>Work("Inspect custom power plan","Get-GamingPowerPreview",r=>powerPreview.Text=String.Join("\n",r.Select(v=>Value(v,"Name")+": "+Value(v,"Current")+" → "+Value(v,"Target")+(Value(v,"Supported")=="True"?"":" (not available)"))))),Btn("Create custom plan",()=>Action("Create custom gaming power plan","Set-GamingPowerPlan",true),true),Btn("Reset power plan",()=>Action("Reset custom power plan","Reset-LatestGamingProfile -Kind ultimate",true)))),20);
   nvidiaGame=new ComboBox{Height=37,Padding=new Thickness(8,5,8,5)};nvidiaGame.Items.Add("Fortnite");nvidiaGame.Items.Add("Rainbow Six Siege");nvidiaGame.SelectedIndex=0;AutomationProperties.SetName(nvidiaGame,"NVIDIA game profile");
   nvidiaPreview=Text("Prefer maximum performance, high-performance texture filtering, V-Sync off and driver FPS cap off. Use the game’s cap and Reflex. Applies only to the selected game.",12,"#A2ABC1");
   nvidiaGame.SelectionChanged+=(s,e)=>nvidiaPreview.Text="Choose Inspect profile to read this game's current driver settings.";
   var nvidia=Card(Stack(Pill("NVIDIA / PER GAME"),Gap(12),Text("Competitive performance",21,null,true),Gap(9),nvidiaGame,Gap(10),nvidiaPreview,Gap(9),Text("Allows tearing and reduced filtering quality; maximum performance can increase GPU heat. Reset restores your previous overrides.",12,"#A2ABC1"),Buttons(Btn("Inspect profile",()=>Work("Read NVIDIA game profile","Get-NvidiaState -GameId $ProfileGame",r=>nvidiaPreview.Text=String.Join("\n",r.Select(v=>Value(v,"Name")+": "+Value(v,"CurrentLabel"))),null,new Dictionary<string,object>{{"ProfileGame",SelectedNvidiaGame()}})),Btn("Apply NVIDIA profile",()=>RunNvidiaProfile(false),true),Btn("Reset NVIDIA",()=>RunNvidiaProfile(true)))),20);
   page.Children.Add(Columns(new UIElement[]{power,nvidia}));page.Children.Add(Gap(18));
  }
  void RunNvidiaProfile(bool reset){if(busy||!RequireAdmin())return;Work(reset?"Reset NVIDIA profile":"Apply NVIDIA profile",reset?"Reset-LatestNvidiaPreset -GameId $ProfileGame -Preset competitive":"Set-NvidiaPerformanceProfile -GameId $ProfileGame",r=>{foreach(var value in r)Log(Value(value,"Status"));},null,new Dictionary<string,object>{{"ProfileGame",SelectedNvidiaGame()}});}
  string SelectedNvidiaPotatoLod(){return nvidiaPotatoLod.SelectedIndex==0?"mild":"strong";}
  void BuildPotatoProfile(StackPanel page) {
   nvidiaPotatoLod=new ComboBox{Height=37,Padding=new Thickness(8,5,8,5),MinWidth=250,HorizontalAlignment=HorizontalAlignment.Left};
   nvidiaPotatoLod.Items.Add("Mild / LOD +1.5");nvidiaPotatoLod.Items.Add("Potato / LOD +3.0");nvidiaPotatoLod.SelectedIndex=1;AutomationProperties.SetName(nvidiaPotatoLod,"NVIDIA potato texture LOD");
   nvidiaPotatoPreview=Text("Fortnite NVIDIA driver profile: positive texture LOD bias, high-performance filtering and a 1x anisotropic override. Inspect to see the current profile and requested changes.",12,"#A2ABC1");
   nvidiaPotatoLod.SelectionChanged+=(s,e)=>nvidiaPotatoPreview.Text="Strength changed. Inspect the NVIDIA profile again to see the selected targets.";
   page.Children.Add(Card(Stack(Pill("FORTNITE / NVIDIA DRIVER EXPERIMENT"),Gap(12),Text("Potato textures in the NVIDIA profile.",23,null,true),Gap(9),nvidiaPotatoPreview,Gap(12),Text("Texture detail reduction",12,"#C9B5FF",true),Gap(6),nvidiaPotatoLod,Gap(10),
    Text("Requests coarser, blurrier texture mip levels. Effects depend on the game, renderer and driver. Current Fortnite uses DX12; these overrides may be ignored. Saved driver values do not prove a visual change or higher FPS. Close Fortnite and other NVIDIA profile editors before applying.",12,"#A2ABC1"),
    Gap(8),Text("Applies to the Fortnite NVIDIA profile. Game configuration files, render scale, display resolution and sensitivity stay as you set them.",12,"#C9B5FF"),
    Buttons(Btn("Inspect NVIDIA potato profile",()=>InspectNvidiaPotato()),Btn("Apply NVIDIA potato",()=>RunNvidiaPotato(false),true),Btn("Reset NVIDIA potato",()=>RunNvidiaPotato(true)),Btn("Read NVIDIA research",()=>OpenLocal("NVIDIA POTATO RESEARCH.txt")))),22));
   page.Children.Add(Gap(12));
   var inGame=new StackPanel();BuildFortniteLowGraphics(inGame);
   page.Children.Add(new Expander{Header="Optional: Fortnite in-game graphics settings",Foreground=ink,Content=inGame,Margin=new Thickness(0,0,0,18)});
  }
  void InspectNvidiaPotato(){
   if(busy)return;
   Work("Read NVIDIA potato profile","Get-NvidiaState -GameId fortnite -Preset potato -LodPreset $NvidiaPotatoLod",r=>nvidiaPotatoPreview.Text=String.Join("\n",r.Select(v=>Value(v,"Profile")+" / "+Value(v,"Name")+"\nCurrent: "+Value(v,"CurrentLabel")+" ["+Value(v,"Current")+"] → "+Value(v,"Target"))),null,new Dictionary<string,object>{{"NvidiaPotatoLod",SelectedNvidiaPotatoLod()}});
  }
  void RunNvidiaPotato(bool reset){
   if(busy||!RequireAdmin())return;
   Work(reset?"Reset NVIDIA potato profile":"Apply NVIDIA potato profile",reset?"Reset-LatestNvidiaPreset -GameId fortnite -Preset potato":"Set-NvidiaPotatoProfile -LodPreset $NvidiaPotatoLod",r=>{
    foreach(var v in r)Log(Value(v,"Status"));
    nvidiaPotatoPreview.Text=(r.Count==0?"Cancelled":Value(r[0],"Status"))+". Inspect the profile to read saved values; check the visual result in the game.";
   },null,new Dictionary<string,object>{{"NvidiaPotatoLod",SelectedNvidiaPotatoLod()}});
  }
  void BuildFortniteLowGraphics(StackPanel page) {
   potatoScale=new ComboBox{Height=37,Width=150,HorizontalAlignment=HorizontalAlignment.Left};foreach(int scale in new[]{50,67,75,100})potatoScale.Items.Add(scale);potatoScale.SelectedIndex=0;AutomationProperties.SetName(potatoScale,"In-game low graphics 3D resolution percent");
   potatoPreview=Text("Low scalability settings, motion blur off, Nanite off and fixed render scale. 50% looks very soft; 100% keeps native clarity. Your display resolution, FPS cap and sensitivity are preserved.",12,"#A2ABC1");
   page.Children.Add(Card(Stack(Pill("FORTNITE / IN-GAME SETTINGS"),Gap(12),Text("In-game low graphics",23,null,true),Gap(9),potatoPreview,Gap(12),Text("3D resolution (%)",12,"#C9B5FF",true),Gap(6),potatoScale,Gap(9),Text("Close Fortnite before applying. Choose Performance rendering and Reflex in the game; this profile edits only recognized, existing graphics keys. Reset restores your saved values, including the original render scale.",12,"#A2ABC1"),Buttons(Btn("Preview graphics",()=>Work("Preview Fortnite in-game graphics","Get-FortnitePotatoPreview -Scale $PotatoScale",r=>potatoPreview.Text=String.Join("\n",r.Select(v=>Value(v,"Name")+": "+Value(v,"Current")+" → "+Value(v,"Target")+(Value(v,"Available")=="True"?"":" (not available)"))),null,new Dictionary<string,object>{{"PotatoScale",SelectedPotatoScale()}})),Btn("Apply in-game low graphics",()=>Work("Apply Fortnite in-game graphics","Set-FortnitePotatoProfile -Scale $PotatoScale",r=>{gameLoaded=false;foreach(var value in r)Log(Value(value,"Status"));},null,new Dictionary<string,object>{{"PotatoScale",SelectedPotatoScale()}}),true),Btn("Reset Fortnite graphics",()=>Action("Reset Fortnite graphics","Reset-LatestGamingProfile -Kind fortnite")))),22));page.Children.Add(Gap(18));
  }
  void UndoNvidia(string id){if(busy||!RequireAdmin())return;Work("Reset NVIDIA profile","Undo-NvidiaProfile -Id $ProfileUndo",null,null,new Dictionary<string,object>{{"ProfileUndo",id}});}
  void UndoPotato(string id){if(busy)return;Work("Reset Fortnite graphics","Undo-FortnitePotatoProfile -Id $ProfileUndo",r=>gameLoaded=false,null,new Dictionary<string,object>{{"ProfileUndo",id}});}
 }
}
