using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Reflection;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using Microsoft.PowerShell;
using Microsoft.Win32.SafeHandles;

namespace KKxtti {
 // Embedded pins bind scripts/data to this build. They are not a publisher
 // signature and cannot establish the authenticity of a replaced executable.
 public static class PackageTrust {
  // .NET Framework's path parser rejects alternate-data-stream syntax. Open
  // the specific stream through Win32, then read it through a safe handle.
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
  static extern SafeFileHandle CreateFile(string name,uint access,uint share,IntPtr security,uint creation,uint flags,IntPtr template);
  public static ExecutionPolicy ReadPolicy() {
   using(var rs=RunspaceFactory.CreateRunspace(InitialSessionState.CreateDefault())) {
    rs.Open();
    using(var ps=PowerShell.Create()) {
     ps.Runspace=rs; ps.AddCommand("Get-ExecutionPolicy").AddParameter("List");
     var values=ps.Invoke();
     if(ps.HadErrors||values.Count!=5)throw new InvalidOperationException("Could not read Windows PowerShell execution policy.");
     foreach(string scope in new[]{"MachinePolicy","UserPolicy","Process","CurrentUser","LocalMachine"}) {
      var row=values.Single(v=>v.Properties["Scope"].Value.ToString()==scope);
      var policy=(ExecutionPolicy)Enum.Parse(typeof(ExecutionPolicy),row.Properties["ExecutionPolicy"].Value.ToString(),true);
      if(policy!=ExecutionPolicy.Undefined)return policy;
     }
     // Retain the app's existing RemoteSigned session when no policy was
     // configured. Never weaken an explicit policy or write policy registry keys.
     return ExecutionPolicy.RemoteSigned;
    }
   }
  }
  public static void RequireAllowedPolicy(ExecutionPolicy policy) {
   if(policy==ExecutionPolicy.AllSigned)
    throw new InvalidOperationException("PowerShell requires signed scripts (AllSigned). This KKxtti release is unsigned. Unblocking a download cannot satisfy that policy. Use a publisher-signed release approved for this PC; on a managed PC, contact your administrator.");
   if(policy==ExecutionPolicy.Restricted||policy==ExecutionPolicy.Undefined||policy==ExecutionPolicy.Default)
    throw new InvalidOperationException("PowerShell script execution is restricted on this PC. KKxtti has not changed that policy. On a managed PC, contact your administrator for an approved deployment.");
  }
  static void OrdinaryPath(string path) {
   string current=Path.GetFullPath(path);
   while(!String.IsNullOrEmpty(current)) {
    if((File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0)
     throw new InvalidOperationException("The package contains a link or junction: "+path+". Extract a fresh copy into an ordinary local folder.");
    current=Path.GetDirectoryName(current);
   }
  }
  public static string[] Verify(string root) {
   root=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;
   if(root.StartsWith(@"\\",StringComparison.Ordinal))throw new InvalidOperationException("Extract KKxtti onto a local drive before opening it.");
   OrdinaryPath(root);
   var files=new List<string>(); var names=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   using(var resource=Assembly.GetExecutingAssembly().GetManifestResourceStream("KKxtti.RuntimeHashes")) {
    if(resource==null)throw new InvalidOperationException("The executable is missing its package verification data. Download a fresh release.");
    using(var reader=new StreamReader(resource)) {
     string line;
     while((line=reader.ReadLine())!=null) {
      if(line.Length<67||!Regex.IsMatch(line.Substring(0,64),"^[A-F0-9]{64}$")||line.Substring(64,2)!="  ")throw new InvalidOperationException("Invalid embedded package record.");
      string relative=line.Substring(66);
      if(Path.IsPathRooted(relative)||relative.Contains(':')||relative.Split('/','\\').Any(p=>String.IsNullOrWhiteSpace(p)||p=="."||p=="..")||!names.Add(relative))throw new InvalidOperationException("Invalid embedded package path.");
      string file=Path.GetFullPath(Path.Combine(root,relative));
      if(!file.StartsWith(root,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("A package path escaped its folder.");
      if(!File.Exists(file))throw new InvalidOperationException("A required package file is missing: "+relative+". Extract the complete ZIP into a new folder.");
      OrdinaryPath(file);
      using(var stream=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.Read))
      using(var hash=SHA256.Create()) {
       if(!String.Equals(BitConverter.ToString(hash.ComputeHash(stream)).Replace("-",""),line.Substring(0,64),StringComparison.Ordinal))
        throw new InvalidOperationException("A package file was modified: "+relative+". Nothing was unblocked. Extract a fresh download; keep the old State folder for its recovery records.");
      }
      files.Add(file);
     }
    }
   }
   if(files.Count==0)throw new InvalidOperationException("The embedded package inventory is empty.");
   return files.ToArray();
  }
  public static string[] BlockedFiles(IEnumerable<string> files) {
   var blocked=new List<string>();
   foreach(string file in files) {
    using(var handle=CreateFile(file+":Zone.Identifier",0x80000000,1,IntPtr.Zero,3,0,IntPtr.Zero)) {
     if(handle.IsInvalid) {
      int error=Marshal.GetLastWin32Error();
      if(error==2)continue; // An absent download marker is normal.
      throw new Win32Exception(error,"Could not inspect a download marker: "+Path.GetFileName(file));
     }
     using(var stream=new FileStream(handle,FileAccess.Read))
     using(var reader=new StreamReader(stream)) {
      if(stream.Length>16384)throw new InvalidOperationException("An invalid download marker was found: "+Path.GetFileName(file));
      var zone=Regex.Match(reader.ReadToEnd(),@"(?im)^\s*ZoneId\s*=\s*([0-9]+)");
      int id;
      if(!zone.Success||!Int32.TryParse(zone.Groups[1].Value,out id))throw new InvalidOperationException("An unreadable download marker was found: "+Path.GetFileName(file));
      if(id>=3)blocked.Add(file);
     }
    }
   }
   return blocked.ToArray();
  }
  public static bool Prepare(string root,Func<string,bool> confirm) {
   RequireAllowedPolicy(ReadPolicy());
   string[] files=Verify(root),blocked=BlockedFiles(files);
   if(blocked.Length==0)return true;
   string message="Windows marked this extracted download as coming from the Internet. Its scripts need to be unblocked before the dashboard can read your PC.\n\n"+
    "All "+files.Length+" packaged code and data files match the hashes embedded in KKxtti 3.4.1. The application is unsigned; these checks detect changed files but do not verify a publisher.\n\n"+
    "Folder: "+Path.GetFullPath(root)+"\n\n"+
    "If you trust this download, allow KKxtti to unblock its "+blocked.Length+" verified files? Windows execution policy and your saved State will stay unchanged. Choosing No closes the app.";
   if(confirm==null||!confirm(message))return false;
   // Recheck after the user decision. No scripts run before this step.
   RequireAllowedPolicy(ReadPolicy()); files=Verify(root); blocked=BlockedFiles(files);
   if(blocked.Length>0)using(var ps=PowerShell.Create()) {
    ps.AddCommand("Unblock-File").AddParameter("LiteralPath",blocked).AddParameter("ErrorAction","Stop");
    ps.Invoke();
    if(ps.HadErrors)throw new InvalidOperationException("Windows could not unblock the verified package. Extract a fresh copy into a writable local folder. "+String.Join("\n",ps.Streams.Error.Select(e=>e.ToString())));
   }
   files=Verify(root);
   if(BlockedFiles(files).Length!=0)throw new InvalidOperationException("Windows still marks package files as blocked. Extract a fresh copy into a writable local folder.");
   return true;
  }
 }
}
