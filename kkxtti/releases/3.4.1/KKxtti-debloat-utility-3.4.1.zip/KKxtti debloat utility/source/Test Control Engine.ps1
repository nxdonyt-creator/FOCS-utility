param([string]$root=(Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference='Stop'
. (Join-Path $root 'Control Engine.ps1')
$script:passed=0
function Assert($condition,$message){if(-not $condition){throw ('FAIL: '+$message)};$script:passed++;Write-Host ('PASS: '+$message)}
function Throws($block,$pattern){$caught=$false;try{& $block | Out-Null}catch{$caught=$true;Assert ($_.Exception.Message -match $pattern) ('error: '+$pattern)};Assert $caught 'operation refused'}
$script:fixture='Software\KKxttiControlTests\'+[guid]::NewGuid().ToString('N')
$script:originalCatalog=${function:Get-ControlCatalog}
function Get-ControlCatalog {foreach($original in (& $script:originalCatalog)){$c=$original | ConvertTo-Json -Depth 12 | ConvertFrom-Json;foreach($v in $c.Values){$v.Path=$script:fixture+'\'+$v.Path;if($v.PSObject.Properties['Hive']){$v.Hive='HKCU'}};$c.RequiresAdmin=$false;$c.Editions=@();$c}}
$script:ControlRoot=Join-Path $PSScriptRoot ('control-tests-'+[guid]::NewGuid().ToString('N'))
$script:originalWrite=${function:Write-ControlValue}
$script:originalSave=${function:Save-ControlJournal}
try {
 Assert (@(Get-ControlStates | Where-Object State -eq 'Default / custom').Count -eq @(Get-ControlCatalog).Count) 'missing preferences are reported as default/custom'
 $a=Set-ControlSettings @('game-mode') $true
 Assert ($a.Status -eq 'Applied') 'switch applies'
 Assert ((Get-ControlStates | Where-Object Id -eq 'game-mode').State -eq 'On') 'on state read back'
 $b=Set-ControlSettings @('game-mode') $false
 Assert ((Get-ControlStates | Where-Object Id -eq 'game-mode').State -eq 'Off') 'off state read back'
 Throws {Undo-ControlSettings $a.Id} 'newer or external'
 $null=Undo-ControlSettings $b.Id
 Assert ((Get-ControlStates | Where-Object Id -eq 'game-mode').State -eq 'On') 'undo later change restores on'
 $null=Undo-ControlSettings $a.Id
 Assert ((Get-ControlStates | Where-Object Id -eq 'game-mode').State -eq 'Default / custom') 'undo restores absence'
 Throws {Undo-ControlSettings $a.Id} 'not an applied'
 $v=(Get-ControlCatalog | Where-Object Id -eq 'extensions').Values[0]
 Write-ControlValue $v ([pscustomobject]@{Exists=$true;Kind='String';Data='original custom value'})
 $a=Set-ControlSettings @('extensions') $true
 $null=Undo-ControlSettings $a.Id
 $read=Read-ControlValue $v
 Assert ($read.Kind -eq 'String' -and $read.Data -ceq 'original custom value') 'undo preserves original value type and contents'
 $a=Set-ControlSettings @('game-mode','no-capture','dark-mode') $true
 Assert ($a.Count -eq 6) 'preset journals every changed value'
 $null=Undo-ControlSettings $a.Id
 Assert (@(Get-ControlStates | Where-Object { $_.Id -in @('game-mode','no-capture','dark-mode') -and $_.State -eq 'Default / custom'}).Count -eq 3) 'preset undo restores all members'
 $script:writeCount=0
 function Write-ControlValue($Spec,$Value){$script:writeCount++; & $script:originalWrite $Spec $Value;if($script:writeCount -eq 2){throw 'Injected write failure'}}
 Throws {Set-ControlSettings @('game-mode','no-capture') $true} 'rolled back'
 Set-Item Function:Write-ControlValue $script:originalWrite
 Assert (@(Get-ControlStates | Where-Object {$_.Id -in @('game-mode','no-capture') -and $_.State -eq 'Default / custom'}).Count -eq 2) 'partial writes roll back including the failing member'
 function Write-ControlValue($Spec,$Value){if($Value.Exists){return}; & $script:originalWrite $Spec $Value}
 Throws {Set-ControlSettings @('game-mode') $true} 'did not keep'
 Set-Item Function:Write-ControlValue $script:originalWrite
 Assert ((Get-ControlStates | Where-Object Id -eq 'game-mode').State -eq 'Default / custom') 'readback failure rolls back'
 function Save-ControlJournal($Path,$Journal){throw 'Injected backup failure'}
 Throws {Set-ControlSettings @('game-mode') $true} 'backup failure'
 Set-Item Function:Save-ControlJournal $script:originalSave
 Assert ((Get-ControlStates | Where-Object Id -eq 'game-mode').State -eq 'Default / custom') 'backup failure prevents registry writes'
 Throws {Set-ControlSettings @('game-mode','not-a-setting') $true} 'Unknown setting'
 Assert ((Get-ControlStates | Where-Object Id -eq 'game-mode').State -eq 'Default / custom') 'invalid preset rejected before writes'
 Throws {Undo-ControlSettings '..\elsewhere'} 'valid settings backup'
 $a=Set-ControlSettings @('game-mode') $true
 $v=(Get-ControlCatalog | Where-Object Id -eq 'game-mode').Values[0]
 Write-ControlValue $v ([pscustomobject]@{Exists=$true;Kind='DWord';Data=42})
 Throws {Undo-ControlSettings $a.Id} 'newer or external'
 Assert ((Read-ControlValue $v).Data -eq 42) 'undo refuses to overwrite external change'
 $empty=Set-ControlSettings @('dark-mode') $true
 $again=Set-ControlSettings @('dark-mode') $true
 Assert ($again.Count -eq 0 -and $again.Status -eq 'Already configured') 'no-op creates no extra mutation'
 $script:packages=@(
  [pscustomobject]@{Name='Microsoft.Windows.Photos';PackageFullName='Photos_test';NonRemovable=$false;IsFramework=$false;SignatureKind='Store'},
  [pscustomobject]@{Name='Microsoft.Windows.DevHome';PackageFullName='DevHome_test';NonRemovable=$false;IsFramework=$false;SignatureKind='Developer'},
  [pscustomobject]@{Name='Microsoft.WindowsStore';PackageFullName='Store_test';NonRemovable=$false;IsFramework=$false;SignatureKind='Store'},
  [pscustomobject]@{Name='Microsoft.Paint';PackageFullName='Paint_system';NonRemovable=$false;IsFramework=$false;SignatureKind='System'})
 $script:removed=@()
 function Get-InstalledMainPackages {@($script:packages | Where-Object {$script:removed -notcontains $_.PackageFullName})}
 function Remove-AppxPackage {param($Package,$ErrorAction);$script:removed+=$Package}
 Assert (@(Get-ManagedApps).Count -eq 4) 'inventory includes protected apps'
 Assert (@(Get-ManagedApps | Where-Object Protected).Count -eq 2) 'store and system-signed packages protected'
 Assert (@(Get-ManagedApps | Where-Object Suggested).Count -eq 1) 'extras preset excludes photo app'
 Throws {Remove-ManagedApps @('Photos_test','Store_test')} 'protected'
 Assert ($script:removed.Count -eq 0) 'whole protected batch refused before uninstall'
 Throws {Remove-ManagedApps @('Photos_test','stale_package')} 'protected'
 Assert ($script:removed.Count -eq 0) 'stale batch refused before uninstall'
 $r=@(Remove-ManagedApps @('Photos_test'))
 Assert ($r.Count -eq 1 -and $r[0].Status -eq 'Removed') 'removal verified after uninstall'
 Assert ($script:removed.Count -eq 1 -and $script:removed[0] -eq 'Photos_test') 'only selected package removed'
 function Remove-AppxPackage {param($Package,$ErrorAction);throw 'Injected app removal failure'}
 $r=@(Remove-ManagedApps @('DevHome_test'))
 Assert ($r[0].Status -eq 'Failed' -and $r[0].Error -match 'Injected') 'uninstall failures recorded accurately'
 function Remove-AppxPackage {param($Package,$ErrorAction)}
 $r=@(Remove-ManagedApps @('DevHome_test'))
 Assert ($r[0].Status -eq 'Failed' -and $r[0].Error -match 'still reports') 'silent failed uninstall caught by readback'
 Write-Host ('TOTAL: '+$script:passed+' assertions passed. Only isolated test registry keys and mocked packages were changed.')
} finally {
 # Strict fixed prefix and generated identifier; never a Windows settings path.
 if($script:fixture -match '^Software\\KKxttiControlTests\\[a-f0-9]{32}$'){[Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($script:fixture,$false)}else{throw 'Invalid fixture cleanup path'}
}
