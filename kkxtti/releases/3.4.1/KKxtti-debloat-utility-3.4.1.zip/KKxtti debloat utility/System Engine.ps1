#requires -Version 5.1
# Typed Windows operations; no downloaded scripts or arbitrary command text.
function Get-SystemCatalog {
 @(
  [pscustomobject]@{Id='hibernate';Name='Disable hibernation';Note='Frees hiberfil.sys and disables Hibernate and Fast Startup. Useful for disk space, not an FPS boost. Undo restores the original enabled state and full/reduced file type.';Source='https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options'}
  [pscustomobject]@{Id='reserved-storage';Name='Disable reserved storage';Note='May free update reservation on a small SSD. Can make future updates fail when disk space is low. Keep enabled normally; no gaming benefit. Fails safely while servicing is active.';Source='https://learn.microsoft.com/en-us/powershell/module/dism/set-windowsreservedstoragestate'}
  [pscustomobject]@{Id='recall-feature';Name='Disable the Recall optional feature';Note='Only if the Recall feature exists. Uses DISM without removing the component payload or restarting. Availability depends on this PC and its Windows installation. A feature-state backup does not back up Recall snapshots; re-enabling the feature cannot promise data recovery.';Source='https://learn.microsoft.com/en-us/windows/client-management/manage-recall'}
  [pscustomobject]@{Id='maps-service';Name='Set Downloaded Maps Manager to Manual';Note='Changes MapsBroker startup only; does not stop a running service. May affect offline maps. Fewer services do not prove lower latency.';Source='https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/set-service'}
  [pscustomobject]@{Id='media-service';Name='Set Media Player network sharing to Manual';Note='Changes WMPNetworkSvc startup only if installed. Media sharing may require starting it. No FPS benefit is claimed.';Source='https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/set-service'}
  [pscustomobject]@{Id='fax-service';Name='Set Fax to Manual';Note='Changes Fax startup only if installed. Excludes networking, Windows Update, audio, anti-cheat and security services.';Source='https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/set-service'}
 )
}
function Get-SystemServiceName($Id) {switch($Id){'maps-service'{'MapsBroker'};'media-service'{'WMPNetworkSvc'};'fax-service'{'Fax'};default{throw 'Unknown optional service.'}}}
function Read-SystemValue($Id) {
 if($Id -eq 'hibernate'){
  $key=[Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\Power')
  try{
   $enabled=$key.GetValue('HibernateEnabled',$null);$type=$key.GetValue('HiberFileType',$null);$size=$key.GetValue('HiberFileSizePercent',0)
   if($null -eq $enabled -or [int]$enabled -notin @(0,1)){throw 'Cannot determine hibernation state.'}
   if([int]$enabled -eq 1 -and ($null -eq $type -or [int]$type -notin @(0,2))){throw 'Unknown hibernation file type; cannot promise exact restoration.'}
   if([int]$size -lt 0 -or [int]$size -gt 100){throw 'Unknown hibernation file size.'}
   [pscustomobject]@{Enabled=[bool]$enabled;Type=$(if($null -eq $type){2}else{[int]$type});SizePercent=[int]$size}
  }finally{$key.Dispose()}
 }elseif($Id -eq 'reserved-storage'){
  [pscustomobject]@{State=[string](Get-WindowsReservedStorageState -ErrorAction Stop).ReservedStorageState}
 }elseif($Id -eq 'recall-feature'){
  $feature=Get-WindowsOptionalFeature -Online -FeatureName 'Recall' -ErrorAction Stop
  if([string]$feature.State -notin @('Enabled','Disabled')){throw 'Recall is absent, removed or pending a restart.'}
  [pscustomobject]@{State=[string]$feature.State}
 }else{
  $name=Get-SystemServiceName $Id;$service=Get-Service -Name $name -ErrorAction Stop
  [pscustomobject]@{Start=[string]$service.StartType}
 }
}
function Assert-SystemValue($Id,$Value) {
 if($Id -notin @(Get-SystemCatalog | ForEach-Object Id)){throw 'Unknown system control.'}
 if($Id -eq 'hibernate'){if($Value.Enabled -isnot [bool] -or $Value.Type -notin @(0,2) -or $Value.SizePercent -lt 0 -or $Value.SizePercent -gt 100){throw 'Invalid hibernation state.'}}
 elseif($Id -in @('reserved-storage','recall-feature')){if($Value.State -notin @('Enabled','Disabled')){throw 'Invalid feature state.'}}
 elseif($Value.Start -notin @('Automatic','Manual','Disabled')){throw 'Unsupported service startup type.'}
}
function Write-SystemValue($Id,$Value) {
 Assert-SystemValue $Id $Value;Require-Admin
 if($Id -eq 'hibernate'){
  $null=Invoke-Native 'powercfg.exe' @('/hibernate',$(if($Value.Enabled){'on'}else{'off'}))
  if($Value.Enabled){
   if($Value.Type -eq 0){$null=Invoke-Native 'powercfg.exe' @('/hibernate','/size','0');$null=Invoke-Native 'powercfg.exe' @('/hibernate','/type','reduced')}
   else{$null=Invoke-Native 'powercfg.exe' @('/hibernate','/type','full');$null=Invoke-Native 'powercfg.exe' @('/hibernate','/size',[string]$Value.SizePercent)}
  }
 }elseif($Id -eq 'reserved-storage'){$null=Set-WindowsReservedStorageState -State $Value.State -ErrorAction Stop}
 elseif($Id -eq 'recall-feature'){
  if($Value.State -eq 'Disabled'){$r=Disable-WindowsOptionalFeature -Online -FeatureName 'Recall' -NoRestart -ErrorAction Stop}
  else{$r=Enable-WindowsOptionalFeature -Online -FeatureName 'Recall' -All -NoRestart -ErrorAction Stop}
  if($r.RestartNeeded){Write-Host 'Windows reports a restart is needed. Restart separately after saving your work.'}
 }else{Set-Service -Name (Get-SystemServiceName $Id) -StartupType $Value.Start -ErrorAction Stop}
}
function Test-SystemEqual($A,$B) {if($A.PSObject.Properties['Enabled'] -and $B.PSObject.Properties['Enabled'] -and -not $A.Enabled -and -not $B.Enabled){return $true};(ConvertTo-Json $A -Compress) -ceq (ConvertTo-Json $B -Compress)}
function Get-SystemStates {
 foreach($item in Get-SystemCatalog){try{$value=Read-SystemValue $item.Id;$detail=ConvertTo-Json $value -Compress;[pscustomobject]@{Id=$item.Id;Name=$item.Name;Note=$item.Note;Source=$item.Source;Available=$true;State=$detail}}catch{[pscustomobject]@{Id=$item.Id;Name=$item.Name;Note=$item.Note;Source=$item.Source;Available=$false;State=$_.Exception.Message}}}
}
function Set-SystemControl([string]$Id) {
 Require-Admin;$item=@(Get-SystemCatalog | Where-Object Id -ceq $Id);if($item.Count -ne 1){throw 'Unknown system control.'}
 $before=Read-SystemValue $Id;Assert-SystemValue $Id $before
 $after=if($Id -eq 'hibernate'){[pscustomobject]@{Enabled=$false;Type=$before.Type;SizePercent=$before.SizePercent}}elseif($Id -in @('reserved-storage','recall-feature')){[pscustomobject]@{State='Disabled'}}else{[pscustomobject]@{Start='Manual'}}
 if(Test-SystemEqual $before $after){return [pscustomobject]@{Status='Already configured';Id=''}}
 if(-not (Confirm-Action ($item[0].Name+'. '+$item[0].Note+' Current: '+(ConvertTo-Json $before -Compress)+'. A system backup will be saved.') 'APPLY')){return}
 $row=[pscustomobject]@{Id=$Id;Before=$before;After=$after};$saved=New-ControlJournal 'system' @($row);$writeAttempted=$false
 try{
  if(-not(Test-SystemEqual (Read-SystemValue $Id) $before)){throw 'System state changed during review.'}
  $writeAttempted=$true
  Write-SystemValue $Id $after
  if(-not(Test-SystemEqual (Read-SystemValue $Id) $after)){throw 'Windows did not retain the requested state. The operation may be awaiting a restart.'}
  $saved.Journal.Status='Applied';Save-ControlJournal $saved.Path $saved.Journal
 }catch{
  $problem=$_.Exception.Message;$saved.Journal.Status='Recovery needed'
  if(-not $writeAttempted){$saved.Journal.Status='Cancelled'}
  else{
   try{
    $current=Read-SystemValue $Id
    if(Test-SystemEqual $current $before){$saved.Journal.Status='Rolled back'}
    elseif(Test-SystemEqual $current $after){Write-SystemValue $Id $before;if(Test-SystemEqual (Read-SystemValue $Id) $before){$saved.Journal.Status='Rolled back'}}
    # Unknown, externally changed or pending servicing states require review.
   }catch{}
  }
  Save-ControlJournal $saved.Path $saved.Journal;throw ($problem+' Status: '+$saved.Journal.Status+'. Inspect the saved record; pending servicing may require a restart.')
 }
 [pscustomobject]@{Status=$saved.Journal.Status;Id=$saved.Journal.Id}
}
function Read-SystemJournal([string]$Id) {
 if($Id -cnotmatch '^system-\d{8}-\d{6}-[a-f0-9]{8}$'){throw 'Invalid system backup.'}
 $path=Join-Path (Join-Path (Join-Path $script:ControlRoot 'State') $Id) 'transaction.json'
 if((Get-Item -LiteralPath $path).Length -gt 2MB){throw 'System backup too large.'}
 $j=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
 if($j.Schema -ne 1 -or $j.Id -cne $Id -or $j.Status -notin @('Applied','Prepared','Undoing','Recovery needed') -or $j.Computer -ne $env:COMPUTERNAME -or $j.Sid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -or @($j.Rows).Count -ne 1){throw 'System backup belongs to another state, PC or account.'}
 Assert-SystemValue $j.Rows[0].Id $j.Rows[0].Before;Assert-SystemValue $j.Rows[0].Id $j.Rows[0].After
 [pscustomobject]@{Path=$path;Journal=$j}
}
function Get-SystemRecoveryPlan([string]$Id) {
 $saved=Read-SystemJournal $Id;$row=$saved.Journal.Rows[0];$current=Read-SystemValue $row.Id
 [pscustomobject]@{Key=$row.Id;Action=$(if(Test-SystemEqual $current $row.Before){'Already original'}elseif(Test-SystemEqual $current $row.After){'Restore original'}else{'Conflict - stop'});Kind='system'}
}
function Undo-SystemControl([string]$Id) {
 Require-Admin;$saved=Read-SystemJournal $Id;$row=$saved.Journal.Rows[0];$plan=Get-SystemRecoveryPlan $Id
 if($plan.Action -eq 'Conflict - stop'){throw 'A newer, pending or external system change conflicts with this record. No changes were made.'}
 if(-not(Confirm-Action ('Restore original system configuration for '+$row.Id+'? A restart may be needed for optional features. No automatic restart is performed.') 'RESTORE')){return}
 $saved.Journal.Status='Undoing';Save-ControlJournal $saved.Path $saved.Journal
 try{
  if($plan.Action -ne 'Already original'){
   if(-not(Test-SystemEqual (Read-SystemValue $row.Id) $row.After)){throw 'State changed during review.'}
   Write-SystemValue $row.Id $row.Before
  }
  if(-not(Test-SystemEqual (Read-SystemValue $row.Id) $row.Before)){throw 'Original state is not restored yet; a restart or servicing completion may be needed.'}
  $saved.Journal.Status='Undone';Save-ControlJournal $saved.Path $saved.Journal
 }catch{$saved.Journal.Status='Recovery needed';Save-ControlJournal $saved.Path $saved.Journal;throw}
 [pscustomobject]@{Status=$saved.Journal.Status;Id=$Id}
}
function Start-SystemDriveDecryption {
 Require-Admin
 $volume=Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
 if([string]$volume.VolumeStatus -eq 'FullyDecrypted'){return [pscustomobject]@{Status='Already decrypted';Percent=0}}
 if([string]$volume.VolumeStatus -ne 'FullyEncrypted'){throw 'The system drive is already converting or has an unsupported encryption state. Review it in Windows first.'}
 if(-not (Confirm-Action ('Decrypt only '+$env:SystemDrive+' and remove its BitLocker protectors. Back up your recovery key outside this PC before proceeding. This weakens protection of stored files, may run for a long time, and has no automatic undo. Typing DECRYPT confirms you have saved your key and want to decrypt. No other drives or auto-unlock keys are touched.') 'DECRYPT')){return}
 $fresh=Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
 if([string]$fresh.VolumeStatus -ne 'FullyEncrypted'){throw 'Encryption state changed. Nothing was requested.'}
 $saved=New-ControlJournal 'decryption' @([pscustomobject]@{Drive=$env:SystemDrive;Status='Requested';AutomaticUndo=$false})
 try{$null=Disable-BitLocker -MountPoint $env:SystemDrive -ErrorAction Stop;$saved.Journal.Status='Decryption requested';Save-ControlJournal $saved.Path $saved.Journal}catch{$saved.Journal.Status='Failed';Save-ControlJournal $saved.Path $saved.Journal;throw}
 $now=Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
 [pscustomobject]@{Status='Decryption requested; monitor in Manage BitLocker';Percent=$now.EncryptionPercentage}
}
function New-ReviewedRestorePoint {
 Require-Admin
 if(-not(Confirm-Action 'Create a Windows restore point? System Protection must already be enabled. This is not a file or game-save backup. Windows may limit how often restore points can be created.' 'CREATE')){return}
 $before=@(Get-ComputerRestorePoint -ErrorAction Stop | ForEach-Object SequenceNumber)
 $description='KKxtti reviewed change '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
 Checkpoint-Computer -Description $description -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
 $fresh=@(Get-ComputerRestorePoint -ErrorAction Stop | Where-Object {$_.SequenceNumber -notin $before -and $_.Description -eq $description})
 if(-not $fresh.Count){throw 'Windows did not create a new restore point. Check System Protection and its creation-frequency limit.'}
 [pscustomobject]@{Status='Created';Description=$description}
}
function Get-PlanFingerprint([string]$Guid,[switch]$All) {
 if($Guid -cnotmatch '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$'){throw 'Invalid power plan GUID.'}
 $text=Invoke-Native 'powercfg.exe' @($(if($All){'/qh'}else{'/query'}),$Guid)
 $sha=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes([string]$text)))).Replace('-','')}finally{$sha.Dispose()}
}
function Set-UltimateTestPlan {
 Require-Admin
 if(-not(Confirm-Action 'Create and activate a separate Ultimate Performance desktop test plan? Your original active plan is saved. This can increase idle power and heat; a gaming benefit on this PC is not established. Compare frame times and restore through Backups. No Windows security settings are changed.' 'CREATE')){return}
 $before=Get-PowerGuid;$created=[guid]::NewGuid().ToString('D');$row=[pscustomobject]@{PreviousPlan=$before;CreatedPlan=$created;Fingerprint=''}
 $saved=New-ControlJournal 'ultimate' @($row)
 try{
  $null=Invoke-Native 'powercfg.exe' @('/duplicatescheme','e9a42b02-d5df-448d-aa00-03f14749eb61',$created)
  $null=Invoke-Native 'powercfg.exe' @('/changename',$created,'KKxtti Ultimate Performance test')
  $row.Fingerprint=Get-PlanFingerprint $created;Save-ControlJournal $saved.Path $saved.Journal
  if((Get-PowerGuid) -cne $before){throw 'Active plan changed during setup.'}
  $null=Invoke-Native 'powercfg.exe' @('/setactive',$created)
  if((Get-PowerGuid) -cne $created){throw 'Power plan activation did not persist.'}
  $saved.Journal.Status='Applied';Save-ControlJournal $saved.Path $saved.Journal
 }catch{
  $problem=$_.Exception.Message;$saved.Journal.Status='Recovery needed'
  try{
   $active=Get-PowerGuid
   if($active -ceq $created){$null=Invoke-Native 'powercfg.exe' @('/setactive',$before);$active=Get-PowerGuid}
   if($active -ceq $before){if($row.Fingerprint -and (Get-PlanFingerprint $created) -ceq $row.Fingerprint){$null=Invoke-Native 'powercfg.exe' @('/delete',$created)};$saved.Journal.Status='Rolled back'}
  }catch{}
  Save-ControlJournal $saved.Path $saved.Journal;throw ($problem+' '+$saved.Journal.Status+'. Inspect the saved record for any unactivated leftover test plan.')
 }
 [pscustomobject]@{Status='Applied';Id=$saved.Journal.Id;Plan=$created}
}
function Read-UltimateJournal([string]$Id) {
 if($Id -cnotmatch '^ultimate-\d{8}-\d{6}-[a-f0-9]{8}$'){throw 'Invalid Ultimate plan backup.'}
 $path=Join-Path (Join-Path (Join-Path $script:ControlRoot 'State') $Id) 'transaction.json'
 if((Get-Item -LiteralPath $path).Length -gt 2MB){throw 'Backup too large.'}
 $j=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
 if($j.Schema -ne 1 -or $j.Id -cne $Id -or $j.Status -notin @('Applied','Prepared','Undoing','Recovery needed') -or $j.Computer -ne $env:COMPUTERNAME -or $j.Sid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -or @($j.Rows).Count -ne 1){throw 'Invalid Ultimate plan record for this account and PC.'}
 $row=$j.Rows[0]
 foreach($guid in @($row.PreviousPlan,$row.CreatedPlan)){if($guid -cnotmatch '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$'){throw 'Invalid saved plan GUID.'}}
 if($row.PreviousPlan -ceq $row.CreatedPlan -or $row.Fingerprint -cnotmatch '^[A-F0-9]{64}$'){throw 'This plan was not fully fingerprinted; inspect it manually. No plan will be deleted.'}
 [pscustomobject]@{Path=$path;Journal=$j}
}
function Test-PowerPlanExists([string]$Guid) {
 $listed=[string](Invoke-Native 'powercfg.exe' @('/list'))
 $plans=@([regex]::Matches($listed,'(?i)\b[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\b') | ForEach-Object {$_.Value.ToLowerInvariant()})
 if(-not $plans.Count){throw 'Cannot read the current power plan list.'}
 $plans -contains $Guid
}
function Undo-UltimateTestPlan([string]$Id) {
 Require-Admin;$saved=Read-UltimateJournal $Id;$row=$saved.Journal.Rows[0];$active=Get-PowerGuid
 $allSettings=$null -ne $row.PSObject.Properties['FingerprintMode'] -and $row.FingerprintMode -ceq 'All'
 if($active -cnotin @($row.PreviousPlan,$row.CreatedPlan)){throw 'Another plan is active. No newer or external plan selection was overwritten.'}
 $null=Get-PlanFingerprint $row.PreviousPlan
 if(-not(Test-PowerPlanExists $row.CreatedPlan)){
  if($active -cne $row.PreviousPlan){throw 'The created plan is absent but the original plan is not active. Inspect manually.'}
  if(-not(Confirm-Action 'The original plan is already active and the utility-created test plan is absent. Finalize this recovery record without changing any power plan?' 'RESTORE')){return}
  if((Get-PowerGuid) -cne $row.PreviousPlan -or (Test-PowerPlanExists $row.CreatedPlan)){throw 'Power configuration changed during review.'}
  $saved.Journal.Status='Undone';Save-ControlJournal $saved.Path $saved.Journal
  return [pscustomobject]@{Status='Undone';Id=$Id}
 }
 if((Get-PlanFingerprint $row.CreatedPlan -All:$allSettings) -cne $row.Fingerprint){throw 'The test plan was edited externally. No plan was changed or deleted.'}
 if(-not(Confirm-Action ('Activate your saved original plan '+$row.PreviousPlan+' and delete only the unchanged test plan '+$row.CreatedPlan+' created by this transaction?') 'RESTORE')){return}
 if((Get-PowerGuid) -cne $active -or (Get-PlanFingerprint $row.CreatedPlan -All:$allSettings) -cne $row.Fingerprint){throw 'Power configuration changed during review.'}
 $saved.Journal.Status='Undoing';Save-ControlJournal $saved.Path $saved.Journal
 try{
  $null=Invoke-Native 'powercfg.exe' @('/setactive',$row.PreviousPlan)
  if((Get-PowerGuid) -cne $row.PreviousPlan){throw 'Original active plan was not restored.'}
  $null=Invoke-Native 'powercfg.exe' @('/delete',$row.CreatedPlan)
  $saved.Journal.Status='Undone';Save-ControlJournal $saved.Path $saved.Journal
 }catch{$saved.Journal.Status='Recovery needed';Save-ControlJournal $saved.Path $saved.Journal;throw}
 [pscustomobject]@{Status='Undone';Id=$Id}
}
