#requires -Version 5.1
# Fixed app IDs. WinGet's hash checks and malware checks are never bypassed.
function Get-InstallerCatalog {
 @(
  [pscustomobject]@{Id='chromium';Name='Chromium';Package='Official Win_x64 snapshot';Publisher='The Chromium project';Source='https://www.chromium.org/getting-involved/download-chromium/';Note='Portable official Google build, not Chrome or an unverified repack. Installs under your LocalAppData\KKxtti\Chromium. Official Chromium snapshots do not auto-update and are development builds; reinstall a new version regularly. No existing browser data is deleted.'}
  [pscustomobject]@{Id='discord';Name='Discord';Package='Discord.Discord';Publisher='Discord Inc.';Source='https://discord.com/download';Note='Exact package from Microsoft community WinGet source. Normal installer and hash validation; Discord handles later updates. Package license agreements are accepted when you confirm installation.'}
  [pscustomobject]@{Id='epic';Name='Epic Games Launcher';Package='EpicGames.EpicGamesLauncher';Publisher='Epic Games';Source='https://store.epicgames.com/download';Note='Exact WinGet package. Machine installation may show Windows UAC. Installs the launcher only; no game is downloaded. Package license agreements are accepted when you confirm installation.'}
 )
}
function Get-TrustedWinget {
 $packages=@(Get-AppxPackage -Name Microsoft.DesktopAppInstaller -ErrorAction Stop | Where-Object {-not $_.IsFramework})
 if($packages.Count -ne 1){throw 'Install or repair Microsoft App Installer through Microsoft Store first.'}
 $path=Join-Path $packages[0].InstallLocation 'winget.exe'
 if(-not(Test-Path -LiteralPath $path -PathType Leaf)){throw 'Microsoft App Installer does not contain winget.exe.'}
 $signature=Get-AuthenticodeSignature -LiteralPath $path
 if($signature.Status -ne 'Valid' -or $null -eq $signature.SignerCertificate -or $signature.SignerCertificate.Subject -notmatch '(^|,\s*)O=Microsoft Corporation(,|$)'){throw 'WinGet signature is not valid for Microsoft Corporation.'}
 $path
}
function Invoke-InstallerProcess($Path,[string[]]$Arguments) {
 # All caller arguments are fixed IDs, flags or locally generated paths.
 $quoted=foreach($arg in $Arguments){if($arg -match '["\r\n]'){throw 'Invalid installer argument.'};'"'+($arg -replace '(\\+)$','$1$1')+'"'}
 $start=[Diagnostics.ProcessStartInfo]::new();$start.FileName=$Path;$start.Arguments=$quoted -join ' ';$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
 $p=[Diagnostics.Process]::new();$p.StartInfo=$start
 try{
  $null=$p.Start();$out=$p.StandardOutput.ReadToEndAsync();$err=$p.StandardError.ReadToEndAsync();$last=Get-Date
  while(-not $p.WaitForExit(1000)){if(((Get-Date)-$last).TotalSeconds -ge 15){Write-Host 'Installer still running. Its own progress or UAC may be visible. Wait for it to finish.';$last=Get-Date}}
  [pscustomobject]@{Code=$p.ExitCode;Output=$out.Result;Error=$err.Result}
 }finally{$p.Dispose()}
}
function Assert-OfficialWingetSource($Winget) {
 $r=Invoke-InstallerProcess $Winget @('source','export','--name','winget','--disable-interactivity')
 if($r.Code -ne 0){throw ('Cannot inspect WinGet source: '+$r.Error)}
 $source=$r.Output | ConvertFrom-Json
 if($source.Name -cne 'winget' -or $source.Arg -cne 'https://cdn.winget.microsoft.com/cache' -or $source.Type -cne 'Microsoft.PreIndexed.Package' -or $source.Identifier -cne 'Microsoft.Winget.Source_8wekyb3d8bbwe'){throw 'The configured winget source is not the official Microsoft community source. Restore it in App Installer; no app was installed.'}
}
function Get-InstallerStates {
 $names=@();foreach($hive in @([Microsoft.Win32.Registry]::CurrentUser,[Microsoft.Win32.Registry]::LocalMachine)){
  foreach($path in @('Software\Microsoft\Windows\CurrentVersion\Uninstall','Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')){
   $parent=$hive.OpenSubKey($path);if(-not $parent){continue};try{foreach($sub in $parent.GetSubKeyNames()){$key=$parent.OpenSubKey($sub);if($key){try{$names+=[string]$key.GetValue('DisplayName','')}finally{$key.Dispose()}}}}finally{$parent.Dispose()}
  }
 }
 foreach($item in Get-InstallerCatalog){
  $installed=if($item.Id -eq 'discord'){@($names | Where-Object {$_ -eq 'Discord'}).Count -gt 0}elseif($item.Id -eq 'epic'){@($names | Where-Object {$_ -eq 'Epic Games Launcher'}).Count -gt 0}else{Test-Path -LiteralPath (Join-Path $env:LOCALAPPDATA 'KKxtti\Chromium\installed.json')}
  [pscustomobject]@{Id=$item.Id;Name=$item.Name;Package=$item.Package;Publisher=$item.Publisher;Source=$item.Source;Note=$item.Note;State=$(if($installed){'Installed (inventory)'}else{'Not detected'})}
 }
}
function Assert-InstallerDirectory([string]$Path,[string]$Root) {
 $rootFull=[IO.Path]::GetFullPath($Root).TrimEnd('\');$full=[IO.Path]::GetFullPath($Path)
 if(-not($full.Equals($rootFull,[StringComparison]::OrdinalIgnoreCase) -or $full.StartsWith($rootFull+'\',[StringComparison]::OrdinalIgnoreCase))){throw 'Installer path escaped its destination.'}
 $node=$full;while($node){if(Test-Path -LiteralPath $node){if((Get-Item -LiteralPath $node -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Installer destination contains a link or junction.'}};$parent=[IO.Path]::GetDirectoryName($node);if($parent -eq $node){break};$node=$parent}
}
function Get-ChromiumPlan {
 [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
 $revision=([string](Invoke-RestMethod -Uri 'https://storage.googleapis.com/chromium-browser-snapshots/Win_x64/LAST_CHANGE' -TimeoutSec 30)).Trim()
 if($revision -cnotmatch '^\d{6,9}$'){throw 'Unexpected official Chromium revision.'}
 $object='Win_x64/'+$revision+'/chrome-win.zip'
 $meta=Invoke-RestMethod -Uri ('https://storage.googleapis.com/storage/v1/b/chromium-browser-snapshots/o/'+[uri]::EscapeDataString($object)) -TimeoutSec 30
 if($meta.bucket -cne 'chromium-browser-snapshots' -or $meta.name -cne $object -or [long]$meta.size -lt 1MB -or [long]$meta.size -gt 700MB -or $meta.generation -notmatch '^\d+$' -or $meta.md5Hash -notmatch '^[A-Za-z0-9+/]{22}==$'){throw 'Unexpected Chromium object metadata.'}
 [pscustomobject]@{Revision=$revision;Generation=[string]$meta.generation;Size=[long]$meta.size;Md5=[string]$meta.md5Hash;Url=('https://storage.googleapis.com/chromium-browser-snapshots/'+$object+'?generation='+$meta.generation)}
}
function Expand-ReviewedChromium($Archive,$Destination) {
 Add-Type -AssemblyName System.IO.Compression
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $zip=[IO.Compression.ZipFile]::OpenRead($Archive)
 try{
  if($zip.Entries.Count -gt 6000){throw 'Chromium archive has too many files.'}
  $bytes=0L;$names=@{}
  foreach($entry in $zip.Entries){
   $name=$entry.FullName
   if($name -notmatch '^chrome-win/' -or $name -match '(^|[/\\])\.\.($|[/\\])|[:\\]' -or $names.ContainsKey($name)){throw 'Unexpected or duplicate Chromium archive path.'}
   $names[$name]=$true;$bytes+=$entry.Length;if($bytes -gt 2GB -or $entry.Length -gt 700MB){throw 'Chromium archive exceeds extraction limit.'}
   $unixMode=($entry.ExternalAttributes -shr 16) -band 0xF000;if($unixMode -eq 0xA000){throw 'Archive contains a symbolic link.'}
   $target=Join-Path $Destination $name;Assert-InstallerDirectory $target $Destination
  }
  if(-not $names.ContainsKey('chrome-win/chrome.exe')){throw 'Archive does not contain the Chromium executable.'}
  [IO.Compression.ZipFile]::ExtractToDirectory($Archive,$Destination)
 }finally{$zip.Dispose()}
}
function Install-OfficialChromium {
 $plan=Get-ChromiumPlan
 if(-not(Confirm-Action ('Install official Chromium snapshot revision '+$plan.Revision+' ('+[math]::Round($plan.Size/1MB)+' MiB)? These are development builds WITHOUT automatic updates. This is Chromium, not Google Chrome. Download metadata and transport are from Google; integrity checks do not prove a build is bug-free. No existing browser data is removed. Install only if you accept maintaining browser updates yourself.') 'INSTALL')){return [pscustomobject]@{Status='Cancelled'}}
 $root=Join-Path $env:LOCALAPPDATA 'KKxtti\Chromium';Assert-InstallerDirectory $root $root
 $destination=Join-Path $root ($plan.Revision+'-'+[guid]::NewGuid().ToString('N').Substring(0,8));Assert-InstallerDirectory $destination $root
 $null=New-Item -ItemType Directory -Path $destination -Force;$archive=Join-Path $destination 'download.zip'
 Write-Host ('Downloading official Chromium revision '+$plan.Revision+'...')
 Invoke-WebRequest -Uri $plan.Url -OutFile $archive -UseBasicParsing -TimeoutSec 600
 if((Get-Item -LiteralPath $archive).Length -ne $plan.Size){throw 'Chromium download length mismatch. No executable was launched.'}
 $stream=[IO.File]::OpenRead($archive);$md5=[Security.Cryptography.MD5]::Create();try{$digest=[Convert]::ToBase64String($md5.ComputeHash($stream))}finally{$stream.Dispose();$md5.Dispose()}
 if($digest -cne $plan.Md5){throw 'Chromium download does not match Google object metadata. No executable was launched.'}
 $sha=(Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash
 Expand-ReviewedChromium $archive $destination
 $exe=Join-Path $destination 'chrome-win\chrome.exe'
 $signature=Get-AuthenticodeSignature -LiteralPath $exe
 if($signature.Status -notin @('Valid','NotSigned')){throw 'Chromium executable has an invalid signature. Installation stopped.'}
 $record=[pscustomobject]@{Revision=$plan.Revision;Generation=$plan.Generation;ArchiveSha256=$sha;GoogleMd5=$digest;Signature=[string]$signature.Status;Path=$exe;AutoUpdates=$false;Installed=(Get-Date).ToString('o')}
 $record | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $root 'installed.json') -Encoding UTF8
 $menu=Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs';Assert-InstallerDirectory $menu $menu
 $shortcut=Join-Path $menu 'KKxtti Chromium.lnk';if(Test-Path -LiteralPath $shortcut){Assert-InstallerDirectory $shortcut $menu}
 $shell=New-Object -ComObject WScript.Shell;$link=$shell.CreateShortcut($shortcut);$link.TargetPath=$exe;$link.WorkingDirectory=Split-Path -Parent $exe;$link.Description='Official Chromium snapshot; update manually with KKxtti';$link.Save()
 [pscustomobject]@{Status='Installed; manual updates required';Path=$exe;Revision=$plan.Revision;Sha256=$sha}
}
function Install-ManagedTools([string[]]$Ids) {
 if(-not $Ids -or $Ids.Count -gt 3){throw 'Choose one to three apps.'}
 $catalog=@(Get-InstallerCatalog);$chosen=@()
 foreach($id in ($Ids | Select-Object -Unique)){$item=@($catalog | Where-Object Id -ceq $id);if($item.Count -ne 1){throw 'Unknown installer selection.'};$chosen+=$item[0]}
 $winget=$null;if(@($chosen | Where-Object Id -ne 'chromium').Count){$winget=Get-TrustedWinget;Assert-OfficialWingetSource $winget}
 $saved=New-ControlJournal 'install' @($chosen | ForEach-Object {[pscustomobject]@{Id=$_.Id;Package=$_.Package;Status='Pending';ExitCode=$null;Error=''}})
 foreach($row in $saved.Journal.Rows){
  try{
   if($row.Id -eq 'chromium'){$result=Install-OfficialChromium;$row.Status=$result.Status}
   else{
    Assert-OfficialWingetSource $winget
    Write-Host ('Installing '+$row.Package+' through verified Microsoft WinGet source...')
    $r=Invoke-InstallerProcess $winget @('install','--id',$row.Package,'--exact','--source','winget','--architecture','x64','--silent','--no-upgrade','--accept-source-agreements','--accept-package-agreements','--disable-interactivity')
    Write-Host $r.Output;if($r.Error){Write-Host $r.Error};$row.ExitCode=$r.Code
    $fresh=@(Get-InstallerStates | Where-Object Id -ceq $row.Id)
    $hex=([BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$r.Code),0)).ToString('X8')
    if($r.Code -ne 0 -and -not($hex -in @('8A150061','8A15010D') -and $fresh[0].State -like 'Installed*')){throw ('WinGet exit '+$r.Code+'. No security checks were bypassed. Inspect the log; installation may have partly completed.')}
    $row.Status=if($fresh[0].State -like 'Installed*'){'Installed (verified inventory)'}else{'WinGet succeeded; inventory verification pending'}
   }
  }catch{$row.Status='Failed / inspect log';$row.Error=$_.Exception.Message}
  Save-ControlJournal $saved.Path $saved.Journal
  if($row.Status -eq 'Cancelled'){foreach($pending in $saved.Journal.Rows){if($pending.Status -eq 'Pending'){$pending.Status='Not started (cancelled)'}};break}
 }
 $saved.Journal.Status=if(@($saved.Journal.Rows | Where-Object {$_.Status -like 'Failed*'}).Count){'Some installs failed'}else{'Completed; see per-app results'};Save-ControlJournal $saved.Path $saved.Journal
 $saved.Journal.Rows
}
function Uninstall-ReviewedDesktopApp([ValidateSet('edge','onedrive')]$Id) {
 $package=if($Id -eq 'edge'){'Microsoft.Edge'}else{'Microsoft.OneDrive'}
 $warning=if($Id -eq 'edge'){'Uses the supported installed-package uninstaller only. Windows may prohibit removal in your region/build. No fake executable, forced protected-file deletion, WebView2 removal or ACL bypass is used. Export bookmarks first.'}else{'Back up and fully download your needed cloud-only files first. Close OneDrive. Uninstalls the client only; does not deliberately delete local folders. This does not back up your files and has no automatic undo.'}
 if(-not(Confirm-Action ($package+': '+$warning) 'UNINSTALL')){return}
 $winget=Get-TrustedWinget;Assert-OfficialWingetSource $winget
 $r=Invoke-InstallerProcess $winget @('uninstall','--id',$package,'--exact','--source','winget','--disable-interactivity','--accept-source-agreements')
 Write-Host $r.Output;if($r.Error){Write-Host $r.Error};if($r.Code -ne 0){throw ('Uninstall unavailable or failed (WinGet '+$r.Code+'). Windows restrictions were not bypassed.')}
 [pscustomobject]@{Status='Uninstaller completed; inspect Installed apps';Package=$package}
}
