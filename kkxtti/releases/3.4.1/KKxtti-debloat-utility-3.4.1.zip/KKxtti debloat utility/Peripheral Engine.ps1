#requires -Version 5.1
# Present PnP devices only. IDs remain in memory; no serials/telemetry uploaded.
function Get-PeripheralNodes { @(Get-PnpDevice -PresentOnly -Class Mouse,Keyboard -ErrorAction Stop) }
function Get-PeripheralProperties([string]$Id) {
 $result=@{}
 foreach($property in Get-PnpDeviceProperty -InstanceId $Id -KeyName 'DEVPKEY_Device_BusReportedDeviceDesc','DEVPKEY_Device_FriendlyName','DEVPKEY_Device_Parent','DEVPKEY_Device_ContainerId' -ErrorAction SilentlyContinue){if($null -ne $property.PSObject.Properties['Data']){$result[$property.KeyName]=$property.Data}}
 $result
}
function Test-GenericPeripheralName([string]$Name) {
 [string]::IsNullOrWhiteSpace($Name) -or $Name -match '^(HID[- ]|USB (Input Device|Receiver|Composite Device)|Standard |Microsoft |\(Standard)' -or $Name -match '(?i)root hub|host controller'
}
function Get-ConnectedPeripherals {
 $cache=@{};$rows=@{}
 foreach($node in Get-PeripheralNodes){
  $id=[string]$node.InstanceId;$cursor=$id;$name=[string]$node.FriendlyName;$container='';$candidates=@();$visited=@{}
  for($depth=0;$depth -lt 4 -and $cursor -and -not $visited.ContainsKey($cursor);$depth++){
   $visited[$cursor]=$true
   if(-not $cache.ContainsKey($cursor)){$cache[$cursor]=Get-PeripheralProperties $cursor};$properties=$cache[$cursor]
   if(-not $container -and $properties.ContainsKey('DEVPKEY_Device_ContainerId')){$value=[string]$properties['DEVPKEY_Device_ContainerId'];if($value -and $value -ne '00000000-0000-0000-0000-000000000000'){$container=$value}}
   foreach($key in @('DEVPKEY_Device_FriendlyName','DEVPKEY_Device_BusReportedDeviceDesc')){if($properties.ContainsKey($key) -and -not(Test-GenericPeripheralName ([string]$properties[$key]))){$candidates+=[string]$properties[$key]}}
   $cursor=if($properties.ContainsKey('DEVPKEY_Device_Parent')){[string]$properties['DEVPKEY_Device_Parent']}else{''}
  }
  if($candidates.Count){$name=$candidates[0]}
  if(-not $name){$name='Unnamed input device'}
  # A receiver does not reliably reveal which wireless product is paired.
  $receiver=$name -match '(?i)receiver|dongle';$virtual=$id -match '^(ROOT|SWD)\\' -or $name -match '(?i)virtual|virhid'
  $group=if($container){$container+'|'+$name}else{$id}
  if(-not $rows.ContainsKey($group)){$rows[$group]=[pscustomobject]@{Name=$name;Ids=@();Roles=@();Receiver=$receiver;Virtual=$virtual}}
  $row=$rows[$group];$row.Ids+= $id
  if([string]$node.Class -notin $row.Roles){$row.Roles+=[string]$node.Class}
 }
 foreach($row in $rows.Values|Sort-Object Virtual,Name){[pscustomobject]@{Name=$row.Name;Ids=($row.Ids -join '|');Roles=($row.Roles -join ' + ');Receiver=$row.Receiver;Virtual=$row.Virtual;Note=$(if($row.Receiver){'Receiver detected; paired model and polling rate are not reported reliably.'}elseif($row.Virtual){'Virtual input interface reported by Windows.'}else{'Present input device; multiple HID interfaces are grouped together.'})}}
}
