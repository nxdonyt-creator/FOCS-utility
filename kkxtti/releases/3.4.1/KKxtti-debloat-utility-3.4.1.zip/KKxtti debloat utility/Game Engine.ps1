#requires -Version 5.1
# Only existing, reviewed configuration keys are edited. No game launch,
# memory access, macros, protected files, or read-only-attribute tricks.
function Get-GameConfigs {
 $fortnite=Join-Path $env:LOCALAPPDATA 'FortniteGame\Saved\Config\WindowsClient\GameUserSettings.ini'
 if(Test-Path -LiteralPath $fortnite -PathType Leaf){[pscustomobject]@{Id='fortnite';Name='Fortnite';Path=$fortnite;Game='fortnite'}}
 $siege=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games\Rainbow Six - Siege'
 if(Test-Path -LiteralPath $siege -PathType Container){foreach($dir in Get-ChildItem -LiteralPath $siege -Directory){$parsed=[guid]::Empty;if([guid]::TryParseExact($dir.Name,'D',[ref]$parsed)){$path=Join-Path $dir.FullName 'GameSettings.ini';if(Test-Path -LiteralPath $path -PathType Leaf){[pscustomobject]@{Id=('siege-'+$parsed.ToString());Name=('Rainbow Six Siege / '+$dir.Name.Substring(0,8));Path=$path;Game='siege'}}}}}
}
function Get-ExactGameConfig([string]$GameId) {
 if($GameId -cne 'fortnite' -and $GameId -cnotmatch '^siege-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$'){throw 'Invalid game profile.'}
 $found=@(Get-GameConfigs | Where-Object Id -ceq $GameId)
 if($found.Count -ne 1){throw 'The game configuration is unavailable. Start and close the game once, then refresh.'}
 $item=Get-Item -LiteralPath $found[0].Path -ErrorAction Stop
 if($item.Length -gt 2MB){throw 'Game configuration exceeds the supported size.'}
 $current=$item
 while($null -ne $current){if($current.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'A redirected file or junction was detected. Change this configuration in the game instead.'};$current=if($current -is [IO.FileInfo]){$current.Directory}else{$current.Parent}}
 $found[0]
}
function Assert-GameClosed([string]$Game) {
 $names=if($Game -eq 'fortnite'){@('FortniteClient-Win64-Shipping','FortniteClient-Win64-Shipping_EAC_EOS','FortniteClient-Win64-Shipping_BE','FortniteLauncher')}else{@('RainbowSix','RainbowSix_DX12','RainbowSix_Vulkan','RainbowSix_BE')}
 if(@(Get-Process -ErrorAction Stop | Where-Object { $_.ProcessName -in $names }).Count){throw 'Close the game before saving or restoring its settings.'}
}
function Get-GameFieldCatalog([string]$Game) {
 if($Game -eq 'fortnite'){
  @([pscustomobject]@{Id='vsync';Section='/Script/FortniteGame.FortGameUserSettings';Key='bUseVSync';On='True';Off='False'},[pscustomobject]@{Id='fps-cap';Section='/Script/FortniteGame.FortGameUserSettings';Key='FrameRateLimit'},[pscustomobject]@{Id='show-fps';Section='/Script/FortniteGame.FortGameUserSettings';Key='bShowFPS';On='True';Off='False'})
 }elseif($Game -eq 'siege'){
  @([pscustomobject]@{Id='vsync';Section='DISPLAY_SETTINGS';Key='VSync';On='1';Off='0'},[pscustomobject]@{Id='fps-cap';Section='DISPLAY';Key='FPSLimit'})
 }else{throw 'Unknown game.'}
}
function Read-GameDocument([string]$Path) {
 $bytes=[IO.File]::ReadAllBytes($Path);$skip=0;$encoding=New-Object Text.UTF8Encoding($false,$true)
 if($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191){$skip=3;$encoding=New-Object Text.UTF8Encoding($true,$true)}
 elseif($bytes.Length -ge 2 -and $bytes[0] -eq 255 -and $bytes[1] -eq 254){$skip=2;$encoding=New-Object Text.UnicodeEncoding($false,$true,$true)}
 elseif($bytes.Length -ge 2 -and $bytes[0] -eq 254 -and $bytes[1] -eq 255){$skip=2;$encoding=New-Object Text.UnicodeEncoding($true,$true,$true)}
 [pscustomobject]@{Bytes=$bytes;Text=$encoding.GetString($bytes,$skip,$bytes.Length-$skip);Encoding=$encoding}
}
function Find-GameField([string]$Text,$Spec) {
 $section='';$found=@();$offset=0
 foreach($line in [regex]::Split($Text,'(?<=\n)')) {
  if($line -match '^\s*\[([^\]\r\n]+)\]\s*(?:\r?\n)?$'){$section=$Matches[1]}
  elseif($section -ceq $Spec.Section -and $line -match ('^(\s*'+[regex]::Escape($Spec.Key)+'\s*=)([^\r\n]*)(\r?\n)?$')) {
   $found+=[pscustomobject]@{Value=$Matches[2].Trim();Start=$offset+$Matches[1].Length;Length=$Matches[2].Length}
  }
  $offset+=$line.Length
 }
 if($found.Count -ne 1){throw ('Expected one existing '+$Spec.Key+' setting. This game version may use a different format.')}
 $found[0]
}
function Get-GameState([string]$GameId) {
 $config=Get-ExactGameConfig $GameId;$doc=Read-GameDocument $config.Path
 foreach($field in Get-GameFieldCatalog $config.Game){try{$value=(Find-GameField $doc.Text $field).Value;[pscustomobject]@{Id=$field.Id;Value=$value;Available=$true}}catch{[pscustomobject]@{Id=$field.Id;Value='Unavailable';Available=$false}}}
}
function Get-BytesHash([byte[]]$Bytes) {$hash=[Security.Cryptography.SHA256]::Create();try{[BitConverter]::ToString($hash.ComputeHash($Bytes)).Replace('-','')}finally{$hash.Dispose()}}
function Convert-GameTextBytes($Document,[string]$Text) {[byte[]]($Document.Encoding.GetPreamble()+$Document.Encoding.GetBytes($Text))}
function Write-GameDocument($Config,[byte[]]$Expected,[byte[]]$Replacement) {
 Assert-GameClosed $Config.Game
 $config=Get-ExactGameConfig $Config.Id
 if((Get-Item -LiteralPath $config.Path).Attributes -band [IO.FileAttributes]::ReadOnly){throw 'The game configuration is read-only. KKxtti does not change its protection; remove read-only yourself if intentional.'}
 $temp=$config.Path+'.kkxtti-'+[guid]::NewGuid().ToString('N')+'.tmp'
 try {
  [IO.File]::WriteAllBytes($temp,$Replacement)
  if((Get-BytesHash ([IO.File]::ReadAllBytes($config.Path))) -cne (Get-BytesHash $Expected)){throw 'The game or another program changed this file. Nothing was overwritten.'}
  Assert-GameClosed $config.Game
  [IO.File]::Replace($temp,$config.Path,[NullString]::Value)
  if((Get-BytesHash ([IO.File]::ReadAllBytes($config.Path))) -cne (Get-BytesHash $Replacement)){throw 'The saved game configuration could not be verified. Check the backup before proceeding.'}
 }finally{if([IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
}
function Assert-GameFieldValue([string]$Game,[string]$Field,[string]$Value) {
 if($Field -eq 'fps-cap'){$n=0.0;if(-not [double]::TryParse($Value,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$n) -or [double]::IsNaN($n) -or [double]::IsInfinity($n) -or $n -lt 0 -or $n -gt 1000){throw 'Invalid saved frame cap.'}}
 elseif($Field -eq 'vsync'){if(($Game -eq 'fortnite' -and $Value -cnotin @('True','False')) -or ($Game -eq 'siege' -and $Value -cnotin @('0','1','2'))){throw 'Invalid V-Sync value.'}}
 elseif($Field -eq 'show-fps' -and $Game -eq 'fortnite'){if($Value -cnotin @('True','False')){throw 'Invalid FPS display value.'}}
 else{throw 'Unknown game setting.'}
}
function Set-GameSetting([string]$GameId,[string]$Field,[string]$Value) {
 $config=Get-ExactGameConfig $GameId;Assert-GameClosed $config.Game
 $spec=@(Get-GameFieldCatalog $config.Game | Where-Object Id -ceq $Field);if($spec.Count -ne 1){throw 'Unsupported game setting.'}
 Assert-GameFieldValue $config.Game $Field $Value
 if($Field -eq 'fps-cap' -and $Value -cnotin @('0','120','144','165','180','200','240','300','360','480')){throw 'Choose a supported frame cap.'}
 $doc=Read-GameDocument $config.Path;$match=Find-GameField $doc.Text $spec[0];Assert-GameFieldValue $config.Game $Field $match.Value
 if($match.Value -ceq $Value -or ($Field -eq 'fps-cap' -and [double]::Parse($match.Value,[Globalization.CultureInfo]::InvariantCulture) -eq [double]::Parse($Value,[Globalization.CultureInfo]::InvariantCulture))){return [pscustomobject]@{Status='Already configured';Id=''}}
 $rows=@([pscustomobject]@{Id=$Field;Before=$match.Value;After=$Value})
 $saved=New-ControlJournal 'game' $rows;$saved.Journal | Add-Member NoteProperty GameId $config.Id;Save-ControlJournal $saved.Path $saved.Journal
 [IO.File]::WriteAllBytes((Join-Path (Split-Path -Parent $saved.Path) 'before.ini'),$doc.Bytes)
 $text=$doc.Text.Remove($match.Start,$match.Length).Insert($match.Start,$Value)
 try{Write-GameDocument $config $doc.Bytes (Convert-GameTextBytes $doc $text);$saved.Journal.Status='Applied';Save-ControlJournal $saved.Path $saved.Journal}catch{$saved.Journal.Status='Recovery needed';try{Save-ControlJournal $saved.Path $saved.Journal}catch{};throw}
 [pscustomobject]@{Status='Applied';Id=$saved.Journal.Id}
}
function Undo-GameSetting([string]$Id) {
 if($Id -cnotmatch '^game-\d{8}-\d{6}-[a-f0-9]{8}$'){throw 'Invalid game backup.'}
 $path=Join-Path (Join-Path (Join-Path $script:ControlRoot 'State') $Id) 'transaction.json'
 if((Get-Item -LiteralPath $path).Length -gt 2MB){throw 'Game backup exceeds size limit.'}
 $j=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
 if($j.Schema -ne 1 -or $j.Id -cne $Id -or $j.Status -ne 'Applied' -or $j.Computer -ne $env:COMPUTERNAME -or $j.Sid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -or @($j.Rows).Count -ne 1){throw 'This is not an applied game change for this account and PC.'}
 $config=Get-ExactGameConfig $j.GameId;Assert-GameClosed $config.Game;$row=$j.Rows[0]
 Assert-GameFieldValue $config.Game $row.Id $row.Before;Assert-GameFieldValue $config.Game $row.Id $row.After
 $spec=@(Get-GameFieldCatalog $config.Game | Where-Object Id -ceq $row.Id);if($spec.Count -ne 1){throw 'Unknown saved game setting.'}
 $doc=Read-GameDocument $config.Path;$match=Find-GameField $doc.Text $spec[0]
 if($match.Value -cne $row.After){throw 'A newer change or the game changed this setting. Automatic restore stopped before overwriting it.'}
 $text=$doc.Text.Remove($match.Start,$match.Length).Insert($match.Start,$row.Before)
 $j.Status='Undoing';Save-ControlJournal $path $j
 try{Write-GameDocument $config $doc.Bytes (Convert-GameTextBytes $doc $text);$j.Status='Undone';Save-ControlJournal $path $j}catch{$j.Status='Recovery needed';try{Save-ControlJournal $path $j}catch{};throw}
 [pscustomobject]@{Status='Undone';Id=$Id}
}
