#requires -Version 5.1
function Get-KKxttiResetRecords {
 $state=Join-Path $script:ControlRoot 'State';if(-not(Test-Path -LiteralPath $state)){return}
 if((Get-Item -LiteralPath $state).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'State is linked; inspect it manually.'}
 $rows=@();$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
 foreach($dir in Get-ChildItem -LiteralPath $state -Directory){
  if($dir.Name -cnotmatch '^(settings|network|dns|system|game|ultimate|nvidia|fortnite)-\d{8}-\d{6}-[a-f0-9]{8}$'){continue}
  if($dir.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'A saved change is linked. Inspect Backups.'}
  $path=Join-Path $dir.FullName 'transaction.json';$file=Get-Item -LiteralPath $path -ErrorAction Stop
  if($file.Length -gt 2MB -or $file.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Invalid saved change. Inspect Backups.'}
  $j=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json
  if($j.Schema -ne 1 -or $j.Id -cne $dir.Name -or $j.Computer -ne $env:COMPUTERNAME -or $j.Sid -ne $sid){throw 'A saved change belongs to a different account/PC or is invalid.'}
  if($j.Status -notin @('Applied','Prepared','Undoing','Recovery needed')){continue}
  $created=[DateTimeOffset]::MinValue;if(-not [DateTimeOffset]::TryParse([string]$j.Created,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind,[ref]$created)){throw 'Invalid saved change time.'}
  $rows+=[pscustomobject]@{Id=$j.Id;Kind=$dir.Name.Split('-')[0];Status=$j.Status;Created=$created;GameId=$(if($j.PSObject.Properties['GameId']){[string]$j.GameId}else{''})}
 }
 $rows|Sort-Object Created -Descending
}
function Invoke-KKxttiUndoRecord($Record) {
 switch -CaseSensitive ($Record.Kind){
  'settings'{Undo-ControlSettings $Record.Id}
  'network'{Undo-NetworkSettings $Record.Id}
  'dns'{Undo-SelectedDnsProfile $Record.Id}
  'system'{Undo-SystemControl $Record.Id}
  'game'{Undo-GameSetting $Record.Id}
  'ultimate'{Undo-UltimateTestPlan $Record.Id}
  'nvidia'{Undo-NvidiaProfile $Record.Id}
  'fortnite'{Undo-FortnitePotatoProfile $Record.Id}
  default{throw 'This action has no automatic Reset.'}
 }
}
function Reset-LatestGamingProfile([string]$Kind,[string]$GameId='') {
 if($Kind -cnotin @('ultimate','nvidia','fortnite')){throw 'Unknown gaming profile.'}
 $record=@(Get-KKxttiResetRecords|Where-Object {$_.Kind -ceq $Kind -and (-not $GameId -or $_.GameId -ceq $GameId)}|Select-Object -First 1)
 if(-not $record.Count){return [pscustomobject]@{Status='No saved profile to reset';Id=''}}
 Invoke-KKxttiUndoRecord $record[0]
}
function Reset-KKxttiSavedSettings {
 Require-Admin
 $records=@(Get-KKxttiResetRecords)
 if(-not $records.Count){return [pscustomobject]@{Status='No saved changes to reset';Count=0}}
 if(@($records|Where-Object Status -cne 'Applied').Count){throw 'An interrupted change needs individual recovery in Backups before Reset all.'}
 if(-not(Confirm-Action ('Reset '+$records.Count+' saved, reversible KKxtti changes from newest to oldest?'+[Environment]::NewLine+(($records|ForEach-Object {$_.Id}) -join [Environment]::NewLine)+[Environment]::NewLine+'Close games and other settings editors. Network/DNS restoration can affect connectivity; some Windows changes need a later restart. This restores your saved values, not factory defaults. Removed apps/files, encryption, external changes and older release folders are excluded. Reset stops on a conflict and reports any earlier completed restores.') 'RESET')){return}
 $current=@(Get-KKxttiResetRecords)
 if(($current.Id -join '|') -cne ($records.Id -join '|') -or @($current|Where-Object Status -cne 'Applied').Count){throw 'The saved change list changed during review.'}
 # The single review above authorizes this exact list. Each undo still validates
 # ownership, allowed values and the current state before writing.
 $resetConfirmation=${function:Confirm-Action}
 function Confirm-Action($Message,$Word){if($Word -eq 'DELETE'){& $resetConfirmation $Message $Word}else{$true}}
 $count=0
 foreach($record in $records){try{$null=Invoke-KKxttiUndoRecord $record;$count++}catch{throw ('Reset stopped after '+$count+' completed restore(s). '+$record.Id+': '+$_.Exception.Message)}}
 [pscustomobject]@{Status='Saved settings restored';Count=$count}
}
