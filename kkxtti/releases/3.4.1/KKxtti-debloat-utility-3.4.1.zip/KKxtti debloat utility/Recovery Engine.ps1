#requires -Version 5.1
# Recovery restores only reviewed values whose current state still matches
# either side of an interrupted transaction. Conflicts are never overwritten.
function Read-RecoveryJournal([string]$Id) {
 if($Id -cnotmatch '^(settings|network|game)-\d{8}-\d{6}-[a-f0-9]{8}$'){throw 'Invalid recovery record.'}
 $path=Join-Path (Join-Path (Join-Path $script:ControlRoot 'State') $Id) 'transaction.json'
 if((Get-Item -LiteralPath $path).Length -gt 2MB){throw 'Recovery record exceeds size limit.'}
 $j=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
 if($j.Schema -ne 1 -or $j.Id -cne $Id -or $j.Status -notin @('Prepared','Undoing','Recovery needed') -or $j.Computer -ne $env:COMPUTERNAME -or $j.Sid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'This is not an interrupted transaction for this PC and account.'}
 if(@($j.Rows).Count -eq 0 -or @($j.Rows).Count -gt 400){throw 'Invalid recovery rows.'}
 [pscustomobject]@{Path=$path;Journal=$j}
}
function Get-RecoveryPlan([string]$Id) {
 $saved=Read-RecoveryJournal $Id;$j=$saved.Journal;$kind=$Id.Split('-')[0];$seen=@{}
 if($kind -eq 'network'){$adapter=Get-ExactNetworkAdapter $j.Adapter.Id;Assert-NetworkHardware $adapter $j.Adapter}
 if($kind -eq 'game'){$config=Get-ExactGameConfig $j.GameId;$doc=Read-GameDocument $config.Path;if(@($j.Rows).Count -ne 1){throw 'Invalid game recovery rows.'}}
 foreach($row in $j.Rows) {
  $key=[string]$row.Id
  if($kind -eq 'settings'){$spec=Get-ControlSpec $row;Assert-ControlValue $row.Before;Assert-ControlValue $row.After;$key+=':'+$row.Index;$current=Read-ControlValue $spec;$before=Test-ControlEqual $current $row.Before;$after=Test-ControlEqual $current $row.After}
  elseif($kind -eq 'network'){Assert-NetworkRow $row;$key+=':'+$row.Keyword;$p=Get-NetworkProperty $adapter $row.Keyword;if($row.Before -cnotin $p.ValidRegistryValues -or $row.After -cnotin $p.ValidRegistryValues){throw 'Driver no longer supports the saved recovery values.'};$current=[string]$p.RegistryValue[0];$before=$current -ceq $row.Before;$after=$current -ceq $row.After}
  else{Assert-GameFieldValue $config.Game $row.Id $row.Before;Assert-GameFieldValue $config.Game $row.Id $row.After;$spec=@(Get-GameFieldCatalog $config.Game | Where-Object Id -ceq $row.Id);if($spec.Count -ne 1){throw 'Unknown game recovery key.'};$current=(Find-GameField $doc.Text $spec[0]).Value;$before=$current -ceq $row.Before;$after=$current -ceq $row.After}
  if($seen.ContainsKey($key)){throw 'Duplicate recovery row.'};$seen[$key]=$true
  [pscustomobject]@{Key=$key;Action=$(if($before){'Already original'}elseif($after){'Restore original'}else{'Conflict - stop'});Kind=$kind}
 }
}
function Restore-InterruptedChange([string]$Id) {
 $saved=Read-RecoveryJournal $Id;$j=$saved.Journal;$plan=@(Get-RecoveryPlan $Id)
 if(@($plan | Where-Object Action -eq 'Conflict - stop').Count){throw 'A setting has a value outside this transaction. Automatic recovery stopped; no settings were changed.'}
 $kind=$Id.Split('-')[0]
 if($kind -eq 'network'){Assert-NetworkAdmin}
 if($kind -eq 'game'){$config=Get-ExactGameConfig $j.GameId;Assert-GameClosed $config.Game}
 $rows=@();for($i=0;$i -lt $plan.Count;$i++){if($plan[$i].Action -eq 'Restore original'){$rows+=$j.Rows[$i]}}
 if(-not $rows.Count){$j.Status='Undone';Save-ControlJournal $saved.Path $j;return [pscustomobject]@{Status='Already original';Id=$Id}}
 # Persist the recovery intent before touching settings, even on a second attempt.
 $j.Status='Recovery needed';Save-ControlJournal $saved.Path $j
 if($kind -eq 'settings'){
  try{Invoke-ControlRows $rows 'Undo' $saved}catch{$j.Status='Recovery needed';try{Save-ControlJournal $saved.Path $j}catch{};throw}
 }elseif($kind -eq 'network'){
  try{$adapter=Get-ExactNetworkAdapter $j.Adapter.Id;Invoke-NetworkRows $rows $adapter $saved 'Undo'}catch{$j.Status='Recovery needed';try{Save-ControlJournal $saved.Path $j}catch{};throw}
 }else{
  $row=$rows[0];$doc=Read-GameDocument $config.Path;$spec=@(Get-GameFieldCatalog $config.Game | Where-Object Id -ceq $row.Id);$match=Find-GameField $doc.Text $spec[0]
  if($match.Value -cne $row.After){throw 'The game setting changed during recovery. No file was overwritten.'}
  $text=$doc.Text.Remove($match.Start,$match.Length).Insert($match.Start,$row.Before)
  Write-GameDocument $config $doc.Bytes (Convert-GameTextBytes $doc $text);$j.Status='Undone';Save-ControlJournal $saved.Path $j
  [pscustomobject]@{Status='Undone';Id=$Id}
 }
}
