#requires -Version 5.1
# Per-game driver settings and a separate custom power plan; never run on import.
function Import-ProfileNative {
 if(-not ('KKxtti.NvidiaSession' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'source\NvidiaApi.cs') -ErrorAction Stop}
}
function Open-NvidiaSession([string]$GameId) {
 Import-ProfileNative
 $app=switch -CaseSensitive ($GameId){'fortnite'{'fortniteclient-win64-shipping.exe'}'siege'{'rainbowsix.exe'}default{throw 'Unsupported NVIDIA game.'}}
 [KKxtti.NvidiaSession]::new($app)
}
function Get-NvidiaCatalog {
 @(
  [pscustomobject]@{Id=0x1057EB71;Name='Power management';Target=1;Label='Prefer maximum performance';Note='Higher GPU power and heat while this game runs.'}
  [pscustomobject]@{Id=0x00CE2691;Name='Texture filtering quality';Target=20;Label='High performance';Note='Trades filtering quality for speed; shimmering is possible.'}
  [pscustomobject]@{Id=0x00A879CF;Name='Vertical sync';Target=0x08416747;Label='Off';Note='Competitive tearing-allowed profile; do not combine with a tear-free G-SYNC setup.'}
  [pscustomobject]@{Id=0x10835002;Name='Driver frame limiter';Target=0;Label='Off / use the in-game cap';Note='Keeps a single limiter under your control.'}
 )
}
# IDs are NVIDIA NVAPI public settings; DX LOD units are eighths in Profile Inspector.
# +1.5 = 12 (0x0C), +3.0 = 24 (0x18), not IEEE float bit patterns.
function Get-NvidiaPresetCatalog([ValidateSet('competitive','potato')][string]$Preset='competitive',[ValidateSet('mild','strong')][string]$LodPreset='strong') {
 if($Preset -eq 'competitive'){Get-NvidiaCatalog;return}
 $lod=if($LodPreset -eq 'mild'){12}else{24};$label=if($LodPreset -eq 'mild'){'+1.5000'}else{'+3.0000'}
 @(
  [pscustomobject]@{Id=0x00738E8F;Name='Texture filtering - LOD bias (DX)';Target=$lod;Label=$label;Note='Positive bias requests coarser mip levels; renderer-dependent. Saved state does not prove a visual effect.'}
  [pscustomobject]@{Id=0x00CE2691;Name='Texture filtering quality';Target=20;Label='High performance';Note='Reduces filtering quality; inspect texture clarity and shimmering.'}
  [pscustomobject]@{Id=0x10D2BB16;Name='Anisotropic filtering mode';Target=1;Label='User-defined override';Note='Requests a driver filtering override for the game profile.'}
  [pscustomobject]@{Id=0x101E61A9;Name='Anisotropic filtering level';Target=1;Label='1x / linear';Note='Reduces filtering quality on angled surfaces when honored.'}
 )
}
function Reset-LatestNvidiaPreset([ValidateSet('fortnite','siege')][string]$GameId,[ValidateSet('competitive','potato')][string]$Preset) {
 $records=@(Get-KKxttiResetRecords|Where-Object {$_.Kind -ceq 'nvidia' -and $_.GameId -ceq $GameId})
 foreach($record in $records){
  $saved=Read-ProfileJournal $record.Id 'nvidia'
  $kind=if($saved.Journal.PSObject.Properties['Preset']){[string]$saved.Journal.Preset}else{'competitive'}
  if($kind -ceq $Preset){Undo-NvidiaProfile $record.Id;return}
 }
 [pscustomobject]@{Status='No saved '+$Preset+' NVIDIA profile to reset in this version';Id=''}
}
function Get-NvidiaState([string]$GameId,[ValidateSet('competitive','potato')][string]$Preset='competitive',[ValidateSet('mild','strong')][string]$LodPreset='strong') {
 if($Preset -eq 'potato' -and $GameId -cne 'fortnite'){throw 'The potato driver profile supports Fortnite only.'}
 $session=Open-NvidiaSession $GameId
 try{foreach($spec in (Get-NvidiaPresetCatalog $Preset $LodPreset)){$value=$session.Get([uint32]$spec.Id);$label=if(-not $value.Found){'Driver default'}elseif($value.Value -eq $spec.Target){$spec.Label}else{'Custom / driver-defined'};if($value.Found){$label+=if($value.Local){' (game override)'}else{' (inherited)'}};[pscustomobject]@{Id=$spec.Id;Name=$spec.Name;Target=$spec.Label;Current=$(if($value.Found){[string]$value.Value}else{'Driver default'});CurrentLabel=$label;Local=$value.Local;Profile=$session.ProfileName;Note=$spec.Note}}}finally{$session.Dispose()}
}
function Assert-NvidiaValue($Value) {
 if($Value.Local -isnot [bool] -or $Value.Found -isnot [bool]){throw 'Invalid saved NVIDIA flags.'}
 $number=0L;if(-not [long]::TryParse([string]$Value.Value,[ref]$number) -or $number -lt 0 -or $number -gt [uint32]::MaxValue){throw 'Invalid saved NVIDIA value.'}
 if($Value.Local -and -not $Value.Found){throw 'Invalid local NVIDIA value.'}
}
function Test-NvidiaValue($A,$B) {
 # Inherited values can change with a driver/global-profile update. Never
 # manufacture a local override when the prior value was inherited.
 $A.Local -eq $B.Local -and $A.Found -eq $B.Found -and (-not $A.Found -or [uint32]$A.Value -eq [uint32]$B.Value)
}
function Set-NvidiaPerformanceProfile([string]$GameId) { Set-NvidiaReviewedProfile -GameId $GameId -Preset competitive }
function Set-NvidiaPotatoProfile([ValidateSet('mild','strong')][string]$LodPreset='strong') { Set-NvidiaReviewedProfile -GameId fortnite -Preset potato -LodPreset $LodPreset }
function Set-NvidiaReviewedProfile([string]$GameId,[ValidateSet('competitive','potato')][string]$Preset,[ValidateSet('mild','strong')][string]$LodPreset='strong') {
 if($Preset -eq 'potato' -and $GameId -cne 'fortnite'){throw 'The potato driver profile supports Fortnite only.'}
 Require-Admin;Assert-GameClosed $GameId
 $specs=@(Get-NvidiaPresetCatalog $Preset $LodPreset);$rows=@();$session=Open-NvidiaSession $GameId
 try{$profile=$session.ProfileName;foreach($spec in $specs){$before=$session.Get([uint32]$spec.Id);$after=[pscustomobject]@{Found=$true;Local=$true;Value=[uint32]$spec.Target};if(-not(Test-NvidiaValue $before $after)){$rows+=[pscustomobject]@{Id=$spec.Id;Before=[pscustomobject]@{Found=[bool]$before.Found;Local=[bool]$before.Local;Value=[uint32]$before.Value};After=$after}}}}finally{$session.Dispose()}
 if(-not $rows.Count){return [pscustomobject]@{Status='Already configured';Id=''}}
 $description=($specs|ForEach-Object {$_.Name+': '+$_.Label}) -join [Environment]::NewLine
 $impact=if($Preset -eq 'potato'){'This NVIDIA texture profile requests blurrier textures using positive Direct3D LOD bias and 1x filtering. The game/renderer/driver may ignore overrides, especially on newer rendering paths. Current Fortnite uses DX12. Readback proves the saved profile only, not the visual effect or FPS gain. Game configuration files, resolution, sensitivity, power, V-Sync and FPS cap are unchanged. Close the game and other NVIDIA profile editors. Reset restores the saved overrides or original inheritance.'}else{'V-Sync off permits tearing. Maximum performance can increase heat. Use in-game Reflex where available. Your previous overrides are saved for Reset. Close NVIDIA Control Panel/Profile Inspector while applying.'}
 if(-not(Confirm-Action ('Apply the '+$Preset+' NVIDIA profile to '+$profile+'?'+[Environment]::NewLine+$description+[Environment]::NewLine+$impact) 'APPLY')){return}
 Assert-GameClosed $GameId;$session=Open-NvidiaSession $GameId;$saved=$null
 try{
  if($session.ProfileName -cne $profile){throw 'The NVIDIA game profile changed during review.'}
  foreach($row in $rows){if(-not(Test-NvidiaValue ($session.Get([uint32]$row.Id)) $row.Before)){throw 'NVIDIA settings changed during review. Refresh and try again.'}}
  $saved=New-ControlJournal 'nvidia' $rows;$saved.Journal|Add-Member NoteProperty GameId $GameId;$saved.Journal|Add-Member NoteProperty Profile $profile;$saved.Journal|Add-Member NoteProperty Preset $Preset;$saved.Journal|Add-Member NoteProperty LodPreset $LodPreset;Save-ControlJournal $saved.Path $saved.Journal
  foreach($row in $rows){$session.Set([uint32]$row.Id,[uint32]$row.After.Value)}
  Assert-GameClosed $GameId;$session.Save()
 }catch{if($saved){$saved.Journal.Status='Recovery needed';Save-ControlJournal $saved.Path $saved.Journal};throw}finally{$session.Dispose()}
 $session=Open-NvidiaSession $GameId
 try{foreach($row in $rows){if(-not(Test-NvidiaValue ($session.Get([uint32]$row.Id)) $row.After)){throw 'NVIDIA did not retain every setting. Use Reset to recover the saved values.'}};$saved.Journal.Status='Applied';Save-ControlJournal $saved.Path $saved.Journal}catch{$saved.Journal.Status='Recovery needed';Save-ControlJournal $saved.Path $saved.Journal;throw}finally{$session.Dispose()}
 [pscustomobject]@{Status='Applied';Id=$saved.Journal.Id}
}
function Read-ProfileJournal([string]$Id,[string]$Kind) {
 if($Kind -cnotin @('nvidia','fortnite') -or $Id -cnotmatch ('^'+$Kind+'-\d{8}-\d{6}-[a-f0-9]{8}$')){throw 'Invalid profile backup ID.'}
 $directory=Join-Path (Join-Path $script:ControlRoot 'State') $Id;$path=Join-Path $directory 'transaction.json'
 foreach($itemPath in @($script:ControlRoot,(Join-Path $script:ControlRoot 'State'),$directory,$path)){if((Get-Item -LiteralPath $itemPath).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Profile backup is linked.'}}
 if((Get-Item -LiteralPath $path).Length -gt 2MB){throw 'Profile backup too large.'}
 $j=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json
 if($j.Schema -ne 1 -or $j.Id -cne $Id -or $j.Computer -ne $env:COMPUTERNAME -or $j.Sid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -or $j.Status -cnotin @('Applied','Prepared','Undoing','Recovery needed') -or @($j.Rows).Count -lt 1 -or @($j.Rows).Count -gt 32){throw 'Invalid saved profile for this account and PC.'}
 [pscustomobject]@{Path=$path;Journal=$j}
}
function Undo-NvidiaProfile([string]$Id) {
 Require-Admin;$saved=Read-ProfileJournal $Id 'nvidia';$j=$saved.Journal
 if($j.GameId -cnotin @('fortnite','siege')){throw 'Invalid saved NVIDIA game.'};Assert-GameClosed $j.GameId
 $preset=if($j.PSObject.Properties['Preset']){[string]$j.Preset}else{'competitive'}
 $lod=if($j.PSObject.Properties['LodPreset']){[string]$j.LodPreset}else{'strong'}
 if($preset -eq 'potato' -and $j.GameId -cne 'fortnite'){throw 'Invalid potato profile game.'}
 $catalog=@(Get-NvidiaPresetCatalog $preset $lod);$seen=@{}
 foreach($row in $j.Rows){$spec=@($catalog|Where-Object Id -eq $row.Id);if($spec.Count -ne 1 -or $seen.ContainsKey([string]$row.Id)){throw 'Invalid/duplicate NVIDIA setting.'};$seen[[string]$row.Id]=$true;Assert-NvidiaValue $row.Before;Assert-NvidiaValue $row.After;if(-not $row.After.Local -or -not $row.After.Found -or [uint32]$row.After.Value -ne [uint32]$spec[0].Target){throw 'Saved NVIDIA target is not an approved preset.'}}
 if(-not(Confirm-Action 'Reset this NVIDIA game profile to the values saved before KKxtti changed it? Other profiles and global settings stay as they are. Newer conflicting changes stop the reset. Keep the game and other profile editors closed.' 'RESET')){return}
 $session=Open-NvidiaSession $j.GameId
 try{
  if($session.ProfileName -cne $j.Profile){throw 'NVIDIA profile identity changed; inspect the backup.'}
  $pending=@();foreach($row in $j.Rows){$current=$session.Get([uint32]$row.Id);if(Test-NvidiaValue $current $row.Before){continue};if(-not(Test-NvidiaValue $current $row.After)){throw 'A newer NVIDIA setting conflicts with Reset. No changes were saved.'};$pending+=$row}
  $j.Status='Undoing';Save-ControlJournal $saved.Path $j
  foreach($row in $pending){if($row.Before.Local){$session.Set([uint32]$row.Id,[uint32]$row.Before.Value)}else{$session.Remove([uint32]$row.Id)}}
  if($pending.Count){Assert-GameClosed $j.GameId;$session.Save()}
 }catch{$j.Status='Recovery needed';Save-ControlJournal $saved.Path $j;throw}finally{$session.Dispose()}
 $session=Open-NvidiaSession $j.GameId
 try{foreach($row in $j.Rows){$current=$session.Get([uint32]$row.Id);if($row.Before.Local){if(-not(Test-NvidiaValue $current $row.Before)){throw 'NVIDIA Reset verification failed.'}}elseif($current.Local){throw 'The NVIDIA override was not removed.'}};$j.Status='Undone';Save-ControlJournal $saved.Path $j}finally{$session.Dispose()}
 [pscustomobject]@{Status='Undone';Id=$Id}
}
function Get-GamingPowerCatalog {
 $cpu='54533251-82be-4824-96c1-47b60b740d00'
 @(
  [pscustomobject]@{Name='Minimum processor state';Sub=$cpu;Key='893dee8e-2bef-41e0-89c6-b55d0929964c';Value=5;Required=$true}
  [pscustomobject]@{Name='Maximum processor state';Sub=$cpu;Key='bc5038f7-23e0-4960-96da-33abaf5935ec';Value=100;Required=$true}
  [pscustomobject]@{Name='Boost enabled / aggressive where supported';Sub=$cpu;Key='be337238-0d82-4146-a960-4f3749d470c7';Value=2;Required=$false}
  [pscustomobject]@{Name='Energy performance preference: performance';Sub=$cpu;Key='36687f9e-e3a5-4dbf-b1dc-15eb381c6863';Value=0;Required=$false}
  [pscustomobject]@{Name='CPPC autonomous selection';Sub=$cpu;Key='8baa4a8a-14c6-4451-8e8b-14bdbd197537';Value=1;Required=$false}
  [pscustomobject]@{Name='PCIe link-state power saving: off on AC';Sub='501a4d13-42af-4429-9fd1-a8218c268e20';Key='ee12f906-d277-404b-b6da-e5fa1a576df5';Value=0;Required=$false}
 )
}
function Read-GamingPowerValue([string]$Plan,$Spec){Import-ProfileNative;[KKxtti.PowerRead]::Read($Plan,$Spec.Sub,$Spec.Key)}
function Assert-GamingPowerDesktop {
 $system=Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
 if($system.PCSystemType -eq 2 -or @(Get-CimInstance Win32_Battery -ErrorAction Stop).Count){throw 'This AC gaming plan is intended for desktops. Use the manufacturer power controls on a laptop.'}
}
function Get-GamingPowerPreview {
 $plan=Get-PowerGuid
 foreach($spec in Get-GamingPowerCatalog){try{$current=Read-GamingPowerValue $plan $spec;[pscustomobject]@{Name=$spec.Name;Current=$current;Target=$spec.Value;Supported=$true}}catch{[pscustomobject]@{Name=$spec.Name;Current='Unavailable';Target=$spec.Value;Supported=$false}}}
}
function Set-GamingPowerPlan {
 Require-Admin;Assert-GamingPowerDesktop
 $before=Get-PowerGuid;$specs=@();foreach($spec in Get-GamingPowerCatalog){try{$null=Read-GamingPowerValue $before $spec;$specs+=$spec}catch{if($spec.Required){throw};Write-Host ('Not supported here: '+$spec.Name)}}
 if(-not(Confirm-Action ('Create and activate KKxtti Ultimate Gaming as a separate copy of your current plan? Only these supported AC values change:'+[Environment]::NewLine+(($specs|ForEach-Object {$_.Name+' = '+$_.Value}) -join [Environment]::NewLine)+[Environment]::NewLine+'Idle downclocking remains allowed. Your display/sleep choices and battery values are preserved. This favors responsiveness but needs game/thermal benchmarks; it is not a guaranteed FPS gain. Reset restores your saved active plan.') 'CREATE')){return}
 if((Get-PowerGuid) -cne $before){throw 'The active power plan changed during review.'}
 $created=[guid]::NewGuid().ToString('D');$row=[pscustomobject]@{PreviousPlan=$before;CreatedPlan=$created;Fingerprint='';FingerprintMode='All';Profile='KKxtti Ultimate Gaming'};$saved=New-ControlJournal 'ultimate' @($row)
 try{
  $null=Invoke-Native 'powercfg.exe' @('/duplicatescheme',$before,$created)
  $null=Invoke-Native 'powercfg.exe' @('/changename',$created,'KKxtti Ultimate Gaming','Custom AC performance profile with saved original plan')
  foreach($spec in $specs){$null=Invoke-Native 'powercfg.exe' @('/setacvalueindex',$created,$spec.Sub,$spec.Key,[string]$spec.Value);if((Read-GamingPowerValue $created $spec) -ne $spec.Value){throw ('Power setting did not persist: '+$spec.Name)}}
  $row.Fingerprint=Get-PlanFingerprint $created -All;Save-ControlJournal $saved.Path $saved.Journal
  if((Get-PowerGuid) -cne $before){throw 'The active plan changed during setup.'}
  $null=Invoke-Native 'powercfg.exe' @('/setactive',$created);if((Get-PowerGuid) -cne $created){throw 'The gaming power plan was not activated.'}
  $saved.Journal.Status='Applied';Save-ControlJournal $saved.Path $saved.Journal
 }catch{
  $problem=$_.Exception.Message;$saved.Journal.Status='Recovery needed'
  # A partially configured plan stays inactive for inspection. Never delete a
  # plan whose complete settings have not been fingerprinted.
  if((Get-PowerGuid) -ceq $created){try{$null=Invoke-Native 'powercfg.exe' @('/setactive',$before)}catch{}}
  Save-ControlJournal $saved.Path $saved.Journal;throw ($problem+' Your saved plan is in Backups; inspect any incomplete plan there.')
 }
 [pscustomobject]@{Status='Applied';Id=$saved.Journal.Id;Plan=$created}
}
