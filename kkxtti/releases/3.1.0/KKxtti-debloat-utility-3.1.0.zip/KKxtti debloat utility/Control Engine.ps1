#requires -Version 5.1
# Local, declarative settings. No downloads, scripts from the network, or telemetry.
$script:ControlRoot=$PSScriptRoot
$script:ExtraControlCatalog=$null
function New-ControlValue($Path,$Name,$On,$Off) { [pscustomobject]@{Path=$Path;Name=$Name;On=[int]$On;Off=[int]$Off} }
function Get-BasicControlCatalog {
 $explorer='Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
 $cdm='Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
 @(
  [pscustomobject]@{Id='game-mode';Name='Game Mode';Group='Gaming';Description='Let Windows prioritize your game while you play.';Note='Applies to this account. Relaunch your game after changing it.';Values=@((New-ControlValue 'Software\Microsoft\GameBar' 'AllowAutoGameMode' 1 0),(New-ControlValue 'Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1 0))}
  [pscustomobject]@{Id='no-capture';Name='Disable Windows game recording';Group='Gaming';Description='Turn off Windows game capture when you use another recorder.';Note='Disables Windows game recording, including clips you might want to save. Does not change NVIDIA recording. Relaunch your game.';Values=@((New-ControlValue 'Software\Microsoft\Windows\CurrentVersion\GameDVR' 'AppCaptureEnabled' 0 1),(New-ControlValue 'System\GameConfigStore' 'GameDVR_Enabled' 0 1))}
  [pscustomobject]@{Id='no-ads';Name='Disable advertising ID';Group='Privacy';Description='Stop apps using your Windows advertising ID.';Note='Changes the Windows advertising preference. Websites and individual apps have separate preferences.';Values=@((New-ControlValue 'Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' 'Enabled' 0 1))}
  [pscustomobject]@{Id='no-tailored';Name='Disable tailored experiences';Group='Privacy';Description='Turn off personalized Windows suggestions based on diagnostics.';Note='Does not disable diagnostic collection. Settings may be managed by your organization.';Values=@((New-ControlValue 'Software\Microsoft\Windows\CurrentVersion\Privacy' 'TailoredExperiencesWithDiagnosticDataEnabled' 0 1))}
  [pscustomobject]@{Id='no-tips';Name='Reduce Windows tips';Group='Privacy';Description='Hide Windows tips and suggestions while using the desktop.';Note='Controls the tips preference; other apps may still show their own notifications. Sign out to refresh shell preferences.';Values=@((New-ControlValue $cdm 'SubscribedContent-338389Enabled' 0 1))}
  [pscustomobject]@{Id='no-welcome';Name='Hide the Windows welcome experience';Group='Privacy';Description='Skip the welcome and suggestion screens after updates.';Note='Controls the Windows welcome preference. Does not suppress update or security notifications.';Values=@((New-ControlValue $cdm 'SubscribedContent-310093Enabled' 0 1))}
  [pscustomobject]@{Id='no-settings-suggestions';Name='Reduce suggestions in Settings';Group='Privacy';Description='Remove suggested content from Windows Settings.';Note='Controls the Settings content preferences. Close and reopen Settings.';Values=@((New-ControlValue $cdm 'SubscribedContent-338393Enabled' 0 1),(New-ControlValue $cdm 'SubscribedContent-353694Enabled' 0 1),(New-ControlValue $cdm 'SubscribedContent-353696Enabled' 0 1))}
  [pscustomobject]@{Id='extensions';Name='Show file extensions';Group='Desktop';Description='See .exe, .cmd and other extensions in File Explorer.';Note='New Explorer windows or a sign-out may be needed to refresh the shell.';Values=@((New-ControlValue $explorer 'HideFileExt' 0 1))}
  [pscustomobject]@{Id='hidden-files';Name='Show hidden files';Group='Desktop';Description='Display ordinary hidden files in File Explorer.';Note='Protected operating-system files stay hidden. Refresh Explorer or sign out.';Values=@((New-ControlValue $explorer 'Hidden' 1 2))}
  [pscustomobject]@{Id='compact';Name='Compact File Explorer';Group='Desktop';Description='Fit more files into the Explorer list.';Note='Reopen File Explorer or sign out to refresh spacing.';Values=@((New-ControlValue $explorer 'UseCompactMode' 1 0))}
  [pscustomobject]@{Id='no-taskview';Name='Hide the Task View button';Group='Desktop';Description='Free taskbar space. Win + Tab keeps working.';Note='Sign out to refresh the taskbar.';Values=@((New-ControlValue $explorer 'ShowTaskViewButton' 0 1))}
  [pscustomobject]@{Id='no-search';Name='Hide taskbar search';Group='Desktop';Description='Keep the taskbar clean. Start menu search stays available.';Note='Off shows the search icon. Undo restores your exact previous search-box preference. Sign out to refresh the taskbar.';Values=@((New-ControlValue 'Software\Microsoft\Windows\CurrentVersion\Search' 'SearchboxTaskbarMode' 0 1))}
  [pscustomobject]@{Id='left-taskbar';Name='Left-align the taskbar';Group='Desktop';Description='Move Start and pinned app icons to the left.';Note='Off centers the taskbar. Sign out to refresh the taskbar.';Values=@((New-ControlValue $explorer 'TaskbarAl' 0 1))}
  [pscustomobject]@{Id='no-transparency';Name='Disable transparency';Group='Desktop';Description='Use solid surfaces throughout the Windows desktop.';Note='An appearance preference, not a measured FPS boost. Sign out to refresh all applications.';Values=@((New-ControlValue 'Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'EnableTransparency' 0 1))}
  [pscustomobject]@{Id='dark-mode';Name='Windows dark mode';Group='Desktop';Description='Use dark colors for Windows and supported apps.';Note='Some apps have their own themes. Reopen apps or sign out to refresh.';Values=@((New-ControlValue 'Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'AppsUseLightTheme' 0 1),(New-ControlValue 'Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'SystemUsesLightTheme' 0 1))}
  [pscustomobject]@{Id='scrollbars';Name='Always show scrollbars';Group='Desktop';Description='Keep scrollbars visible in supported Windows apps.';Note='Reopen applications or sign out to refresh.';Values=@((New-ControlValue 'Control Panel\Accessibility' 'DynamicScrollbars' 0 1))}
 )
}
function Get-ControlProperty($Object,$Name,$Default=$null) { if($Object.PSObject.Properties[$Name]){$Object.$Name}else{$Default} }
function Get-ControlCatalog {
 foreach($item in Get-BasicControlCatalog){
  $item | Add-Member NoteProperty Risk 'Preference'
  $item | Add-Member NoteProperty Evidence 'Windows preference'
  $item | Add-Member NoteProperty Source 'https://github.com/ChrisTitusTech/winutil'
  $item | Add-Member NoteProperty RequiresAdmin $false
  $item | Add-Member NoteProperty MinBuild 22000
  $item | Add-Member NoteProperty Editions @()
  $item
 }
 if(-not $script:ExtraControlCatalog){
  $path=Join-Path $PSScriptRoot 'Control Catalog.json'
  if((Get-Item -LiteralPath $path).Length -gt 1MB){throw 'Control catalog is too large.'}
  $script:ExtraControlCatalog=Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
  $seen=@{}
  foreach($item in $script:ExtraControlCatalog){
   if($item.Id -cnotmatch '^[a-z][a-z0-9-]{1,60}$' -or $seen.ContainsKey($item.Id)){throw 'Invalid or duplicate catalog ID.'};$seen[$item.Id]=$true
   if($item.Source -notmatch '^https://' -or @($item.Values).Count -notin 1..12){throw 'Invalid catalog metadata.'}
   foreach($v in $item.Values){if($v.Hive -notin @('HKCU','HKLM','HKU') -or $v.Kind -notin @('DWord','String','QWord') -or $v.Path -match '(^|\\)\.\.($|\\)' -or ($v.Hive -eq 'HKU' -and $v.Path -notlike '.DEFAULT\*')){throw 'Invalid catalog registry specification.'}}
  }
 }
 $script:ExtraControlCatalog
}
function Get-ControlPlatform {
 $key=[Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Microsoft\Windows NT\CurrentVersion')
 try{[pscustomobject]@{Build=[int]$key.GetValue('CurrentBuildNumber');Edition=[string]$key.GetValue('EditionID')}}finally{$key.Dispose()}
}
function Test-ControlSupported($Item,$Platform) { $Platform.Build -ge $Item.MinBuild -and (@($Item.Editions).Count -eq 0 -or $Platform.Edition -in $Item.Editions) }
function Assert-ControlWritable($Spec) {
 if((Get-ControlProperty $Spec 'Hive' 'HKCU') -ne 'HKCU' -and -not (Test-Admin)){throw 'Administrator access is needed for this system setting. Restart KKxtti as administrator and choose it again.'}
}
function Get-ControlRegistry($Spec) {
 switch((Get-ControlProperty $Spec 'Hive' 'HKCU')){'HKCU'{[Microsoft.Win32.Registry]::CurrentUser};'HKLM'{[Microsoft.Win32.Registry]::LocalMachine};'HKU'{[Microsoft.Win32.Registry]::Users};default{throw 'Unknown registry scope.'}}
}
function Get-ControlTarget($Spec,[bool]$Enabled,$Before) {
 $kind=Get-ControlProperty $Spec 'Kind' 'DWord';$data=if($Enabled){$Spec.On}else{$Spec.Off}
 $mask=Get-ControlProperty $Spec 'Mask'
 if($null -ne $mask){
  if(-not $Before.Exists -and $kind -eq 'DWord'){$n=0L}
  else{
   if(-not $Before.Exists -or $Before.Kind -notin @('String','DWord')){throw 'This bit preference requires an existing integer or string value. Configure it once in Windows Settings first.'}
   $kind=$Before.Kind;$n=0L;if(-not [long]::TryParse([string]$Before.Data,[ref]$n) -or $n -lt 0 -or $n -gt [int]::MaxValue){throw 'This bit preference has an unsupported current value.'}
  }
  $data=($n -band (-bnot [long]$mask)) -bor ([long]$data -band [long]$mask)
 }
 if($null -eq $data){return [pscustomobject]@{Exists=$false;Kind=$kind;Data=$null}}
 $data=switch($kind){'String'{[string]$data};'QWord'{[long]$data};default{[int]$data}}
 [pscustomobject]@{Exists=$true;Kind=$kind;Data=$data}
}
function Read-ControlValue($Spec) {
 $key=(Get-ControlRegistry $Spec).OpenSubKey($Spec.Path)
 try {
  if($null -eq $key -or $key.GetValueNames() -notcontains $Spec.Name){return [pscustomobject]@{Exists=$false;Kind='DWord';Data=$null}}
  [pscustomobject]@{Exists=$true;Kind=$key.GetValueKind($Spec.Name).ToString();Data=$key.GetValue($Spec.Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)}
 } finally {if($key){$key.Dispose()}}
}
function Write-ControlValue($Spec,$Value) {
 if(-not $Value.Exists) {
  $key=(Get-ControlRegistry $Spec).OpenSubKey($Spec.Path,$true)
  if($key){try{$key.DeleteValue($Spec.Name,$false)}finally{$key.Dispose()}}
  return
 }
 $data=switch($Value.Kind){'DWord'{[int]$Value.Data} 'QWord'{[long]$Value.Data} 'Binary'{[byte[]]$Value.Data} 'MultiString'{[string[]]$Value.Data} default{[string]$Value.Data}}
 $key=(Get-ControlRegistry $Spec).CreateSubKey($Spec.Path)
 try{$key.SetValue($Spec.Name,$data,([Enum]::Parse([Microsoft.Win32.RegistryValueKind],$Value.Kind)))}finally{$key.Dispose()}
}
function Test-ControlEqual($A,$B) {
 if([bool]$A.Exists -ne [bool]$B.Exists){return $false}
 if(-not $A.Exists){return $true}
 ($A.Kind -eq $B.Kind -and (ConvertTo-Json -InputObject $A.Data -Compress) -ceq (ConvertTo-Json -InputObject $B.Data -Compress))
}
function Get-ControlStates {
 $platform=Get-ControlPlatform
 foreach($item in Get-ControlCatalog) {
  $on=$true;$off=$true;$any=$false;$state='Default / custom';$errorText=''
  try{foreach($v in $item.Values){$value=Read-ControlValue $v;$any=$any -or $value.Exists
   if((Get-ControlProperty $v 'Mask') -and -not $value.Exists){$on=$false;$off=$false;continue}
   $on=$on -and (Test-ControlEqual $value (Get-ControlTarget $v $true $value));$off=$off -and (Test-ControlEqual $value (Get-ControlTarget $v $false $value))
  };if($on -and $any){$state='On'}elseif($off -and $any){$state='Off'}}catch{$state='Unavailable';$errorText=$_.Exception.Message}
  $supported=Test-ControlSupported $item $platform
  if(-not $supported){$state='Unsupported edition / build'}
  [pscustomobject]@{Id=$item.Id;Name=$item.Name;Group=$item.Group;Description=$item.Description;Note=$item.Note;State=$state;Risk=$item.Risk;Source=$item.Source;Evidence=$item.Evidence;RequiresAdmin=$item.RequiresAdmin;Supported=[bool]($supported -and -not $errorText);Error=$errorText}
 }
}
function Save-ControlJournal($Path,$Journal) {
 $json=ConvertTo-Json -InputObject $Journal -Depth 14
 [IO.File]::WriteAllText(($Path+'.tmp'),$json,[Text.UTF8Encoding]::new($false))
 Move-Item -LiteralPath ($Path+'.tmp') -Destination $Path -Force -ErrorAction Stop
}
function New-ControlJournal($Kind,$Rows) {
 $id=$Kind+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)
 $folder=Join-Path (Join-Path $script:ControlRoot 'State') $id
 $null=New-Item -ItemType Directory -Path $folder -Force
 $j=[pscustomobject]@{Schema=1;Id=$id;Computer=$env:COMPUTERNAME;Sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;Created=(Get-Date).ToString('o');Status='Prepared';Rows=@($Rows)}
 $path=Join-Path $folder 'transaction.json';Save-ControlJournal $path $j
 [pscustomobject]@{Path=$path;Journal=$j}
}
function Get-ControlSpec($Row) {
 $found=@(Get-ControlCatalog | Where-Object Id -eq $Row.Id)
 if($found.Count -ne 1 -or $Row.Index -isnot [int] -or $Row.Index -lt 0 -or $Row.Index -ge $found[0].Values.Count){throw 'Invalid setting in saved state.'}
 $found[0].Values[$Row.Index]
}
function Assert-ControlValue($Value) {
 if($Value.Exists -isnot [bool] -or $Value.Kind -notin @('DWord','QWord','String','ExpandString','MultiString','Binary')){throw 'Invalid value in saved state.'}
 if($null -ne $Value.Data){$encoded=ConvertTo-Json -InputObject $Value.Data -Compress;if($null -ne $encoded -and $encoded.Length -gt 65536){throw 'Saved value is too large.'}}
 if($Value.Exists){switch($Value.Kind){'DWord'{$null=[int]$Value.Data} 'QWord'{$null=[long]$Value.Data} 'Binary'{$null=[byte[]]$Value.Data}}}
}
function Invoke-ControlRows($Rows,$Mode,$Saved) {
 foreach($row in $Rows){Assert-ControlWritable (Get-ControlSpec $row)}
 $attempted=New-Object Collections.Generic.List[object]
 try {
  foreach($row in $Rows) {
   $spec=Get-ControlSpec $row
   $expected=if($Mode -eq 'Apply'){$row.Before}else{$row.After}
   $target=if($Mode -eq 'Apply'){$row.After}else{$row.Before}
   if(-not (Test-ControlEqual (Read-ControlValue $spec) $expected)){throw ('Setting changed externally: '+$row.Id+'. Refresh and try again.')}
   $attempted.Add($row)
   Write-ControlValue $spec $target
   if(-not (Test-ControlEqual (Read-ControlValue $spec) $target)){throw ('Windows did not keep the setting: '+$row.Id)}
  }
  $Saved.Journal.Status=if($Mode -eq 'Apply'){'Applied'}else{'Undone'}
  Save-ControlJournal $Saved.Path $Saved.Journal
 } catch {
  $problem=$_.Exception.Message;$failures=@()
  for($i=$attempted.Count-1;$i -ge 0;$i--) {
   $row=$attempted[$i];$prior=if($Mode -eq 'Apply'){$row.Before}else{$row.After}
   try { $spec=Get-ControlSpec $row;Write-ControlValue $spec $prior;if(-not (Test-ControlEqual (Read-ControlValue $spec) $prior)){throw 'Readback failed'} } catch {$failures+=$row.Id}
  }
  $Saved.Journal.Status=if($failures.Count){'Recovery needed'}elseif($Mode -eq 'Undo'){'Applied'}else{'Rolled back'}
  try{Save-ControlJournal $Saved.Path $Saved.Journal}catch{$problem+=' Could not update the journal.'}
  if($failures.Count){throw ($problem+' Recovery needed for: '+($failures -join ', ')+'. Backup: '+$Saved.Path)}
  throw ($problem+' Attempted changes were rolled back.')
 }
 [pscustomobject]@{Id=$Saved.Journal.Id;Status=$Saved.Journal.Status;Count=@($Rows).Count}
}
function Set-ControlSettings([string[]]$Ids,[bool]$Enabled) {
 if(-not $Ids -or $Ids.Count -gt 100){throw 'Choose between one and 100 settings.'}
 $catalog=@(Get-ControlCatalog);$rows=@();$platform=Get-ControlPlatform;$keys=@{}
 foreach($id in ($Ids | Select-Object -Unique)) {
  $item=@($catalog | Where-Object Id -eq $id)
  if($item.Count -ne 1){throw ('Unknown setting: '+$id)}
  if(-not (Test-ControlSupported $item[0] $platform)){throw ('This edition/build does not support '+$item[0].Name)}
  for($i=0;$i -lt $item[0].Values.Count;$i++) {
   $v=$item[0].Values[$i];$before=Read-ControlValue $v
   Assert-ControlWritable $v
   $key=(Get-ControlProperty $v 'Hive' 'HKCU')+'\'+$v.Path+'\'+$v.Name
   if($keys.ContainsKey($key)){throw 'Selected controls affect the same value. Apply these separately so each change can be compared and undone.'};$keys[$key]=$true
   $safe=Get-ControlProperty $v 'SafePrevious'
   if($safe -and $before.Exists -and ($before.Kind -ne (Get-ControlProperty $v 'Kind' 'DWord') -or [string]$before.Data -cnotin $safe)){throw 'A different page-visibility policy already exists. KKxtti will not overwrite it.'}
   $after=Get-ControlTarget $v $Enabled $before
   if(-not (Test-ControlEqual $before $after)){$rows+=[pscustomobject]@{Id=$id;Index=$i;Before=$before;After=$after}}
  }
 }
 if(-not $rows.Count){return [pscustomobject]@{Id='';Status='Already configured';Count=0}}
 $saved=New-ControlJournal 'settings' $rows
 Invoke-ControlRows $rows 'Apply' $saved
}
function Undo-ControlSettings([string]$Id) {
 if($Id -notmatch '^settings-\d{8}-\d{6}-[a-f0-9]{8}$'){throw 'Choose a valid settings backup.'}
 $path=Join-Path (Join-Path (Join-Path $script:ControlRoot 'State') $Id) 'transaction.json'
 if((Get-Item -LiteralPath $path).Length -gt 2000000){throw 'Backup exceeds size limit.'}
 $j=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
 if($j.Schema -ne 1 -or $j.Id -ne $Id -or $j.Status -ne 'Applied' -or $j.Computer -ne $env:COMPUTERNAME -or $j.Sid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'This backup is not an applied change for this account and PC.'}
 $seen=@{}
 foreach($row in $j.Rows){$spec=Get-ControlSpec $row;Assert-ControlValue $row.Before;Assert-ControlValue $row.After;$key=$row.Id+':'+$row.Index;if($seen.ContainsKey($key)){throw 'Duplicate backup row.'};$seen[$key]=$true;if(-not(Test-ControlEqual (Read-ControlValue $spec) $row.After)){throw ('A newer or external change affects '+$row.Id+'. Undo newer changes first. Nothing was changed.')}}
 if(@($j.Rows).Count -eq 0 -or @($j.Rows).Count -gt 400){throw 'Invalid backup rows.'}
 $j.Status='Undoing';Save-ControlJournal $path $j
 Invoke-ControlRows @($j.Rows) 'Undo' ([pscustomobject]@{Path=$path;Journal=$j})
}
function Get-ControlHistory {
 $state=Join-Path $script:ControlRoot 'State'
 if(Test-Path -LiteralPath $state){Get-ChildItem -LiteralPath $state -Directory -Filter 'settings-*' | Sort-Object Name -Descending | ForEach-Object {
  try{$j=Get-Content -LiteralPath (Join-Path $_.FullName 'transaction.json') -Raw | ConvertFrom-Json;[pscustomobject]@{Id=$_.Name;Created=$j.Created;Status=$j.Status;Count=@($j.Rows | Select-Object -ExpandProperty Id -Unique).Count}}catch{}
 }}
}

# Only reviewed optional apps can be removed. Every installed main package is
# visible; system, framework, driver and unknown packages remain protected.
function Get-AppCatalog {
 @{
  'Microsoft.Windows.DevHome'=@('Dev Home','Extras','Developer dashboard. Remove if you do not use its workspaces.', $true)
  'Microsoft.BingNews'=@('News','Extras','Microsoft news feed.', $true)
  'Microsoft.BingWeather'=@('Weather','Extras','Weather forecasts and live tiles.', $true)
  'Microsoft.GetHelp'=@('Get Help','Extras','Windows help and support app.', $true)
  'Microsoft.Getstarted'=@('Tips','Extras','Windows getting-started tips.', $true)
  'Microsoft.WindowsFeedbackHub'=@('Feedback Hub','Extras','Send Windows feedback and diagnostics.', $true)
  'Microsoft.MicrosoftOfficeHub'=@('Microsoft 365 hub','Extras','Microsoft 365 launcher; not the desktop Office suite.', $true)
  'Microsoft.MicrosoftSolitaireCollection'=@('Solitaire Collection','Extras','Microsoft card games; local progress may be removed.', $false)
  'Microsoft.Copilot'=@('Copilot','Extras','The standalone Microsoft Copilot app.', $true)
  'MicrosoftWindows.Client.WebExperience'=@('Windows Web Experience / Widgets','Extras','Widgets feed package. May affect Windows web experiences. Protected or non-removable installations are kept.', $false)
  'Microsoft.Windows.Photos'=@('Photos','Media','Photo viewer and editor. Choose a replacement before removal.', $false)
  'Microsoft.Paint'=@('Paint','Media','Image editor. App settings may be removed.', $false)
  'Microsoft.WindowsCamera'=@('Camera','Media','Windows camera app; does not uninstall webcam drivers.', $false)
  'Microsoft.ScreenSketch'=@('Snipping Tool','Media','Screenshots and screen recording. Win + Shift + S may stop working.', $false)
  'Clipchamp.Clipchamp'=@('Clipchamp','Media','Video editor. Back up local projects first.', $false)
  'Microsoft.ZuneMusic'=@('Media Player','Media','Windows music and video player.', $false)
  'Microsoft.ZuneVideo'=@('Movies & TV','Media','Video playback and purchased content access.', $false)
  'Microsoft.WindowsSoundRecorder'=@('Sound Recorder','Media','Voice recording app. Back up recordings first.', $false)
  'Microsoft.MicrosoftStickyNotes'=@('Sticky Notes','Tools','Back up or sync your notes before removal.', $false)
  'Microsoft.WindowsCalculator'=@('Calculator','Tools','Calculator and unit conversions.', $false)
  'Microsoft.WindowsNotepad'=@('Notepad','Tools','Text editor. Save every open tab before removal.', $false)
  'Microsoft.WindowsTerminal'=@('Terminal','Tools','Terminal app and custom profiles; PowerShell itself stays installed.', $false)
  'Microsoft.WindowsAlarms'=@('Clock','Tools','Alarms, timers and focus sessions.', $false)
  'Microsoft.WindowsMaps'=@('Maps','Tools','Map app and its local data.', $false)
  'Microsoft.PowerAutomateDesktop'=@('Power Automate','Tools','Desktop automation. Export flows before removal.', $false)
  'Microsoft.YourPhone'=@('Phone Link','Connectivity','Phone notifications, calls and messages on your PC.', $false)
  'MicrosoftWindows.CrossDevice'=@('Cross Device Experience','Connectivity','Phone integration, connected camera and cross-device features.', $false)
  'Microsoft.People'=@('People','Connectivity','Contacts app. Sync contacts before removal.', $false)
  'Microsoft.SkypeApp'=@('Skype','Connectivity','Legacy Skype app and local data.', $false)
  'Microsoft.OutlookForWindows'=@('Outlook for Windows','Connectivity','Mail and calendar. Save local drafts first.', $false)
  'Microsoft.XboxGamingOverlay'=@('Xbox Game Bar','Gaming','Overlay, recording and widgets; keep if you use them.', $false)
  'Microsoft.XboxApp'=@('Xbox Console Companion','Gaming','Legacy Xbox companion app.', $false)
  'Microsoft.Microsoft3DViewer'=@('3D Viewer','Media','Viewer for 3D models.', $false)
  'Microsoft.MixedReality.Portal'=@('Mixed Reality Portal','Extras','Windows mixed-reality headset app.', $false)
 }
}
function Get-InstalledMainPackages { @(Get-AppxPackage -PackageTypeFilter Main -ErrorAction Stop) }
function Get-ManagedApps {
 $catalog=Get-AppCatalog
 foreach($p in Get-InstalledMainPackages) {
  $known=$catalog.ContainsKey($p.Name)
  $protected=($p.NonRemovable -or $p.IsFramework -or [string]$p.SignatureKind -eq 'System' -or [string]$p.SignatureKind -eq '4' -or -not $known)
  $data=if($known){$catalog[$p.Name]}else{@(($p.Name -replace '^Microsoft\.|^MicrosoftWindows\.|^NVIDIACorp\.',''),'Protected','Kept: Windows component, dependency, driver control or app outside the reviewed removal catalog.',$false)}
  [pscustomobject]@{Name=$data[0];Package=$p.PackageFullName;Identity=$p.Name;Group=$(if($protected){'Protected'}else{$data[1]});Description=$data[2];Protected=[bool]$protected;Suggested=[bool]($data[3] -and -not $protected)}
 }
}
function Remove-ManagedApps([string[]]$Packages) {
 if(-not $Packages -or $Packages.Count -gt 100){throw 'Choose apps to remove.'}
 $installed=@(Get-ManagedApps);$chosen=@()
 foreach($id in ($Packages | Select-Object -Unique)) {
  $match=@($installed | Where-Object Package -ceq $id)
  if($match.Count -ne 1 -or $match[0].Protected){throw 'An app changed or is protected. Refresh your selection. No apps were removed.'}
  $chosen+=$match[0]
 }
 $rows=@($chosen | ForEach-Object {[pscustomobject]@{Name=$_.Name;Package=$_.Package;Status='Pending';Error=''}})
 $saved=New-ControlJournal 'apps' $rows
 foreach($row in $rows) {
  try{
   $fresh=@(Get-ManagedApps | Where-Object Package -ceq $row.Package)
   if($fresh.Count -ne 1 -or $fresh[0].Protected){throw 'Package changed since review.'}
   Remove-AppxPackage -Package $row.Package -ErrorAction Stop
   if(@(Get-InstalledMainPackages | Where-Object PackageFullName -ceq $row.Package).Count){throw 'Windows still reports this package as installed.'}
   $row.Status='Removed'
  }catch{$row.Status='Failed';$row.Error=$_.Exception.Message}
  Save-ControlJournal $saved.Path $saved.Journal
 }
 $saved.Journal.Status=if(@($rows | Where-Object Status -eq 'Failed').Count){'Completed with errors'}else{'Completed'}
 Save-ControlJournal $saved.Path $saved.Journal
 $rows
}
