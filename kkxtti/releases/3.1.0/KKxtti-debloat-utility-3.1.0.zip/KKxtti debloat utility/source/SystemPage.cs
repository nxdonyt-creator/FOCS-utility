using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace KKxtti {
 public sealed partial class Dashboard {
  StackPanel systemList;
  bool systemLoaded;
  void BuildSystemTools(){
   var page=Page("System tools");
   page.Children.Add(Card(Stack(Pill("REVIEW / COMPATIBILITY / RECOVERY"),Gap(12),Text("The rest of the checklist.",25,null,true),Gap(8),Text("Separate actions for disk space, optional services, app removal and compatibility. Every screenshot entry is mapped in the checklist, including operations Windows cannot safely support on this PC.",13,"#A2ABC1"),Buttons(Btn("Read screenshot coverage",()=>OpenLocal("SCREENSHOT CHECKLIST.txt")),Btn("Read research decisions",()=>OpenLocal("EXPANDED RESEARCH.txt")),Btn("Refresh system states",()=>LoadSystemControls()))),22));
   page.Children.Add(Gap(14));systemList=new StackPanel();page.Children.Add(systemList);
   page.Children.Add(Columns(new UIElement[]{
    InfoCard("Disk cleanup", "Open Windows Disk Cleanup to review categories and files. No unattended clean sweep.", "REVIEW FILES",Btn("Open Disk Cleanup",()=>OpenUri(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"System32","cleanmgr.exe"))),Btn("Old temporary files",()=>Action("Review old temporary files","Clear-OldUserTemp"))),
    InfoCard("Recovery", "Create a real Windows restore point when System Protection is already enabled. Saved switch states remain separate.", "RESTORE POINT",Btn("Create restore point",()=>Action("Create restore point","New-ReviewedRestorePoint",true)),Btn("System Protection",()=>OpenUri(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"System32","SystemPropertiesProtection.exe"))))
   }));page.Children.Add(Gap(12));
   page.Children.Add(Columns(new UIElement[]{
    InfoCard("BitLocker decryption", "Decrypt the system drive only after saving your recovery key. Weakens stored-file protection; no automatic encryption undo or FPS claim.", "HIGH IMPACT",Btn("Review system-drive decryption",()=>Action("Review BitLocker decryption","Start-SystemDriveDecryption",true)),Btn("Manage BitLocker",()=>Action("Open Manage BitLocker","Start-Process -FilePath (Join-Path $env:WINDIR 'System32\\control.exe') -ArgumentList @('/name','Microsoft.BitLockerDriveEncryption')"))),
    InfoCard("Edge & OneDrive removal", "Use the supported installed-package uninstaller. Back up bookmarks and download cloud-only files first. Windows may prohibit Edge removal.", "NO FORCE REMOVAL",Btn("Review Edge uninstall",()=>Action("Review Edge uninstall","Uninstall-ReviewedDesktopApp -Id edge")),Btn("Review OneDrive uninstall",()=>Action("Review OneDrive uninstall","Uninstall-ReviewedDesktopApp -Id onedrive")))
   }));page.Children.Add(Gap(12));
   page.Children.Add(Columns(new UIElement[]{
    InfoCard("Windows AI & Widgets", "Disable supported AI preferences in Performance. Review removable Copilot, Widgets and Outlook packages in Debloat. Core system AI components stay protected.", "REVIEW PACKAGES",Btn("AI preference controls",()=>FindControl("AI")),Btn("Review Windows apps",()=>Navigate("Debloat"))),
    InfoCard("Sleep options", "S0 and S3 availability is defined by firmware and drivers. Read available sleep states before changing power settings. KKxtti does not force unsupported sleep modes.", "HARDWARE DEPENDENT",Btn("Read available sleep states",()=>Action("Read sleep capabilities","Invoke-Native 'powercfg.exe' @('/a')")),Btn("Power & sleep settings",()=>OpenUri("ms-settings:powersleep")))
   }));page.Children.Add(Gap(12));
   page.Children.Add(Columns(new UIElement[]{
    InfoCard("Ultimate Performance plan", "Create a separate desktop test plan, save the original active plan and compare. Not guaranteed faster on a 5700X3D. Restore deletes only the plan created by that transaction.", "EXPERIMENT",Btn("Review Ultimate Performance",()=>Action("Create Ultimate Performance test plan","Set-UltimateTestPlan",true)),Btn("Restore / disable test plan",()=>Navigate("Backups"))),
    InfoCard("O&O ShutUp10", "Open the official publisher download page. Review the utility's own changes and backups. KKxtti does not download and execute a changing third-party privacy script.", "EXTERNAL UTILITY",Btn("Official download",()=>OpenUri("https://www.oo-software.com/en/download/current/ooshutup10")))
   }));page.Children.Add(Gap(12));
   page.Children.Add(Card(Stack(Text("Compatibility entries requiring a different approach",17,null,true),Gap(10),Text("Previous Start layout: private feature overrides can stop working on 25H2. Store recommended search: denying access to store.db can break Store behavior. Adobe URL block list: an unreviewed changing list can block licensing, sign-in or updates. Logitech/Razer install blocks: folder-deny tricks can interfere with driver and device management. Unsigned RDP warnings: keep the trust prompt rather than silently suppressing it.\n\nThese entries are documented in the checklist and intentionally have no destructive one-click replacement. Logitech G HUB and SteelSeries GG remain available for configuring your Superlight 2 and Apex Pro.",13,"#A2ABC1")),20));
  }
  void FindControl(string term){Navigate("Performance");controlSearch.Text=term;}
  void LoadSystemControls(){if(busy)return;Work("Read optional system controls","Get-SystemStates",r=>{systemList.Children.Clear();foreach(var p in r){string id=Value(p,"Id"),name=Value(p,"Name"),note=Value(p,"Note"),source=Value(p,"Source");bool available=Boolean.Parse(Value(p,"Available","False"));var apply=Btn("Review change",()=>RunSystemControl(id,name),true);apply.IsEnabled=available;
    var card=Card(Stack(Text(name,17,null,true),Gap(7),Text(Value(p,"State"),11,available?"#C5B3E8":"#FFC79F"),Gap(8),Text(note,13,"#A2ABC1"),Buttons(apply,Btn("Source",()=>OpenUri(source)))),18);card.Margin=new Thickness(0,0,0,12);systemList.Children.Add(card);
   }systemLoaded=true;});}
  void RunSystemControl(string id,string name){if(busy||!RequireAdmin())return;Work(name,"Set-SystemControl -Id $SystemId",r=>{foreach(var p in r)Log(Value(p,"Status"));systemLoaded=false;},null,new Dictionary<string,object>{{"SystemId",id}});}
  void UndoSystem(string id){if(busy||!RequireAdmin())return;Work("Restore system control","Undo-SystemControl -Id $SystemUndoId",r=>{systemLoaded=false;RefreshBackups();},null,new Dictionary<string,object>{{"SystemUndoId",id}});}
  void UndoUltimate(string id){if(busy||!RequireAdmin())return;Work("Restore original power plan","Undo-UltimateTestPlan -Id $UltimateUndoId",r=>{RefreshBackups();RefreshPowerLabel();},null,new Dictionary<string,object>{{"UltimateUndoId",id}});}
 }
}
