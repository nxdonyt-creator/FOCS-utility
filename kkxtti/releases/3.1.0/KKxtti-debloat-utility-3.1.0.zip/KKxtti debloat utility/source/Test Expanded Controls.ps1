#requires -Version 5.1
param([string]$Root=(Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference='Stop'
. (Join-Path $Root 'Performance Utility.ps1') -LibraryOnly
. (Join-Path $Root 'Control Engine.ps1')
$script:ControlRoot=Join-Path $PSScriptRoot ('expanded-control-fixtures-'+[guid]::NewGuid().ToString('N'))
$script:checks=0;$script:values=@{};$script:writes=0;$script:admin=$true;$script:edition='Enterprise'
function Check($Value,$Message){if(-not $Value){throw ('FAIL: '+$Message)};$script:checks++;Write-Host ('PASS: '+$Message)}
function Refuses($Block,$Pattern){$caught=$false;try{& $Block | Out-Null}catch{$caught=$true;Check ($_.Exception.Message -match $Pattern) ('refused '+$Pattern)};Check $caught 'refusal surfaced'}
function Test-Admin {$script:admin}
function Get-ControlPlatform {[pscustomobject]@{Build=26200;Edition=$script:edition}}
function Key($Spec){(Get-ControlProperty $Spec 'Hive' 'HKCU')+'|'+$Spec.Path+'|'+$Spec.Name}
function Read-ControlValue($Spec){$key=Key $Spec;if($script:values.ContainsKey($key)){$script:values[$key]}else{[pscustomobject]@{Exists=$false;Kind=(Get-ControlProperty $Spec 'Kind' 'DWord');Data=$null}}}
function Write-ControlValue($Spec,$Value){$script:writes++;$script:values[(Key $Spec)]=$Value}
$script:normalWrite=${function:Write-ControlValue}
$catalog=@(Get-ControlCatalog)
Check ($catalog.Count -eq 103) '103 individual controls without counting system tools or installer apps'
Check (@($catalog | Group-Object Id | Where-Object Count -ne 1).Count -eq 0) 'catalog IDs unique'
Check (@($catalog | Where-Object {$_.Source -notlike 'https://*' -or -not $_.Note}).Count -eq 0) 'every control has a source and practical note'
Check (@($catalog | Where-Object Risk -eq 'High impact').Count -eq 1) 'IPv6 disable explicitly classified high impact'
$n=$script:writes;$script:admin=$false
Refuses {Set-ControlSettings @('extensions','delivery-peers') $true} 'Administrator'
Check ($script:writes -eq $n) 'mixed batch rejected before any write without admin'
$script:admin=$true;$script:edition='Professional'
Refuses {Set-ControlSettings @('consumer-features') $true} 'edition/build'
Check ($script:writes -eq $n) 'unsupported edition rejected before any write'
$script:edition='Enterprise'
Refuses {Set-ControlSettings @('ipv4-preferred','ipv6-disable') $true} 'same value'
Check ($script:writes -eq $n) 'overlapping network controls refused as one batch'
foreach($id in @('no-sticky-shortcut','no-filter-shortcut','no-toggle-shortcut','sticky-keys')){
 $spec=($catalog | Where-Object Id -eq $id).Values[0]
 foreach($kind in @('String','DWord')){
  $data=if($kind -eq 'String'){'511'}else{511};$before=[pscustomobject]@{Exists=$true;Kind=$kind;Data=$data};$script:values[(Key $spec)]=$before
  $change=Set-ControlSettings @($id) $true;$after=Read-ControlValue $spec
  $mask=[int]$spec.Mask;Check ((([int]$after.Data -band (-bnot $mask)) -eq (511 -band (-bnot $mask))) -and $after.Kind -eq $kind) ($id+' preserves other bits and '+$kind+' type')
  if($change.Id){$null=Undo-ControlSettings $change.Id}
  Check (Test-ControlEqual (Read-ControlValue $spec) $before) ($id+' exact undo')
 }
}
$homeSpec=($catalog | Where-Object Id -eq 'settings-home').Values[0]
$script:values[(Key $homeSpec)]=[pscustomobject]@{Exists=$true;Kind='String';Data='hide:privacy-location'};$n=$script:writes
Refuses {Set-ControlSettings @('settings-home') $true} 'visibility policy'
Check ($script:writes -eq $n) 'existing different Settings visibility list preserved'
$script:values=@{}
foreach($item in $catalog){
 foreach($spec in $item.Values){if(Get-ControlProperty $spec 'Mask'){$data=if((Get-ControlProperty $spec 'Kind') -eq 'String'){'511'}else{0};$script:values[(Key $spec)]=[pscustomobject]@{Exists=$true;Kind=(Get-ControlProperty $spec 'Kind');Data=$data}}}
 $before=@($item.Values | ForEach-Object {Read-ControlValue $_});$changed=Set-ControlSettings @($item.Id) $true
 Check ((Get-ControlStates | Where-Object Id -eq $item.Id).State -eq 'On') ($item.Id+' on configuration read back')
 if($changed.Id){$null=Undo-ControlSettings $changed.Id}
 for($i=0;$i -lt $item.Values.Count;$i++){Check (Test-ControlEqual (Read-ControlValue $item.Values[$i]) $before[$i]) ($item.Id+' original restored')}
}
$script:values=@{};$script:failureCount=0
function Write-ControlValue($Spec,$Value){$script:failureCount++;& $script:normalWrite $Spec $Value;if($script:failureCount -eq 2){throw 'Injected mixed-scope failure'}}
Refuses {Set-ControlSettings @('activity-history') $true} 'rolled back'
Set-Item Function:Write-ControlValue $script:normalWrite
Check (-not (Read-ControlValue ($catalog | Where-Object Id -eq 'activity-history').Values[0]).Exists) 'machine-scope mock rollback restores absence'
Write-Host ('TOTAL: '+$script:checks+' expanded control checks; every registry read/write mocked.')
