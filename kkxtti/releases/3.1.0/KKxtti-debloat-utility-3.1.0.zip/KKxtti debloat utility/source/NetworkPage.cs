using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Management.Automation;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;

namespace KKxtti {
 public sealed partial class Dashboard {
  sealed class NicItem {public string Id,Name,Description,Status,Speed,Driver;public override string ToString(){return Name+"  /  "+Status+"  /  "+Speed;}}
  ComboBox networkAdapter,dnsProfile; TextBlock networkDetail,networkNotice,dnsDetail; StackPanel networkControls,probeResults; Button probeStart,probeStop;
  bool networkLoaded,networkLoading; ActionBridge probeBridge;
  void BuildNetwork() {
   var page=Page("Network");
   page.Children.Add(Card(Stack(Pill("MEASURE FIRST"),Gap(10),Text("A steadier connection starts here.",25,null,true),Gap(8),Text("See your real adapter settings. Compare one change at a time, with your previous values saved automatically.",13,"#A2ABC1")),22));page.Children.Add(Gap(15));
   networkAdapter=new ComboBox {Height=39,Padding=new Thickness(10,6,10,6),Foreground=System.Windows.Media.Brushes.Black};AutomationProperties.SetName(networkAdapter,"Physical network adapter");
   networkAdapter.SelectionChanged+=(s,e)=>{if(!networkLoading&&!busy)LoadNetworkSettings();};
   page.Children.Add(Columns(new UIElement[]{networkAdapter,Btn("Refresh adapters",()=>LoadNetwork())},4,1));
   networkDetail=Text("Use Refresh adapters to read your connection.",12,"#A2ABC1");page.Children.Add(Gap(9));page.Children.Add(networkDetail);page.Children.Add(Gap(18));
   probeStart=Btn("Measure connection",()=>StartNetworkProbe(),true);probeStop=Btn("Stop measurement",()=>{if(probeBridge!=null){probeBridge.Cancelled=true;probeStop.IsEnabled=false;}});probeStop.IsEnabled=false;
   probeResults=new StackPanel();probeResults.Children.Add(Text("No results yet. A light probe checks your gateway and two public endpoints.",12,"#A2ABC1"));
   page.Children.Add(Card(Stack(Text("Loss, latency and variation",18,null,true),Gap(8),Text("30 small ICMP probes per target. Usually 20 seconds; timeouts can take longer. No bandwidth saturation or game-server traffic.",12,"#A2ABC1"),Buttons(probeStart,probeStop),Gap(8),probeResults,Gap(12),Text("Public ICMP results are not your in-game ping or input delay. Some networks filter or deprioritize probes. Compare the same targets and traffic conditions.",11,"#929EB8")),18));page.Children.Add(Gap(20));
   page.Children.Add(Text("Adapter switches",20,null,true));page.Children.Add(Gap(7));
   networkNotice=Text("Switches show saved configuration. Changes require administrator access and may need a reconnect or reboot to take effect.",12,"#A2ABC1");page.Children.Add(networkNotice);
   page.Children.Add(Buttons(Btn("Restore latest adapter change",()=>UndoLatestNetwork()),Btn("Reconnect selected adapter",()=>ReconnectNetwork())));page.Children.Add(Gap(8));
   networkControls=new StackPanel();page.Children.Add(networkControls);page.Children.Add(Gap(12));
   dnsProfile=new ComboBox{Height=38};dnsProfile.Items.Add("Automatic (DHCP)");dnsProfile.Items.Add("Cloudflare");dnsProfile.Items.Add("Google Public DNS");dnsProfile.Items.Add("Quad9 (malware filtering)");dnsProfile.SelectedIndex=0;AutomationProperties.SetName(dnsProfile,"DNS profile");
   dnsDetail=Text("Read DNS to see the selected adapter's IPv4 and IPv6 modes.",12,"#A2ABC1");
   page.Children.Add(Card(Stack(Text("DNS profiles",18,null,true),Gap(8),Text("Affects hostname lookups; does not guarantee lower game-server ping. Original DHCP/static modes are saved for each family.",12,"#A2ABC1"),Gap(10),dnsProfile,Buttons(Btn("Read DNS",()=>ReadSelectedDns()),Btn("Review DNS change",()=>ChangeSelectedDns(),true),Btn("Restore DNS",()=>Navigate("Backups"))),dnsDetail),18));page.Children.Add(Gap(12));
   page.Children.Add(InfoCard("When latency jumps during downloads","Compare idle and busy network conditions. Router queue management can matter much more than Windows registry changes when the line is saturated.","ROUTER / SQM",Btn("Read network findings",()=>OpenLocal("RESEARCH FINDINGS.txt"))));
  }
  NicItem SelectedNic {get{return networkAdapter.SelectedItem as NicItem;}}
  Dictionary<string,object> NicVariables() {var a=SelectedNic;if(a==null)throw new InvalidOperationException("Select a physical adapter first.");return new Dictionary<string,object>{{"AdapterId",a.Id}};}
  void LoadNetwork() {
   if(busy)return;string selected=SelectedNic==null?null:SelectedNic.Id;
   Work("Read physical adapters","Get-NetworkInventory",r=>{
    networkLoading=true;networkAdapter.Items.Clear();foreach(var p in r)networkAdapter.Items.Add(new NicItem{Id=Value(p,"Id"),Name=Value(p,"Name"),Description=Value(p,"Description"),Status=Value(p,"Status"),Speed=Value(p,"LinkSpeed"),Driver=Value(p,"DriverVersion")});
    networkAdapter.SelectedItem=networkAdapter.Items.Cast<NicItem>().FirstOrDefault(a=>a.Id==selected)??networkAdapter.Items.Cast<NicItem>().FirstOrDefault(a=>a.Status=="Up")??networkAdapter.Items.Cast<NicItem>().FirstOrDefault();networkLoading=false;networkLoaded=true;
    Dispatcher.BeginInvoke(new Action(()=>LoadNetworkSettings()));
   });
  }
  void LoadNetworkSettings() {
   if(busy)return;networkControls.Children.Clear();var a=SelectedNic;if(a==null){networkDetail.Text="No physical adapter found.";return;}
   networkDetail.Text=a.Description+"  ·  Driver "+a.Driver+"  ·  Link speed is not internet throughput";
   Work("Read adapter settings","Get-NetworkSettingStates -AdapterId $AdapterId",r=>RenderNetworkSettings(r),null,NicVariables());
  }
  void RenderNetworkSettings(Collection<PSObject> values) {
   networkControls.Children.Clear();var cards=new List<UIElement>();
   foreach(var p in values) {
    string id=Value(p,"Id"),name=Value(p,"Name"),state=Value(p,"State"),description=Value(p,"Description"),source=Value(p,"Source"),details=Value(p,"Details"),category=Value(p,"Class");bool supported=Value(p,"Supported")=="True";
    var toggle=new ToggleButton{Width=48,Height=26,IsChecked=state=="On",IsEnabled=supported,Cursor=Cursors.Hand,Style=(Style)XamlReader.Parse(SwitchStyle)};AutomationProperties.SetName(toggle,name);toggle.ToolTip=supported?"Save this adapter setting with undo":"This driver does not expose all required values";
    toggle.Click+=(s,e)=>{bool enabled=toggle.IsChecked==true;toggle.IsChecked=state=="On";if(!busy&&RequireAdmin())ChangeNetwork(new[]{id},enabled,name,null);};
    var head=new DockPanel();DockPanel.SetDock(toggle,Dock.Right);head.Children.Add(toggle);head.Children.Add(Text(name,14,null,true));
    var detailButton=Btn("Details & source",()=>{var body=Stack(Text(name,22,null,true),Gap(12),Text(description,13,"#BBC5DA"),Gap(12),Text(details.Length==0?"Driver support unavailable.":details,12,"#A2ABC1"),Gap(12),Text("Changes are staged without automatically reconnecting. Undo restores the saved values and also needs a reconnect when the driver requires it.",12,"#A2ABC1"));var dialog=Dialog(body);body.Children.Add(Buttons(Btn("Open source",()=>OpenUri(source)),Btn("Close",()=>dialog.Close(),true)));dialog.ShowDialog();});detailButton.FontSize=10;detailButton.Padding=new Thickness(8,5,8,5);
    var desc=Text(description,12,"#A2ABC1");desc.MinHeight=48;
    cards.Add(Card(Stack(head,Gap(10),desc,Gap(9),Text(category.ToUpperInvariant()+"  ·  "+state,11,state=="On"?"#C9B5FF":"#A2ABC1"),Buttons(detailButton)),16));
   }
   for(int i=0;i<cards.Count;i+=2){var row=Columns(new[]{cards[i],i+1<cards.Count?cards[i+1]:new Border()});row.Margin=new Thickness(0,0,0,10);networkControls.Children.Add(row);}
  }
  async void ChangeNetwork(string[] ids,bool enabled,string title,string undoId) {
   if(busy||!RequireAdmin())return;if(undoId==null&&SelectedNic==null)return;SetBusy(true,title+"…");networkControls.IsEnabled=false;networkAdapter.IsEnabled=false;
   try {
    var vars=undoId==null?NicVariables():new Dictionary<string,object>();vars["SettingIds"]=ids;vars["SettingEnabled"]=enabled;vars["UndoId"]=undoId;
    var results=await Task.Run(()=>Backend.Run(root,undoId==null?"Set-NetworkSettings -AdapterId $AdapterId -Ids $SettingIds -Enabled $SettingEnabled":"Undo-NetworkSettings -Id $UndoId",new ActionBridge(this),vars));
    string outcome=results.Count==0?"Completed":Value(results[0],"Status");Log(title+": "+outcome);networkNotice.Text=outcome=="Already configured"?"These values are already configured.":"Saved. The adapter has not been reconnected. Reconnect after leaving your online game, or reboot, for driver changes to take effect.";
   }catch(Exception ex){Log("ERROR: "+ex.Message);Notice("Adapter change could not complete",ex.Message);}
   networkControls.IsEnabled=true;networkAdapter.IsEnabled=true;SetBusy(false,"Ready");RefreshBackupCount();if(currentPage=="Backups")RefreshBackups();if(SelectedNic!=null)LoadNetworkSettings();
  }
  void UndoNetwork(string id) {if(busy||!RequireAdmin())return;if(Review("Restore adapter settings","Restore the exact values saved before this change. An external change or driver update stops automatic restore. Reconnect separately after restoring.",new[]{id},"Restore adapter"))ChangeNetwork(new string[0],false,"Restore adapter",id);}
  void UndoLatestNetwork() {
   if(busy||SelectedNic==null)return;Work("Find adapter backup","Get-NetworkHistory -AdapterId $AdapterId | Select-Object -First 1",r=>{if(r.Count==0){Notice("No adapter change to restore","There is no applied adapter change saved for this selection.");return;}string id=Value(r[0],"Id");Dispatcher.BeginInvoke(new Action(()=>UndoNetwork(id)));},null,NicVariables());
  }
  void ReconnectNetwork() {
   if(busy||SelectedNic==null||!RequireAdmin())return;var a=SelectedNic;
   if(!Review("Reconnect "+a.Name+"?","This briefly disconnects this adapter and can interrupt games, calls and downloads. Leave your online match first. A failed reconnect may need Windows troubleshooting or a reboot.",new[]{a.Description},"Reconnect adapter"))return;
   Work("Reconnect adapter","Restart-SelectedNetworkAdapter -AdapterId $AdapterId",r=>{networkNotice.Text="Reconnect requested. Allow a few seconds for the link to return, then refresh adapters. Windows may still require a reboot for some driver settings.";},null,NicVariables());
  }
  async void StartNetworkProbe() {
   if(busy||SelectedNic==null)return;var vars=NicVariables();probeBridge=new ActionBridge(this);probeStart.IsEnabled=false;probeStop.IsEnabled=true;networkAdapter.IsEnabled=false;networkControls.IsEnabled=false;SetBusy(true,"Measuring network…");probeResults.Children.Clear();probeResults.Children.Add(Text("Probing your gateway and public endpoints. You can stop at any time.",12,"#C9B5FF"));
   try {
    var result=await Task.Run(()=>Backend.Run(root,"Invoke-NetworkProbe -AdapterId $AdapterId -Count 30",probeBridge,vars));probeResults.Children.Clear();
    foreach(var p in result){var card=Card(Stack(Text(Value(p,"Name"),15,null,true),Gap(8),Text("Median "+ProbeMs(p,"MedianMs")+"   /   p95 "+ProbeMs(p,"P95Ms")+"   /   loss "+Value(p,"LossPercent","—")+"%",13,"#D5C4FF"),Gap(5),Text(Value(p,"Replies")+" / "+Value(p,"Sent")+" replies  ·  successive RTT variation "+ProbeMs(p,"JitterMs"),11,"#A2ABC1")),14);card.Margin=new Thickness(0,0,0,8);probeResults.Children.Add(card);}
    if(result.Count==0)probeResults.Children.Add(Text("Stopped before a target completed.",12,"#A2ABC1"));
    Log("Network measurement "+(probeBridge.Cancelled?"stopped; partial results saved.":"completed; results saved."));
   }catch(Exception ex){probeResults.Children.Clear();probeResults.Children.Add(Text(ex.Message,12,"#FFABA8"));Log("Network probe: "+ex.Message);}
   probeStart.IsEnabled=true;probeStop.IsEnabled=false;networkAdapter.IsEnabled=true;networkControls.IsEnabled=true;probeBridge=null;SetBusy(false,"Network measurement finished");RefreshBackupCount();
  }
  static string ProbeMs(PSObject p,string name) {string raw=Value(p,name,"");double n;if(!Double.TryParse(raw,NumberStyles.Float,CultureInfo.CurrentCulture,out n))return "unavailable";return n==0?"<1 ms":n.ToString("0.0",CultureInfo.CurrentCulture)+" ms";}
  void ReadSelectedDns(){if(busy||SelectedNic==null)return;Work("Read selected adapter DNS","Get-SelectedDnsStates -AdapterId $AdapterId",r=>dnsDetail.Text=String.Join("\n",r.Select(p=>Value(p,"Family")+" / "+Value(p,"Mode")+" / "+Value(p,"Servers","No servers reported"))),null,NicVariables());}
  void ChangeSelectedDns(){if(busy||SelectedNic==null||!RequireAdmin())return;var ids=new[]{"automatic","cloudflare","google","quad9"};if(dnsProfile.SelectedIndex<0)return;var vars=NicVariables();vars["DnsProfileId"]=ids[dnsProfile.SelectedIndex];Work("Change selected adapter DNS","Set-SelectedDnsProfile -AdapterId $AdapterId -ProfileId $DnsProfileId",r=>{foreach(var p in r)Log(Value(p,"Status"));Dispatcher.BeginInvoke(new Action(()=>ReadSelectedDns()));},null,vars);}
  void UndoDns(string id){if(busy||!RequireAdmin())return;Work("Restore selected DNS","Undo-SelectedDnsProfile -Id $DnsUndoId",r=>RefreshBackups(),null,new Dictionary<string,object>{{"DnsUndoId",id}});}
 }
}
