#requires -Version 5.1
param([switch]$LibraryOnly, [switch]$ReportOnly)
# Independent utility; no original KKxtti script is executed.
# Every mutation is a separately selected action. No automatic elevation.
Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'
$script:StateRoot = Join-Path $PSScriptRoot 'State'
$script:BootKeys = @('useplatformclock','useplatformtick','disabledynamictick','numproc')
$script:AppAllowlist = @(
 'Clipchamp.Clipchamp','Microsoft.BingNews','Microsoft.BingWeather',
 'Microsoft.GetHelp','Microsoft.Getstarted','Microsoft.MicrosoftSolitaireCollection',
 'Microsoft.MicrosoftOfficeHub','Microsoft.People','Microsoft.SkypeApp',
 'Microsoft.WindowsFeedbackHub','Microsoft.WindowsMaps','Microsoft.YourPhone',
 'Microsoft.ZuneMusic','Microsoft.ZuneVideo','Microsoft.Microsoft3DViewer',
 'Microsoft.MixedReality.Portal','Microsoft.PowerAutomateDesktop',
 'Microsoft.WindowsAlarms','Microsoft.WindowsSoundRecorder','Microsoft.XboxGamingOverlay'
)

function Test-Admin {
 $id = [Security.Principal.WindowsIdentity]::GetCurrent()
 return ([Security.Principal.WindowsPrincipal]::new($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Require-Admin {
 if (-not (Test-Admin)) { throw 'This action needs administrator rights. Close and run the launcher as administrator; other actions work normally.' }
}
function Invoke-Native([string]$Name, [string[]]$Arguments) {
 if ($Name -notin @('powercfg.exe','bcdedit.exe','pnputil.exe','fsutil.exe')) { throw 'Executable is not allowlisted.' }
 $quoted = foreach ($arg in $Arguments) {
  if ($arg -match '["\r\n]') { throw 'Invalid native argument.' }
  '"' + ($arg -replace '(\\+)$','$1$1') + '"'
 }
 $psi = [Diagnostics.ProcessStartInfo]::new()
 $psi.FileName = Join-Path $env:SystemRoot ('System32\' + $Name)
 $psi.Arguments = $quoted -join ' '
 $psi.UseShellExecute = $false
 $psi.CreateNoWindow = $true
 $psi.RedirectStandardOutput = $true
 $psi.RedirectStandardError = $true
 $p = [Diagnostics.Process]::new()
 $p.StartInfo = $psi
 try {
  [void]$p.Start()
  $outTask = $p.StandardOutput.ReadToEndAsync()
  $errTask = $p.StandardError.ReadToEndAsync()
  $p.WaitForExit()
  $outText = $outTask.GetAwaiter().GetResult()
  $errText = $errTask.GetAwaiter().GetResult()
  if ($p.ExitCode -ne 0) { throw "$Name exited $($p.ExitCode): $outText $errText" }
  return $outText.Trim()
 } finally { $p.Dispose() }
}
function New-StateDirectory([string]$Kind) {
 [void][IO.Directory]::CreateDirectory($script:StateRoot)
 $name = '{0}-{1}-{2}' -f $Kind,(Get-Date -Format 'yyyyMMdd-HHmmss'),([guid]::NewGuid().ToString('N').Substring(0,8))
 $dir = Join-Path $script:StateRoot $name
 [void][IO.Directory]::CreateDirectory($dir)
 return $dir
}
function Write-Json([string]$Path, $Data) {
 $text = $Data | ConvertTo-Json -Depth 12
 [IO.File]::WriteAllText($Path,$text,[Text.UTF8Encoding]::new($false))
}
function Confirm-Action([string]$Message,[string]$Word) {
 Write-Host $Message -ForegroundColor Yellow
 return ((Read-Host "Type $Word to continue; Enter cancels") -ceq $Word)
}
function Get-GuidFromText([string]$Text) {
 $match = [regex]::Match($Text,'(?i)\b[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\b')
 if (-not $match.Success) { throw 'Windows returned no recognizable GUID.' }
 return $match.Value.ToLowerInvariant()
}
function Get-PowerGuid { Get-GuidFromText (Invoke-Native 'powercfg.exe' @('/getactivescheme')) }
function Set-TestPowerPlan {
 Write-Host (Invoke-Native 'powercfg.exe' @('/getactivescheme'))
 Write-Host '1 = Balanced baseline; 2 = High performance experiment; Enter = cancel.'
 $choice = Read-Host 'Plan'
 $target = switch ($choice) { '1' {'381b4222-f694-41f0-9685-ff5bb260df2e'} '2' {'8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'} default {return} }
 $list = Invoke-Native 'powercfg.exe' @('/list')
 if ($list -notmatch [regex]::Escape($target)) { throw 'That plan is absent. No plans will be created or deleted.' }
 $before = Get-PowerGuid
 if ($before -eq $target) { Write-Host 'Already active; nothing changed.'; return }
 if (-not (Confirm-Action 'Changes the active power plan. Benchmark the same scenes; a faster result is not guaranteed. The current plan will be recorded for Undo.' 'APPLY')) { return }
 $dir = New-StateDirectory 'power'
 Write-Json (Join-Path $dir 'before.json') ([ordered]@{Schema=1;Kind='Power';Original=$before;Target=$target})
 try {
  [void](Invoke-Native 'powercfg.exe' @('/setactive',$target))
  if ((Get-PowerGuid) -ne $target) { throw 'Power-plan verification failed.' }
 } catch {
  $problem = $_
  try { [void](Invoke-Native 'powercfg.exe' @('/setactive',$before)) } catch { Write-Warning "Automatic rollback also failed: $_" }
  throw $problem
 }
 Write-Host "Applied. Prior plan recorded in $dir"
}
function Select-State([string]$Kind) {
 if (-not (Test-Path -LiteralPath $script:StateRoot)) { throw 'No saved state exists.' }
 $dirs = @(Get-ChildItem -LiteralPath $script:StateRoot -Directory | Where-Object { $_.Name -like "$Kind-*" -and (Test-Path -LiteralPath (Join-Path $_.FullName 'before.json')) } | Sort-Object Name -Descending)
 if ($dirs.Count -eq 0) { throw 'No matching backup exists.' }
 for ($i=0;$i -lt $dirs.Count;$i++) { Write-Host ('{0}. {1}' -f ($i+1),$dirs[$i].Name) }
 $entry = Read-Host 'Backup number (Enter cancels)'
 if (-not $entry) { return }
 $n = 0
 if (-not [int]::TryParse($entry,[ref]$n) -or $n -lt 1 -or $n -gt $dirs.Count) { throw 'Invalid backup selection.' }
 return $dirs[$n-1].FullName
}
function Undo-Power {
 $dir = Select-State 'power'
 if (-not $dir) { return }
 $state = Get-Content -LiteralPath (Join-Path $dir 'before.json') -Raw | ConvertFrom-Json
 if ($state.Schema -ne 1 -or $state.Kind -ne 'Power' -or $state.Original -notmatch '^[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$') { throw 'Invalid power backup.' }
 $list = Invoke-Native 'powercfg.exe' @('/list')
 if ($list -notmatch [regex]::Escape($state.Original)) { throw 'The original plan no longer exists; nothing changed.' }
 if (-not (Confirm-Action "Restores active power plan $($state.Original)." 'RESTORE')) { return }
 [void](Invoke-Native 'powercfg.exe' @('/setactive',$state.Original))
 if ((Get-PowerGuid) -ne $state.Original) { throw 'Restore verification failed.' }
 Write-Host 'Original power plan restored.'
}
function ConvertFrom-BootText([string]$Text) {
 $id = '{' + (Get-GuidFromText $Text) + '}'
 $values = [ordered]@{}
 foreach ($key in $script:BootKeys) {
  $match = [regex]::Match($Text,('(?im)^\s*' + $key + '\s+(\S+)\s*$'))
  $value = $null
  if ($match.Success) {
   $value = $match.Groups[1].Value.ToLowerInvariant()
   if ($key -eq 'numproc') {
    if ($value -notmatch '^\d{1,4}$' -or [int]$value -lt 1) { throw 'Unrecognized processor-count value. No boot edits allowed.' }
   } elseif ($value -notin @('yes','no')) { throw 'Unrecognized/localized boot value. No boot edits allowed.' }
  }
  $values[$key] = $value
 }
 return [pscustomobject]@{Schema=1;Kind='Boot';BootId=$id;Values=[pscustomobject]$values}
}
function Get-BootState {
 Require-Admin
 ConvertFrom-BootText (Invoke-Native 'bcdedit.exe' @('/enum','{current}','/v'))
}
function Test-BootState($State) {
 if ($State.Schema -ne 1 -or $State.Kind -ne 'Boot' -or $State.BootId -notmatch '^\{[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}\}$') { throw 'Invalid boot backup.' }
 $names = @($State.Values.PSObject.Properties.Name)
 if ($names.Count -ne 4) { throw 'Unexpected boot keys.' }
 foreach ($key in $script:BootKeys) {
  if ($key -notin $names) { throw 'Missing boot key.' }
  $v = $State.Values.$key
  if ($null -ne $v) {
   if ($key -eq 'numproc') {
    if ([string]$v -notmatch '^\d{1,4}$' -or [int]$v -lt 1) { throw 'Invalid processor count.' }
   } elseif ($v -notin @('yes','no')) { throw 'Invalid timer value.' }
  }
 }
}
function Require-BootWritable {
 Require-Admin
 if (-not (Get-Command Get-BitLockerVolume -ErrorAction SilentlyContinue)) { throw 'Cannot verify encryption status; automatic boot changes are unavailable.' }
 $volume = Get-BitLockerVolume -MountPoint $env:SystemDrive
 if ([string]$volume.VolumeStatus -ne 'FullyDecrypted') { throw 'The OS volume is encrypted. Automatic boot changes are blocked; use a recovery-aware manual workflow. This utility does not suspend encryption or Secure Boot.' }
}
function Set-BootState($Desired) {
 Test-BootState $Desired
 $current = Get-BootState
 if ($current.BootId -ne $Desired.BootId) { throw 'Backup belongs to a different Windows boot entry.' }
 foreach ($key in $script:BootKeys) {
  $old = $current.Values.$key
  $new = $Desired.Values.$key
  if ($old -eq $new) { continue }
  if ($null -eq $new) { [void](Invoke-Native 'bcdedit.exe' @('/deletevalue',$current.BootId,$key)) }
  else { [void](Invoke-Native 'bcdedit.exe' @('/set',$current.BootId,$key,[string]$new)) }
 }
 $verified = Get-BootState
 foreach ($key in $script:BootKeys) { if ($verified.Values.$key -ne $Desired.Values.$key) { throw "Boot verification failed for $key." } }
}
function Backup-Boot([string]$Kind='boot') {
 $state = Get-BootState
 $dir = New-StateDirectory $Kind
 [void](Invoke-Native 'bcdedit.exe' @('/export',(Join-Path $dir 'BCD-store.bak')))
 if (-not (Test-Path -LiteralPath (Join-Path $dir 'BCD-store.bak'))) { throw 'BCD export missing; no changes allowed.' }
 Write-Json (Join-Path $dir 'before.json') $state
 return [pscustomobject]@{Directory=$dir;State=$state}
}
function Reset-BootOverrides {
 Require-BootWritable
 $state = Get-BootState
 $state.Values | Format-List | Out-Host
 if (@($script:BootKeys | Where-Object { $null -ne $state.Values.$_ }).Count -eq 0) { Write-Host 'These overrides are absent already. Nothing to reset.'; return }
 if (-not (Confirm-Action 'Restores automatic Windows timer selection and CPU count by removing only the four listed overrides. BCD is backed up first. A reboot is needed; there is no automatic reboot or promised FPS gain.' 'RESET')) { return }
 $backup = Backup-Boot
 $desired = $backup.State | ConvertTo-Json -Depth 5 | ConvertFrom-Json
 foreach ($key in $script:BootKeys) { $desired.Values.$key = $null }
 try { Set-BootState $desired } catch {
  $problem = $_
  try { Set-BootState $backup.State } catch { Write-Warning "Rollback failed too. Preserve the BCD backup in $($backup.Directory). Error: $_" }
  throw $problem
 }
 Write-Host "Automatic choices restored. Restart manually when ready. Backup: $($backup.Directory)"
}
function Undo-Boot {
 Require-BootWritable
 $dir = Select-State 'boot'
 if (-not $dir) { return }
 $desired = Get-Content -LiteralPath (Join-Path $dir 'before.json') -Raw | ConvertFrom-Json
 Test-BootState $desired
 $current = Get-BootState
 if ($current.BootId -ne $desired.BootId) { throw 'Different Windows boot entry; restore blocked.' }
 $desired.Values | Format-List | Out-Host
 if (-not (Confirm-Action 'Restores exactly these saved timer/CPU values, including saved absence. This can reintroduce earlier experimental tweaks. Requires reboot.' 'RESTORE')) { return }
 $backup = Backup-Boot 'pre-restore'
 try { Set-BootState $desired } catch {
  $problem = $_
  try { Set-BootState $backup.State } catch { Write-Warning "Rollback failed: $_" }
  throw $problem
 }
 Write-Host 'Saved boot values restored. Restart manually when ready.'
}
function Save-Inventory {
 $dir = New-StateDirectory 'report'
 $report = [ordered]@{Timestamp=(Get-Date).ToString('o')}
 $queries = [ordered]@{
  OS={Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber}
  CPU={Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors}
  Board={Get-CimInstance Win32_BaseBoard | Select-Object Manufacturer,Product,Version}
  BIOS={Get-CimInstance Win32_BIOS | Select-Object SMBIOSBIOSVersion,ReleaseDate}
  GPU={Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,CurrentHorizontalResolution,CurrentVerticalResolution,CurrentRefreshRate}
  RAM={Get-CimInstance Win32_PhysicalMemory | Select-Object Capacity,ConfiguredClockSpeed,PartNumber}
  Disks={Get-PhysicalDisk | Select-Object FriendlyName,MediaType,Size,HealthStatus}
  FreeSpace={Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | Select-Object DeviceID,Size,FreeSpace}
  Pagefile={Get-CimInstance Win32_ComputerSystem | Select-Object AutomaticManagedPagefile}
  Power={Invoke-Native 'powercfg.exe' @('/getactivescheme')}
  TRIM={Invoke-Native 'fsutil.exe' @('behavior','query','DisableDeleteNotify')}
  Defender={Get-MpComputerStatus | Select-Object AMRunningMode,AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureLastUpdated}
  Boot={Get-BootState}
  VBS={Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard -ClassName Win32_DeviceGuard | Select-Object VirtualizationBasedSecurityStatus,SecurityServicesRunning}
 }
 foreach ($name in $queries.Keys) {
  try { $report[$name] = & $queries[$name] } catch { $report[$name] = "Unavailable: $($_.Exception.Message)" }
 }
 Write-Json (Join-Path $dir 'inventory.json') $report
 $report | ConvertTo-Json -Depth 8 | Out-Host
 Write-Host "Report saved locally: $dir. No upload occurs. This is not a benchmark."
}
function Export-DisplayDrivers {
 Require-Admin
 $drivers = @(Get-CimInstance Win32_PnPSignedDriver | Where-Object { $_.DeviceClass -eq 'DISPLAY' -and $_.Manufacturer -match 'NVIDIA' } | Select-Object DeviceName,DriverVersion,InfName -Unique)
 if ($drivers.Count -eq 0) { throw 'No NVIDIA display driver package found.' }
 $drivers | Format-Table | Out-Host
 if (-not (Confirm-Action 'Exports the installed NVIDIA driver packages to local backup files, possibly several GB. No driver is installed or deleted. This does not back up NVIDIA profiles; export those from Profile Inspector separately.' 'EXPORT')) { return }
 $dir = New-StateDirectory 'drivers'
 Write-Json (Join-Path $dir 'packages.json') $drivers
 foreach ($driver in $drivers) {
  if ($driver.InfName -notmatch '^oem\d+\.inf$') { throw 'Unrecognized INF name.' }
  Write-Host (Invoke-Native 'pnputil.exe' @('/export-driver',$driver.InfName,$dir))
 }
 Write-Host "Driver files exported to $dir. Keep the vendor installer for rollback too."
}
function Open-Inspector {
 $dir = Join-Path $PSScriptRoot 'tools\ProfileInspector'
 $expected = @{
  'nvidiaProfileInspector.exe'='1EBD8129B3C564BF226291FB3344819FD59668066F0C5E03334A69A04A62859E'
  'nvidiaProfileInspector.exe.config'='051099983B896673909E01A1F631B6652ABB88DA95C9F06F3EFEF4BE033091FA'
  'Reference.xml'='0EA7B055AEE5C543047243D2DD7ABDD1B8C6D96F5D2B7BB5FE17BE8130E005EF'
 }
 foreach ($name in $expected.Keys) {
  $path = Join-Path $dir $name
  if (-not (Test-Path -LiteralPath $path) -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $expected[$name]) { throw "Helper missing or changed: $name. See ASSET AUDIT.txt; do not bypass the check." }
 }
 if (-not (Confirm-Action 'Opens upstream NVIDIA Profile Inspector 3.0.2.1, an unsigned third-party tool. Source/digest and local scan were checked; that is not a safety guarantee. Export your profiles first, then follow the game guide. No profile is imported automatically.' 'OPEN')) { return }
 Start-Process -FilePath (Join-Path $dir 'nvidiaProfileInspector.exe') -WorkingDirectory $dir
}
function Get-RemovableApps {
 @(Get-AppxPackage | Where-Object { $_.Name -in $script:AppAllowlist -and -not $_.IsFramework -and -not $_.NonRemovable } | Sort-Object Name)
}
function Select-Indices([string]$Text,[int]$Count) {
 if ($Text -eq 'ALL') { return @(0..($Count-1)) }
 $result = @()
 foreach ($part in ($Text -split '[, ]+' | Where-Object { $_ })) {
  $n = 0
  if (-not [int]::TryParse($part,[ref]$n) -or $n -lt 1 -or $n -gt $Count) { throw 'Use listed numbers separated by commas, or ALL.' }
  $result += $n - 1
 }
 return @($result | Sort-Object -Unique)
}
function Remove-SelectedApps {
 $apps = @(Get-RemovableApps)
 if ($apps.Count -eq 0) { Write-Host 'No allowlisted optional apps installed for this account.'; return }
 Write-Host 'Optional apps for the CURRENT account only. Nothing is preselected.'
 for ($i=0;$i -lt $apps.Count;$i++) { Write-Host ('{0}. {1}' -f ($i+1),$apps[$i].Name) }
 $text = Read-Host 'Numbers separated by commas, ALL, or Enter to cancel'
 if (-not $text) { return }
 $indices = @(Select-Indices $text $apps.Count)
 if ($indices.Count -eq 0) { return }
 $selected = @($indices | ForEach-Object { $apps[$_] })
 $selected | Select-Object Name,PackageFullName | Format-Table -Wrap | Out-Host
 if (-not (Confirm-Action 'Uninstalls ONLY the listed apps for this account. App data may be lost. The manifest is NOT a data backup or guaranteed undo. Reinstall available apps from Microsoft Store. XboxGamingOverlay is Game Bar; removing it removes its capture/overlay features. Store, installers, frameworks, gaming services and Windows Security are excluded.' 'UNINSTALL')) { return }
 $dir = New-StateDirectory 'apps'
 Write-Json (Join-Path $dir 'selected-apps.json') @($selected | Select-Object Name,PackageFullName,PackageFamilyName)
 $logPath = Join-Path $dir 'results.txt'
 [IO.File]::WriteAllText($logPath,"Selected app removal started`r`n")
 foreach ($app in $selected) {
  if ($app.Name -notin $script:AppAllowlist -or $app.IsFramework -or $app.NonRemovable) { throw 'App failed allowlist validation.' }
  try {
   Remove-AppxPackage -Package $app.PackageFullName -ErrorAction Stop
   Add-Content -LiteralPath $logPath -Value "Removed: $($app.Name)"
   Write-Host "Removed: $($app.Name)"
  } catch { Add-Content -LiteralPath $logPath -Value "Failed: $($app.Name): $_"; Write-Warning $_ }
 }
 Write-Host "Results: $logPath. Reinstall through Microsoft Store if needed; app data is not restored."
}
function Get-OldTempFiles([string]$Root,[datetime]$Cutoff) {
 $rootFull = [IO.Path]::GetFullPath($Root).TrimEnd('\')
 if (-not [IO.Directory]::Exists($rootFull)) { return @() }
 if (([IO.File]::GetAttributes($rootFull) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Temp root is a link; cleanup blocked.' }
 $stack = [Collections.Generic.Stack[string]]::new()
 $stack.Push($rootFull)
 while ($stack.Count -gt 0) {
  $dir = $stack.Pop()
  try { $items = @(Get-ChildItem -LiteralPath $dir -Force -ErrorAction Stop) } catch { continue }
  foreach ($item in $items) {
   if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
   if ($item.PSIsContainer) { $stack.Push($item.FullName) }
   elseif ($item.LastWriteTime -lt $Cutoff -and $item.FullName.StartsWith($rootFull+'\',[StringComparison]::OrdinalIgnoreCase)) { $item }
  }
 }
}
function Test-TempPath([string]$Root,[string]$Path) {
 $rootFull = [IO.Path]::GetFullPath($Root).TrimEnd('\')
 $full = [IO.Path]::GetFullPath($Path)
 if (-not $full.StartsWith($rootFull+'\',[StringComparison]::OrdinalIgnoreCase)) { return $false }
 $cursor = $full
 while ($cursor -and $cursor.Length -ge $rootFull.Length) {
  if (([IO.File]::GetAttributes($cursor) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { return $false }
  if ($cursor -eq $rootFull) { return $true }
  $cursor = [IO.Path]::GetDirectoryName($cursor)
 }
 return $false
}
function Clear-OldUserTemp {
 $root = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Temp'
 $cutoff = (Get-Date).AddDays(-7)
 $files = @(Get-OldTempFiles $root $cutoff)
 if ($files.Count -eq 0) { Write-Host 'No eligible old files.'; return }
 $bytes = ($files | Measure-Object Length -Sum).Sum
 Write-Host ('Preview: {0} files, {1:N1} MiB under {2}' -f $files.Count,($bytes/1MB),$root)
 $files | Select-Object -First 25 FullName,LastWriteTime,Length | Format-Table -Wrap | Out-Host
 if (-not (Confirm-Action 'Deletes only files last modified over 7 days ago in this account temp folder. Links and locked files are skipped; folders, Downloads, Windows Update and shader caches are not cleaned. Deletion has no undo. Close other apps first.' 'DELETE')) { return }
 $dir = New-StateDirectory 'temp'
 Write-Json (Join-Path $dir 'preview.json') @($files | Select-Object FullName,LastWriteTime,Length)
 $logPath = Join-Path $dir 'results.txt'
 [IO.File]::WriteAllText($logPath,"Old temp-file cleanup started`r`n")
 $deleted = 0
 foreach ($file in $files) {
  try {
   if (-not (Test-TempPath $root $file.FullName)) { continue }
   $current = Get-Item -LiteralPath $file.FullName -Force
   if ($current.PSIsContainer -or $current.LastWriteTime -ge $cutoff) { continue }
   [IO.File]::Delete($current.FullName)
   $deleted++
   Add-Content -LiteralPath $logPath -Value "Deleted: $($current.FullName)"
  } catch { Add-Content -LiteralPath $logPath -Value "Skipped: $($file.FullName): $_" }
 }
 Write-Host "$deleted files deleted. Log: $logPath"
}
function Record-DefenderImpact {
 Require-Admin
 if (-not (Get-Command New-MpPerformanceRecording -ErrorAction SilentlyContinue)) { throw 'Defender performance recording is unavailable.' }
 Write-Host 'Records Defender scan activity while you reproduce stutter. This is not a frame-time benchmark. Press Enter in this console to stop.'
 Write-Host 'The local trace can contain process names and file paths. Nothing is uploaded.'
 if (-not (Confirm-Action 'Start the trace, switch to the game, reproduce the issue, then return here and press Enter.' 'RECORD')) { return }
 $dir = New-StateDirectory 'defender'
 $trace = Join-Path $dir 'scan.etl'
 New-MpPerformanceRecording -RecordTo $trace
 if (Test-Path -LiteralPath $trace) {
  Get-MpPerformanceReport -Path $trace -TopFiles 10 -TopProcesses 10 -TopScans 20 | Out-String -Width 220 | Set-Content -LiteralPath (Join-Path $dir 'analysis.txt')
  Write-Host "Saved to $dir. No protection settings were changed."
 }
}
function Open-GameControls {
 Write-Host '1 Game Mode; 2 Background recording; 3 Graphics/HAGS/windowed optimizations; 4 Startup apps; 5 Windows optional features; 6 Windows Security; 7 Installed apps.'
 $uri = switch (Read-Host 'Control') {
  '1' {'ms-settings:gaming-gamemode'} '2' {'ms-settings:gaming-gamedvr'}
  '3' {'ms-settings:display-advancedgraphics'} '4' {'ms-settings:startupapps'}
  '6' {'ms-settings:windowsdefender'} '7' {'ms-settings:appsfeatures'}
  '5' { Write-Host 'Optional features can affect games and other apps. Keep security, runtime and virtualization components required by Siege. Windows handles dependencies and restart prompts.'; Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\OptionalFeatures.exe'); return }
  default {return}
 }
 if ($uri) { Start-Process $uri }
}
function Show-Menu {
 while ($true) {
  Write-Host "`nPERFORMANCE UTILITY - Fortnite / Rainbow Six / AM4 X3D" -ForegroundColor Cyan
  Write-Host '1 Inventory report                 2 Power-plan comparison'
  Write-Host '3 Undo power-plan change           4 Export boot backup / inspect'
  Write-Host '5 Restore automatic boot timers    6 Undo saved boot changes'
  Write-Host '7 Export NVIDIA driver packages    8 Open checked Profile Inspector'
  Write-Host '9 Select apps for bulk uninstall  10 Preview/delete old user temp files'
  Write-Host '11 Open tuning guide              12 Windows gaming / feature controls'
  Write-Host '13 Measure Defender scan impact    Q Quit'
  Write-Host 'No one-click preset, Defender removal, automatic download or reboot.'
  try {
   switch ((Read-Host 'Action').Trim().ToUpperInvariant()) {
    '1' {Save-Inventory} '2' {Set-TestPowerPlan} '3' {Undo-Power}
    '4' {$b=Backup-Boot; $b.State.Values | Format-List | Out-Host; Write-Host "Backup: $($b.Directory)"}
    '5' {Reset-BootOverrides} '6' {Undo-Boot} '7' {Export-DisplayDrivers}
    '8' {Open-Inspector} '9' {Remove-SelectedApps} '10' {Clear-OldUserTemp}
    '11' {Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\notepad.exe') -ArgumentList ('"'+(Join-Path $PSScriptRoot 'GAMING GUIDE.txt')+'"')}
    '12' {Open-GameControls} '13' {Record-DefenderImpact} 'Q' {return}
    default {Write-Host 'Choose a listed action.'}
   }
  } catch { Write-Host $_.Exception.Message -ForegroundColor Red }
 }
}
if ($LibraryOnly) { return }
if ($ReportOnly) { Save-Inventory; return }
Show-Menu
