#requires -Version 5.1
# This file is loaded after Control Engine.ps1. Mutations are limited to
# enumerated physical adapters and a fixed, reviewed advanced-property catalog.
function Get-NetworkCatalog {
 @(
  [pscustomobject]@{Id='nic-rss';Name='Receive Side Scaling';Class='Baseline';Description='Distribute receive processing across CPU cores. Keep enabled unless diagnosing a specific driver problem.';Source='https://learn.microsoft.com/en-us/windows-hardware/drivers/network/introduction-to-receive-side-scaling';Keys=@('*RSS');On='1';Off='0'}
  [pscustomobject]@{Id='nic-checksum';Name='Checksum offload';Class='Baseline';Description='Let the adapter calculate IP, TCP and UDP checksums. Disabling this is not a general gaming-latency fix.';Source='https://learn.microsoft.com/en-us/windows-hardware/drivers/network/performance-in-network-adapters';Keys=@('*IPChecksumOffloadIPv4','*TCPChecksumOffloadIPv4','*TCPChecksumOffloadIPv6','*UDPChecksumOffloadIPv4','*UDPChecksumOffloadIPv6');On='3';Off='0'}
  [pscustomobject]@{Id='nic-lso';Name='Large Send Offload';Class='Compare';Description='Offload TCP segmentation. Compare only if troubleshooting; it does not directly optimize game UDP packets.';Source='https://learn.microsoft.com/en-us/windows-hardware/drivers/network/performance-in-network-adapters';Keys=@('*LsoV2IPv4','*LsoV2IPv6');On='1';Off='0'}
  [pscustomobject]@{Id='nic-no-eee';Name='Disable Energy-Efficient Ethernet';Class='Compare';Description='Avoid Ethernet low-power idle transitions. A driver-dependent experiment, not a guaranteed internet-ping improvement.';Source='https://learn.microsoft.com/en-us/windows-hardware/drivers/network/standardized-inf-keywords-for-power-management';Keys=@('*EEE');On='0';Off='1'}
  [pscustomobject]@{Id='nic-no-moderation';Name='Disable interrupt moderation';Class='Compare';Description='Trade more CPU interrupts for faster packet notification. Keep only if repeatable latency and frame-time tests improve.';Source='https://learn.microsoft.com/en-us/windows-server/networking/technologies/network-subsystem/net-sub-performance-tuning-nics';Keys=@('*InterruptModeration');On='0';Off='1'}
 )
}
function Get-PhysicalNetworkAdapters { @(Get-NetAdapter -Physical -ErrorAction Stop) }
function Get-ExactNetworkAdapter([string]$AdapterId) {
 $parsed=[guid]::Empty
 if(-not [guid]::TryParse($AdapterId,[ref]$parsed)){throw 'Invalid network adapter identifier.'}
 $matches=@(Get-PhysicalNetworkAdapters | Where-Object { [string]$_.InterfaceGuid -and [guid]$_.InterfaceGuid -eq $parsed })
 if($matches.Count -ne 1){throw 'The selected physical adapter is no longer available. Refresh the inventory.'}
 $matches[0]
}
function Get-ExactNetworkProperties($Adapter) {
 # Escape wildcard characters in adapter names; names are not trusted selectors.
 @(Get-NetAdapterAdvancedProperty -Name ([Management.Automation.WildcardPattern]::Escape($Adapter.Name)) -ErrorAction Stop)
}
function Get-NetworkInventory {
 foreach($a in Get-PhysicalNetworkAdapters) {
  [pscustomobject]@{Id=[string]$a.InterfaceGuid;Name=$a.Name;Description=$a.InterfaceDescription;Status=[string]$a.Status;LinkSpeed=[string]$a.LinkSpeed;DriverVersion=[string]$a.DriverVersion;DriverDate=[string]$a.DriverDate;InterfaceIndex=$a.ifIndex}
 }
}
function Get-NetworkSettingStates([string]$AdapterId) {
 $a=Get-ExactNetworkAdapter $AdapterId;$properties=@(Get-ExactNetworkProperties $a)
 foreach($item in Get-NetworkCatalog) {
  $on=$true;$off=$true;$supported=$true;$details=@()
  foreach($key in $item.Keys) {
   $p=@($properties | Where-Object RegistryKeyword -ceq $key)
   if($p.Count -ne 1 -or @($p[0].RegistryValue).Count -ne 1 -or $item.On -notin $p[0].ValidRegistryValues -or $item.Off -notin $p[0].ValidRegistryValues){$supported=$false;break}
   $on=$on -and ([string]$p[0].RegistryValue[0] -ceq $item.On)
   $off=$off -and ([string]$p[0].RegistryValue[0] -ceq $item.Off)
   $details+=($p[0].DisplayName+': '+$p[0].DisplayValue)
  }
  [pscustomobject]@{Id=$item.Id;Name=$item.Name;Class=$item.Class;Description=$item.Description;Source=$item.Source;Supported=$supported;State=$(if(-not $supported){'Unavailable'}elseif($on){'On'}elseif($off){'Off'}else{'Custom'});Details=($details -join "`n")}
 }
}
function Assert-NetworkAdmin {
 if(-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Restart KKxtti as administrator to configure a network adapter.'}
}
function Get-NetworkProperty($Adapter,[string]$Keyword) {
 $p=@(Get-ExactNetworkProperties $Adapter | Where-Object RegistryKeyword -ceq $Keyword)
 if($p.Count -ne 1 -or @($p[0].RegistryValue).Count -ne 1){throw ('Driver property is unavailable: '+$Keyword)}
 $p[0]
}
function Set-NetworkProperty($Property,[string]$Value) {
 if($Value -notin $Property.ValidRegistryValues){throw ('Driver does not support this value for '+$Property.RegistryKeyword)}
 # Stage without disconnecting the user. Reconnect is an explicit separate action.
 Set-NetAdapterAdvancedProperty -InputObject $Property -RegistryValue @($Value) -NoRestart -ErrorAction Stop
}
function Get-NetworkHardwareIdentity($Adapter) {
 [pscustomobject]@{Id=([guid]$Adapter.InterfaceGuid).ToString();Description=[string]$Adapter.InterfaceDescription;DeviceId=[string]$Adapter.PnPDeviceID;Driver=[string]$Adapter.DriverVersion}
}
function Assert-NetworkHardware($Adapter,$Identity) {
 $actual=Get-NetworkHardwareIdentity $Adapter
 foreach($key in @('Id','Description','DeviceId','Driver')){if([string]$actual.$key -cne [string]$Identity.$key){throw 'The adapter or driver changed since this backup was created. Automatic restore was stopped.'}}
}
function Assert-NetworkRow($Row) {
 $item=@(Get-NetworkCatalog | Where-Object Id -ceq $Row.Id)
 if($item.Count -ne 1 -or $Row.Keyword -cnotin $item[0].Keys){throw 'Invalid network setting in saved state.'}
 foreach($value in @($Row.Before,$Row.After)){if($value -isnot [string] -or $value -notmatch '^\d{1,5}$'){throw 'Invalid driver value in saved state.'}}
}
function Invoke-NetworkRows($Rows,$Adapter,$Saved,[ValidateSet('Apply','Undo')]$Mode) {
 $attempted=New-Object Collections.Generic.List[object]
 try {
  foreach($row in $Rows) {
   $a=Get-ExactNetworkAdapter $Saved.Journal.Adapter.Id;Assert-NetworkHardware $a $Saved.Journal.Adapter
   $p=Get-NetworkProperty $a $row.Keyword
   $expected=if($Mode -eq 'Apply'){$row.Before}else{$row.After}
   $target=if($Mode -eq 'Apply'){$row.After}else{$row.Before}
   if([string]$p.RegistryValue[0] -cne $expected){throw ('The driver setting changed externally: '+$row.Keyword)}
   $attempted.Add($row);Set-NetworkProperty $p $target
   if([string](Get-NetworkProperty $a $row.Keyword).RegistryValue[0] -cne $target){throw ('Driver readback failed: '+$row.Keyword)}
  }
  $Saved.Journal.Status=if($Mode -eq 'Apply'){'Applied'}else{'Undone'}
  $Saved.Journal.NeedsReconnect=$true
  Save-ControlJournal $Saved.Path $Saved.Journal
 } catch {
  $message=$_.Exception.Message;$failures=@()
  for($i=$attempted.Count-1;$i -ge 0;$i--) {
   $row=$attempted[$i];$prior=if($Mode -eq 'Apply'){$row.Before}else{$row.After}
   try{$a=Get-ExactNetworkAdapter $Saved.Journal.Adapter.Id;Assert-NetworkHardware $a $Saved.Journal.Adapter;$p=Get-NetworkProperty $a $row.Keyword;Set-NetworkProperty $p $prior;if([string](Get-NetworkProperty $a $row.Keyword).RegistryValue[0] -cne $prior){throw 'Rollback readback failed'}}catch{$failures+=$row.Keyword}
  }
  $Saved.Journal.Status=if($failures.Count){'Recovery needed'}elseif($Mode -eq 'Undo'){'Applied'}else{'Rolled back'}
  try{Save-ControlJournal $Saved.Path $Saved.Journal}catch{$message+=' Could not update the journal.'}
  if($failures.Count){throw ($message+' Manual recovery needed: '+($failures -join ', ')+'. Backup: '+$Saved.Path)}
  throw ($message+' Attempted driver changes were rolled back without restarting the adapter.')
 }
 [pscustomobject]@{Id=$Saved.Journal.Id;Status=$Saved.Journal.Status;Count=@($Rows).Count;NeedsReconnect=$true}
}
function Set-NetworkSettings([string]$AdapterId,[string[]]$Ids,[bool]$Enabled) {
 Assert-NetworkAdmin
 if(-not $Ids -or $Ids.Count -gt 10){throw 'Choose a network setting.'}
 $a=Get-ExactNetworkAdapter $AdapterId;$catalog=@(Get-NetworkCatalog);$rows=@()
 foreach($id in ($Ids | Select-Object -Unique)) {
  $item=@($catalog | Where-Object Id -ceq $id);if($item.Count -ne 1){throw 'Unknown network setting.'}
  foreach($key in $item[0].Keys) {
   $p=Get-NetworkProperty $a $key;$target=if($Enabled){$item[0].On}else{$item[0].Off};$before=[string]$p.RegistryValue[0]
   if($target -notin $p.ValidRegistryValues -or $before -notin $p.ValidRegistryValues){throw ('Unsupported driver value for '+$key)}
   if($before -cne $target){$rows+=[pscustomobject]@{Id=$id;Keyword=$key;Before=$before;After=[string]$target}}
  }
 }
 if($rows.Count -eq 0){return [pscustomobject]@{Id='';Status='Already configured';Count=0;NeedsReconnect=$false}}
 $saved=New-ControlJournal 'network' $rows
 $saved.Journal | Add-Member NoteProperty Adapter (Get-NetworkHardwareIdentity $a)
 $saved.Journal | Add-Member NoteProperty NeedsReconnect $false
 Save-ControlJournal $saved.Path $saved.Journal
 Invoke-NetworkRows $rows $a $saved 'Apply'
}
function Undo-NetworkSettings([string]$Id) {
 Assert-NetworkAdmin
 if($Id -notmatch '^network-\d{8}-\d{6}-[a-f0-9]{8}$'){throw 'Choose a valid network backup.'}
 $path=Join-Path (Join-Path (Join-Path $script:ControlRoot 'State') $Id) 'transaction.json'
 if((Get-Item -LiteralPath $path).Length -gt 2000000){throw 'Network backup exceeds size limit.'}
 $j=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
 if($j.Schema -ne 1 -or $j.Id -ne $Id -or $j.Status -ne 'Applied' -or $j.Computer -ne $env:COMPUTERNAME -or $j.Sid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'This backup is not an applied network change for this account and PC.'}
 $a=Get-ExactNetworkAdapter $j.Adapter.Id;Assert-NetworkHardware $a $j.Adapter
 $seen=@{}
 if(@($j.Rows).Count -eq 0 -or @($j.Rows).Count -gt 12){throw 'Invalid network backup row count.'}
 foreach($row in $j.Rows) {
  Assert-NetworkRow $row
  if($seen.ContainsKey($row.Keyword)){throw 'Duplicate driver property in saved state.'};$seen[$row.Keyword]=$true
  $p=Get-NetworkProperty $a $row.Keyword
  if([string]$p.RegistryValue[0] -cne $row.After){throw 'A newer or external driver change conflicts with this backup. Nothing changed.'}
  if($row.Before -notin $p.ValidRegistryValues){throw 'Driver no longer supports the saved value.'}
 }
 $j.Status='Undoing';Save-ControlJournal $path $j
 Invoke-NetworkRows @($j.Rows) $a ([pscustomobject]@{Path=$path;Journal=$j}) 'Undo'
}
function Get-NetworkHistory([string]$AdapterId) {
 $id=([guid]$AdapterId).ToString()
 $state=Join-Path $script:ControlRoot 'State'
 if(-not (Test-Path -LiteralPath $state)){return}
 foreach($dir in Get-ChildItem -LiteralPath $state -Directory -Filter 'network-*' | Sort-Object Name -Descending) {
  $path=Join-Path $dir.FullName 'transaction.json'
  try {
   if((Get-Item -LiteralPath $path -ErrorAction Stop).Length -gt 2MB){continue}
   $j=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
   if($j.Status -eq 'Applied' -and $j.Adapter.Id -eq $id){[pscustomobject]@{Id=$dir.Name;Status=$j.Status}}
  }catch{continue}
 }
}
function Restart-SelectedNetworkAdapter([string]$AdapterId) {
 Assert-NetworkAdmin;$a=Get-ExactNetworkAdapter $AdapterId
 Restart-NetAdapter -InputObject $a -Confirm:$false -ErrorAction Stop
 [pscustomobject]@{Name=$a.Name;Status='Reconnect requested';Note='The link can take a few seconds to return. Refresh the adapter inventory after reconnecting.'}
}
function Get-NetworkProbeTargets([string]$AdapterId) {
 $a=Get-ExactNetworkAdapter $AdapterId
 if([string]$a.Status -ne 'Up'){throw 'Choose a connected Ethernet adapter to run the probe.'}
 $config=Get-NetIPConfiguration -InterfaceIndex $a.ifIndex -ErrorAction Stop
 $gateway=@($config.IPv4DefaultGateway | Select-Object -ExpandProperty NextHop -ErrorAction SilentlyContinue | Select-Object -First 1)
 if($gateway.Count -eq 1){$ip=$null;if([Net.IPAddress]::TryParse([string]$gateway[0],[ref]$ip)){[pscustomobject]@{Id='gateway';Name='Local gateway';Address=$ip.ToString()}}}
 [pscustomobject]@{Id='cloudflare';Name='Cloudflare anycast';Address='1.1.1.1'}
 [pscustomobject]@{Id='google';Name='Google anycast';Address='8.8.8.8'}
}
function Assert-NetworkProbeRoute([string]$AdapterId,[string]$Address) {
 $a=Get-ExactNetworkAdapter $AdapterId
 $route=@(Find-NetRoute -RemoteIPAddress $Address -ErrorAction Stop)
 if(-not $route.Count -or @($route | Where-Object { $_.InterfaceIndex -ne $a.ifIndex }).Count){throw 'This probe target uses a different adapter or VPN route. Choose the adapter that carries the traffic, or compare with the VPN disconnected.'}
}
function Get-ProbeSummary($Samples,[string]$Name) {
 $samples=@($Samples);$success=@($samples | Where-Object Status -eq 'Success');$sorted=@($success.Milliseconds | Sort-Object)
 $median=$null;$p95=$null;$average=$null;$jitter=$null;$min=$null;$max=$null
 if($sorted.Count){$middle=[int][math]::Floor($sorted.Count/2);$median=if($sorted.Count%2){[double]$sorted[$middle]}else{([double]$sorted[$middle-1]+[double]$sorted[$middle])/2};$p95=[double]$sorted[[int][math]::Ceiling($sorted.Count*.95)-1];$average=($sorted|Measure-Object -Average).Average;$min=$sorted[0];$max=$sorted[-1]}
 $differences=@();$last=$null
 foreach($s in $samples){if($s.Status -eq 'Success'){if($null -ne $last){$differences+=[math]::Abs([double]$s.Milliseconds-[double]$last)};$last=$s.Milliseconds}else{$last=$null}}
 if($differences.Count){$jitter=($differences|Measure-Object -Average).Average}
 [pscustomobject]@{Name=$Name;Sent=$samples.Count;Replies=$success.Count;LossPercent=$(if($samples.Count){100.0*($samples.Count-$success.Count)/$samples.Count}else{$null});MinMs=$min;MaxMs=$max;MedianMs=$median;P95Ms=$p95;AverageMs=$average;JitterMs=$jitter}
}
function Test-ProbeCancelled {
 $context=Get-Variable Ui -ValueOnly -ErrorAction SilentlyContinue
 ($null -ne $context -and $context.Cancelled)
}
function Invoke-NetworkProbe([string]$AdapterId,[ValidateRange(5,60)][int]$Count=30) {
 $targets=@(Get-NetworkProbeTargets $AdapterId);$records=@();$summaries=@()
 foreach($target in $targets) {
  if(Test-ProbeCancelled){break}
  Assert-NetworkProbeRoute $AdapterId $target.Address
  $samples=@();$ping=New-Object Net.NetworkInformation.Ping
  try {
   for($i=0;$i -lt $Count;$i++) {
    if(Test-ProbeCancelled){break}
    try{$reply=$ping.Send([Net.IPAddress]::Parse($target.Address),800);$status=[string]$reply.Status;$ms=if($reply.Status -eq 'Success'){$reply.RoundtripTime}else{$null}}catch{$status='Probe error';$ms=$null}
    $samples+=[pscustomobject]@{Status=$status;Milliseconds=$ms}
    Start-Sleep -Milliseconds 200
   }
  } finally {$ping.Dispose()}
  Assert-NetworkProbeRoute $AdapterId $target.Address
  $summaries+=Get-ProbeSummary $samples $target.Name
  $records+=[pscustomobject]@{Target=$target.Name;Samples=$samples}
 }
 $saved=New-ControlJournal 'latency' $records
 $saved.Journal.Status=if(Test-ProbeCancelled){'Cancelled'}else{'Completed'};Save-ControlJournal $saved.Path $saved.Journal
 foreach($summary in $summaries){$summary | Add-Member NoteProperty RecordId $saved.Journal.Id;$summary}
}
