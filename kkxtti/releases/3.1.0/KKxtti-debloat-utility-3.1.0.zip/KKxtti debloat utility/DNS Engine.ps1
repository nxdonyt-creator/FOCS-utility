#requires -Version 5.1
# Adapter-scoped DNS, preserving DHCP vs static mode for each IP family.
function Get-DnsProfiles {
 @(
  [pscustomobject]@{Id='automatic';Name='Automatic (DHCP)';IPv4=@();IPv6=@();Source='https://learn.microsoft.com/en-us/powershell/module/dnsclient/set-dnsclientserveraddress'}
  [pscustomobject]@{Id='cloudflare';Name='Cloudflare';IPv4=@('1.1.1.1','1.0.0.1');IPv6=@('2606:4700:4700::1111','2606:4700:4700::1001');Source='https://developers.cloudflare.com/1.1.1.1/ip-addresses/'}
  [pscustomobject]@{Id='google';Name='Google Public DNS';IPv4=@('8.8.8.8','8.8.4.4');IPv6=@('2001:4860:4860::8888','2001:4860:4860::8844');Source='https://developers.google.com/speed/public-dns/docs/using'}
  [pscustomobject]@{Id='quad9';Name='Quad9 (malware filtering)';IPv4=@('9.9.9.9','149.112.112.112');IPv6=@('2620:fe::fe','2620:fe::9');Source='https://quad9.net/service/'}
 )
}
function Get-DnsFamily($Adapter,[string]$Family) {
 $number=if($Family -eq 'IPv4'){2}elseif($Family -eq 'IPv6'){23}else{throw 'Invalid DNS address family.'}
 $found=@(Get-DnsClientServerAddress -InterfaceIndex $Adapter.ifIndex -ErrorAction Stop | Where-Object AddressFamily -eq $number)
 if($found.Count -ne 1){throw 'Cannot uniquely identify DNS configuration for the selected address family.'}
 $found[0]
}
function Read-DnsMode($Adapter,[string]$Family) {
 $guid=([guid]$Adapter.InterfaceGuid).ToString('B');$service=if($Family -eq 'IPv4'){'Tcpip'}else{'Tcpip6'}
 $policy=[Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Policies\Microsoft\Windows NT\DNSClient')
 try{if($policy -and $policy.GetValue('NameServer','')){throw 'An organization DNS policy is active. KKxtti will not override it.'}}finally{if($policy){$policy.Dispose()}}
 $global=[Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Services\'+$service+'\Parameters')
 try{if($global -and $global.GetValue('NameServer','')){throw 'Global static DNS is configured; adapter-scoped restoration is ambiguous.'}}finally{if($global){$global.Dispose()}}
 $key=[Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Services\'+$service+'\Parameters\Interfaces\'+$guid)
 try{if(-not $key){throw 'Cannot read the selected adapter DNS mode.'};[string]$key.GetValue('NameServer','')}finally{if($key){$key.Dispose()}}
}
function Read-DnsValue($Adapter,[string]$Family) {
 $object=Get-DnsFamily $Adapter $Family;$configured=Read-DnsMode $Adapter $Family
 $servers=@($object.ServerAddresses | ForEach-Object {([ipaddress]$_).ToString()})
 if($configured){
  $saved=@($configured -split '[,;\s]+' | Where-Object {$_} | ForEach-Object {([ipaddress]$_).ToString()})
  if(($saved -join ',') -cne ($servers -join ',')){throw 'DNS mode and active server list disagree. No automatic change is safe.'}
 }
 [pscustomobject]@{Automatic=[bool](-not $configured);Servers=$servers}
}
function Assert-DnsValue($Family,$Value) {
 if($Family -notin @('IPv4','IPv6') -or $Value.Automatic -isnot [bool] -or @($Value.Servers).Count -gt 8 -or (-not $Value.Automatic -and @($Value.Servers).Count -eq 0)){throw 'Invalid saved DNS state.'}
 foreach($s in $Value.Servers){$ip=$null;if(-not [ipaddress]::TryParse([string]$s,[ref]$ip)){throw 'Invalid DNS server.'};$expected=if($Family -eq 'IPv4'){[Net.Sockets.AddressFamily]::InterNetwork}else{[Net.Sockets.AddressFamily]::InterNetworkV6};if($ip.AddressFamily -ne $expected){throw 'DNS server belongs to another address family.'}}
}
function Test-DnsEqual($A,$B) {if([bool]$A.Automatic -ne [bool]$B.Automatic){return $false};if($A.Automatic){return $true};(@($A.Servers) -join ',') -ceq (@($B.Servers) -join ',')}
function Write-DnsValue($Adapter,$Family,$Value) {
 Assert-DnsValue $Family $Value;Assert-NetworkAdmin;$object=Get-DnsFamily $Adapter $Family
 if($Value.Automatic){Set-DnsClientServerAddress -InputObject $object -ResetServerAddresses -ErrorAction Stop}
 else{Set-DnsClientServerAddress -InputObject $object -ServerAddresses @($Value.Servers) -ErrorAction Stop}
}
function Get-SelectedDnsStates([string]$AdapterId) {
 $adapter=Get-ExactNetworkAdapter $AdapterId
 foreach($family in @('IPv4','IPv6')){try{$value=Read-DnsValue $adapter $family;[pscustomobject]@{Family=$family;Mode=$(if($value.Automatic){'Automatic'}else{'Static'});Servers=($value.Servers -join ', ')}}catch{[pscustomobject]@{Family=$family;Mode='Unavailable';Servers=$_.Exception.Message}}}
}
function Invoke-DnsRows($Rows,$Saved,[ValidateSet('Apply','Undo')]$Mode) {
 $attempted=@()
 try{
  foreach($row in $Rows){$adapter=Get-ExactNetworkAdapter $Saved.Journal.Adapter.Id;Assert-NetworkHardware $adapter $Saved.Journal.Adapter
   $expected=if($Mode -eq 'Apply'){$row.Before}else{$row.After};$target=if($Mode -eq 'Apply'){$row.After}else{$row.Before}
   if(-not(Test-DnsEqual (Read-DnsValue $adapter $row.Family) $expected)){throw 'DNS configuration changed externally. No later change will be overwritten.'}
   $attempted+=$row;Write-DnsValue $adapter $row.Family $target
   if(-not(Test-DnsEqual (Read-DnsValue $adapter $row.Family) $target)){throw 'DNS readback failed.'}
  }
  $Saved.Journal.Status=if($Mode -eq 'Apply'){'Applied'}else{'Undone'};Save-ControlJournal $Saved.Path $Saved.Journal
 }catch{
  $problem=$_.Exception.Message;$failures=@()
  for($i=$attempted.Count-1;$i -ge 0;$i--){$row=$attempted[$i];$prior=if($Mode -eq 'Apply'){$row.Before}else{$row.After}
   try{$adapter=Get-ExactNetworkAdapter $Saved.Journal.Adapter.Id;Assert-NetworkHardware $adapter $Saved.Journal.Adapter;Write-DnsValue $adapter $row.Family $prior;if(-not(Test-DnsEqual (Read-DnsValue $adapter $row.Family) $prior)){throw 'Rollback readback failed.'}}catch{$failures+=$row.Family}
  }
  $Saved.Journal.Status=if($failures.Count){'Recovery needed'}elseif($Mode -eq 'Undo'){'Applied'}else{'Rolled back'};Save-ControlJournal $Saved.Path $Saved.Journal;throw ($problem+' '+$Saved.Journal.Status)
 }
 [pscustomobject]@{Id=$Saved.Journal.Id;Status=$Saved.Journal.Status}
}
function Set-SelectedDnsProfile([string]$AdapterId,[string]$ProfileId) {
 Assert-NetworkAdmin;$profile=@(Get-DnsProfiles | Where-Object Id -ceq $ProfileId);if($profile.Count -ne 1){throw 'Choose a reviewed DNS profile.'}
 $adapter=Get-ExactNetworkAdapter $AdapterId;$rows=@()
 foreach($family in @('IPv4','IPv6')){$before=Read-DnsValue $adapter $family;Assert-DnsValue $family $before;$after=[pscustomobject]@{Automatic=[bool]($ProfileId -eq 'automatic');Servers=@($profile[0].$family)};Assert-DnsValue $family $after;if(-not(Test-DnsEqual $before $after)){$rows+=[pscustomobject]@{Family=$family;Before=$before;After=$after}}}
 if(-not $rows.Count){return [pscustomobject]@{Status='Already configured';Id=''}}
 if(-not(Confirm-Action ('Change DNS for '+$adapter.Name+' to '+$profile[0].Name+'? DNS affects name lookups; this does not guarantee a lower ping to an already connected game. Public resolvers may break local/organization names or filter domains. Both IP-family modes are saved for undo. Other adapters are untouched. No adapter restart or DNS cache flush is requested.') 'APPLY')){return}
 $saved=New-ControlJournal 'dns' $rows;$saved.Journal | Add-Member NoteProperty Adapter (Get-NetworkHardwareIdentity $adapter);Save-ControlJournal $saved.Path $saved.Journal
 Invoke-DnsRows $rows $saved 'Apply'
}
function Read-DnsJournal([string]$Id) {
 if($Id -cnotmatch '^dns-\d{8}-\d{6}-[a-f0-9]{8}$'){throw 'Invalid DNS backup.'}
 $path=Join-Path (Join-Path (Join-Path $script:ControlRoot 'State') $Id) 'transaction.json';if((Get-Item -LiteralPath $path).Length -gt 2MB){throw 'DNS backup too large.'};$j=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
 if($j.Schema -ne 1 -or $j.Id -cne $Id -or $j.Status -notin @('Applied','Prepared','Undoing','Recovery needed') -or $j.Computer -ne $env:COMPUTERNAME -or $j.Sid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -or @($j.Rows).Count -notin @(1,2)){throw 'Invalid DNS record for this account and PC.'}
 $seen=@{};foreach($row in $j.Rows){Assert-DnsValue $row.Family $row.Before;Assert-DnsValue $row.Family $row.After;if($seen.ContainsKey($row.Family)){throw 'Duplicate DNS family.'};$seen[$row.Family]=$true}
 $adapter=Get-ExactNetworkAdapter $j.Adapter.Id;Assert-NetworkHardware $adapter $j.Adapter
 [pscustomobject]@{Path=$path;Journal=$j}
}
function Undo-SelectedDnsProfile([string]$Id) {
 Assert-NetworkAdmin;$saved=Read-DnsJournal $Id;$adapter=Get-ExactNetworkAdapter $saved.Journal.Adapter.Id;$rows=@()
 foreach($row in $saved.Journal.Rows){$current=Read-DnsValue $adapter $row.Family;if(Test-DnsEqual $current $row.Before){continue};if(-not(Test-DnsEqual $current $row.After)){throw 'A newer or external DNS change conflicts. No settings changed.'};$rows+=$row}
 if(-not(Confirm-Action 'Restore saved DNS modes and static server lists? DHCP addresses can legitimately change; automatic mode restores DHCP rather than forcing old dynamic addresses.' 'RESTORE')){return}
 $saved.Journal.Status='Undoing';Save-ControlJournal $saved.Path $saved.Journal
 if($rows.Count){Invoke-DnsRows $rows $saved 'Undo'}else{$saved.Journal.Status='Undone';Save-ControlJournal $saved.Path $saved.Journal;[pscustomobject]@{Status='Already original';Id=$Id}}
}
