﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace KKxtti {
 public static class Program {
  [STAThread] public static void Main(string[] args) {
   bool secondary=args.Contains("--secondary-monitor"),preview=args.Contains("--read-only-preview");
   if(secondary&&!System.Windows.Forms.Screen.AllScreens.Any(screen=>!screen.Primary)){Environment.ExitCode=2;return;}
   try {
    var app = new Application();
    app.DispatcherUnhandledException += (s,e) => { if(app.MainWindow!=null)MessageBox.Show(app.MainWindow,e.Exception.Message,"KKxtti - interface error"); e.Handled=true; };
    app.Run(new Dashboard(secondary,preview));
   } catch(Exception ex) { if(secondary){Environment.ExitCode=1;return;}MessageBox.Show(ex.ToString(),"KKxtti could not start"); }
  }
 }

 // The dashboard calls the existing audited operations in a fresh background
 // runspace. User choices are passed as variables, never concatenated as code.
 public class ActionBridge {
  readonly Dashboard ui;
  public volatile bool Cancelled;
  public string Answer = "";
  public string BackupPath;
  public readonly StringBuilder Preview = new StringBuilder();
  public ActionBridge(Dashboard window) { ui=window; }
  public virtual void Log(string text) {
   if(String.IsNullOrWhiteSpace(text)) return;
   if(Preview.Length<60000) Preview.AppendLine(text);
   ui.Dispatcher.BeginInvoke(new Action(()=>ui.Log(text)));
  }
  public virtual string Prompt(string prompt) { return Answer; }
  public virtual bool Confirm(string message,string word) {
   bool accepted=(bool)ui.Dispatcher.Invoke(new Func<bool>(()=>ui.ConfirmOperation(message,word,Preview.ToString())));
   if(!accepted) Cancelled=true;
   return accepted;
  }
  public virtual string Backup(string kind) {
   if(!String.IsNullOrEmpty(BackupPath)) return BackupPath;
   string value=(string)ui.Dispatcher.Invoke(new Func<string>(()=>ui.ChooseBackup(kind)));
   if(String.IsNullOrEmpty(value)) Cancelled=true;
   return value;
  }
 }

 public static class Backend {
  public const string SelectedAppCommand=@"
$script:UiApps=@(Get-RemovableApps)
$indices=@()
foreach($package in $SelectedPackages) {
 $found=$false
 for($i=0;$i -lt $script:UiApps.Count;$i++) {
  if($script:UiApps[$i].PackageFullName -eq $package){$indices+=($i+1);$found=$true;break}
 }
 if(-not $found){throw 'An app changed since the preview. Refresh the app list and select again.'}
}
$Ui.Answer=($indices -join ',')
function Get-RemovableApps { $script:UiApps }
Remove-SelectedApps
";
  public static Collection<PSObject> Run(string root,string command,ActionBridge bridge,Dictionary<string,object> variables=null) {
   var initial=InitialSessionState.CreateDefault();
   initial.ExecutionPolicy=Microsoft.PowerShell.ExecutionPolicy.RemoteSigned;
   using(var runspace=RunspaceFactory.CreateRunspace(initial)) {
    runspace.Open();
    runspace.SessionStateProxy.SetVariable("UtilityPath",System.IO.Path.Combine(root,"Performance Utility.ps1"));
    runspace.SessionStateProxy.SetVariable("Ui",bridge);
    runspace.SessionStateProxy.SetVariable("ControlPath",System.IO.Path.Combine(root,"Control Engine.ps1"));
    runspace.SessionStateProxy.SetVariable("NetworkPath",System.IO.Path.Combine(root,"Network Engine.ps1"));
    runspace.SessionStateProxy.SetVariable("GamePath",System.IO.Path.Combine(root,"Game Engine.ps1"));
    runspace.SessionStateProxy.SetVariable("RecoveryPath",System.IO.Path.Combine(root,"Recovery Engine.ps1"));
    runspace.SessionStateProxy.SetVariable("SystemPath",System.IO.Path.Combine(root,"System Engine.ps1"));
    runspace.SessionStateProxy.SetVariable("InstallerPath",System.IO.Path.Combine(root,"Installer Engine.ps1"));
    runspace.SessionStateProxy.SetVariable("DnsPath",System.IO.Path.Combine(root,"DNS Engine.ps1"));
    runspace.SessionStateProxy.SetVariable("ProfilePath",System.IO.Path.Combine(root,"Profile Engine.ps1"));
    runspace.SessionStateProxy.SetVariable("PotatoPath",System.IO.Path.Combine(root,"Fortnite Profile.ps1"));
    runspace.SessionStateProxy.SetVariable("PeripheralPath",System.IO.Path.Combine(root,"Peripheral Engine.ps1"));
    runspace.SessionStateProxy.SetVariable("ResetPath",System.IO.Path.Combine(root,"Reset Engine.ps1"));
    runspace.SessionStateProxy.SetVariable("RegistryReviewPath",System.IO.Path.Combine(root,"Registry Review.ps1"));
    if(variables!=null) foreach(var pair in variables) runspace.SessionStateProxy.SetVariable(pair.Key,pair.Value);
    using(var ps=PowerShell.Create()) {
     ps.Runspace=runspace;
     ps.AddScript(@"
$ErrorActionPreference='Stop'
. $UtilityPath -LibraryOnly
. $ControlPath
. $NetworkPath
. $GamePath
. $RecoveryPath
. $SystemPath
. $InstallerPath
. $DnsPath
. $ProfilePath
. $PotatoPath
. $PeripheralPath
. $ResetPath
. $RegistryReviewPath
function Read-Host { param([string]$Prompt) $Ui.Prompt($Prompt) }
function Confirm-Action { param([string]$Message,[string]$Word) $Ui.Confirm($Message,$Word) }
function Select-State { param([string]$Kind) $Ui.Backup($Kind) }
function Write-Host {
 param([Parameter(Position=0,ValueFromRemainingArguments=$true)][object[]]$Object,[object]$ForegroundColor,[switch]$NoNewline)
 $Ui.Log(($Object -join ' '))
}
function Out-Host {
 param([Parameter(ValueFromPipeline=$true)]$InputObject)
 begin { $buffer=New-Object 'Collections.Generic.List[object]' }
 process { $buffer.Add($InputObject) }
 end { $Ui.Log(($buffer | Out-String -Width 140).TrimEnd()) }
}
");
     ps.Invoke();
     if(ps.HadErrors) throw new InvalidOperationException(String.Join("\n",ps.Streams.Error.Select(e=>e.ToString())));
     ps.Commands.Clear();
     ps.AddScript(command);
     var result=ps.Invoke();
     foreach(var w in ps.Streams.Warning) bridge.Log("Notice: "+w.Message);
     if(ps.HadErrors) throw new InvalidOperationException(String.Join("\n",ps.Streams.Error.Select(e=>e.ToString())));
     return result;
    }
   }
  }
 }

 public sealed partial class Dashboard : Window {
  readonly string root=AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
  readonly Brush ink=Brushes.White;
  readonly Brush muted=Hex("#A2ABC1"), accent=Hex("#B69AFF"), surface=Hex("#141A28"), line=Hex("#263047");
  readonly Dictionary<string,StackPanel> pages=new Dictionary<string,StackPanel>();
  readonly Dictionary<string,Button> nav=new Dictionary<string,Button>();
  readonly List<double> cpuSamples=new List<double>();

  readonly DispatcherTimer monitor=new DispatcherTimer();
  readonly bool admin=new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);
  TextBlock heading,subtitle,status,cpuValue,ramValue,ramDetail,gpuTitle,gpuDetail,heroCpu,heroGpu,powerValue,backupValue,timerStatus;
  TextBox activity;
  StackPanel backupsList;
  ContentControl content;
  Canvas chart;
  System.Windows.Shapes.Path ramArc;

  ProgressBar progress;
  bool busy,loadedApps,closed;
  readonly bool readOnlyPreview;
  [DllImport("user32.dll")] static extern uint GetDpiForSystem();
  string currentPage="Dashboard";
  ulong priorIdle,priorKernel,priorUser;
  public Dashboard(bool secondaryMonitor=false,bool preview=false) {
   readOnlyPreview=preview;Title="KKxtti debloat utility 3.3.0"+(preview?" — read-only preview":"");
   var area=SystemParameters.WorkArea;
   if(secondaryMonitor){var screen=System.Windows.Forms.Screen.AllScreens.First(s=>!s.Primary);var pixels=screen.WorkingArea;double scale=GetDpiForSystem()/96.0;area=new Rect(pixels.Left/scale,pixels.Top/scale,pixels.Width/scale,pixels.Height/scale);}
   Width=Math.Min(1280,area.Width-24); Height=Math.Min(850,area.Height-24); MinWidth=Math.Min(1060,Width); MinHeight=Math.Min(720,Height);
   WindowStartupLocation=WindowStartupLocation.Manual; Left=area.Left+(area.Width-Width)/2; Top=area.Top+(area.Height-Height)/2;
   WindowStyle=WindowStyle.None; ResizeMode=ResizeMode.CanResize;
   Background=Hex("#0C101B"); Foreground=ink; FontFamily=new FontFamily("Segoe UI"); FontSize=13;
   var chrome=new System.Windows.Shell.WindowChrome {CaptionHeight=0,ResizeBorderThickness=new Thickness(6),CornerRadius=new CornerRadius(12),GlassFrameThickness=new Thickness(0)};
   System.Windows.Shell.WindowChrome.SetWindowChrome(this,chrome);
   Resources=(ResourceDictionary)XamlReader.Parse(Styles);
   BuildShell(); BuildDashboard(); BuildPerformance(); BuildTimers(); BuildGames(); BuildDebloat(); BuildNetwork(); BuildBenchmarks(); BuildSystemTools(); BuildInstallers(); BuildBackups(); BuildActivity();
   Navigate("Dashboard");
   Loaded+=(s,e)=> { RefreshHardware(); StartPeripheralDetection(); TickMonitor(); monitor.Start(); };
   monitor.Interval=TimeSpan.FromSeconds(2); monitor.Tick+=(s,e)=> { TickPeripherals();if(WindowState!=WindowState.Minimized) TickMonitor(); };
   Closing+=(s,e)=> { if(busy) { e.Cancel=true; MessageBox.Show(this,"Wait for the current operation to finish before closing.","Operation in progress"); } };
   Closed+=(s,e)=> {closed=true; monitor.Stop();StopPeripheralDetection();};
  }
  static Brush Hex(string color) {return (Brush)new BrushConverter().ConvertFromString(color);}
  TextBlock Text(string value,double size=13,string color=null,bool bold=false) {
   return new TextBlock {Text=value,FontSize=size,Foreground=color==null?ink:Hex(color),FontWeight=bold?FontWeights.SemiBold:FontWeights.Normal,TextWrapping=TextWrapping.Wrap};
  }
  StackPanel Stack(params UIElement[] children) { var p=new StackPanel(); foreach(var c in children)p.Children.Add(c); return p; }
  UIElement Gap(double height=12) { return new Border {Height=height}; }
  Border Card(UIElement body,double padding=22) {return new Border {Background=surface,BorderBrush=line,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(12),Padding=new Thickness(padding),Child=body};}
  Grid Columns(UIElement[] children,params double[] weights) {
   var grid=new Grid();
   for(int i=0;i<children.Length;i++) {
    grid.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(weights.Length>i?weights[i]:1,GridUnitType.Star)});
    var holder=new Border{Child=children[i],Margin=new Thickness(i==0?0:7,0,i==children.Length-1?0:7,0)};
    Grid.SetColumn(holder,i);grid.Children.Add(holder);
   }
   return grid;
  }
  WrapPanel Buttons(params Button[] buttons) { var p=new WrapPanel {Margin=new Thickness(0,16,0,0)}; foreach(var b in buttons){b.Margin=new Thickness(0,0,8,6);p.Children.Add(b);}return p; }
  Button Btn(string label,Action action,bool primary=false) {
   var b=new Button {Content=label,Style=(Style)Resources[primary?"PrimaryButton":"Button"],Padding=new Thickness(16,10,16,10),Cursor=Cursors.Hand};
   AutomationProperties.SetName(b,label); b.Click+=(s,e)=>action(); return b;
  }
  Border Pill(string label,string foreground="#BBA4FF",string background="#29213F") {
   return new Border {Background=Hex(background),CornerRadius=new CornerRadius(5),Padding=new Thickness(9,4,9,4),HorizontalAlignment=HorizontalAlignment.Left,Child=Text(label,10,foreground,true)};
  }
  StackPanel Page(string name) {var p=new StackPanel();pages.Add(name,p);return p;}
  TextBlock Label(string value) {return Text(value,10,"#96A0B8",true);}
  Border InfoCard(string title,string description,string badge,params Button[] buttons) {
   return Card(Stack(Pill(badge),Gap(),Text(title,19,null,true),Gap(8),Text(description,13,"#A2ABC1"),Buttons(buttons)));
  }
  void BuildShell() {
   var outer=new Grid();outer.RowDefinitions.Add(new RowDefinition{Height=new GridLength(44)});outer.RowDefinitions.Add(new RowDefinition());
   var titlebar=new Grid {Background=Hex("#0C101B")};titlebar.ColumnDefinitions.Add(new ColumnDefinition());titlebar.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});
   var caption=Text("KKXTTI  /  DEBLOAT UTILITY 3.3.0",10,"#8691AB",true);caption.Margin=new Thickness(23,14,0,0);titlebar.Children.Add(caption);
   titlebar.MouseLeftButtonDown+=(s,e)=> {if(e.ClickCount==2)WindowState=WindowState==WindowState.Maximized?WindowState.Normal:WindowState.Maximized;else DragMove();};
   var windowButtons=new StackPanel{Orientation=Orientation.Horizontal};
   var min=Btn("\u2014",()=>WindowState=WindowState.Minimized); min.Width=44;min.ToolTip="Minimize";AutomationProperties.SetName(min,"Minimize");
   var max=Btn("\u25a1",()=>WindowState=WindowState==WindowState.Maximized?WindowState.Normal:WindowState.Maximized);max.Width=44;AutomationProperties.SetName(max,"Maximize or restore");
   var close=Btn("\u00d7",()=>Close());close.Width=44;AutomationProperties.SetName(close,"Close KKxtti");
   foreach(var b in new[]{min,max,close}){b.Style=(Style)Resources["CaptionButton"];windowButtons.Children.Add(b);}Grid.SetColumn(windowButtons,1);titlebar.Children.Add(windowButtons);outer.Children.Add(titlebar);
   var body=new Grid();body.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(208)});body.ColumnDefinitions.Add(new ColumnDefinition());Grid.SetRow(body,1);outer.Children.Add(body);
   var side=new DockPanel{Background=Hex("#101522"),Margin=new Thickness(0)};
   var brand=Stack(Text("K /",35,"#B69AFF",true),Gap(7),Text("KKxtti",23,null,true),Text("DEBLOAT UTILITY",10,"#7F8CA8",true),Gap(28));brand.Margin=new Thickness(24,15,18,0);DockPanel.SetDock(brand,Dock.Top);side.Children.Add(brand);
   var foot=Stack(Pill("PURPLE EDITION"),Gap(12),Text("Your settings. Your call.",11,"#8F9BB5"),Gap(),Btn(admin?"Administrator access":"Run as administrator",()=>Elevate()),Gap(6),Btn("Read the guide",()=>OpenLocal("GAMING GUIDE.txt")));
   foot.Margin=new Thickness(18,12,18,20);DockPanel.SetDock(foot,Dock.Bottom);side.Children.Add(foot);
   var navigation=new StackPanel {Margin=new Thickness(12,0,12,0)};
   string[] names={"Dashboard","Performance","Timers & input","Games","Network","Benchmarks","Debloat","System tools","App installer","Backups","Activity"};
   string[] glyphs={"\uE80F","\uE9D9","\uE916","\uE7FC","\uE968","\uE9D2","\uE74D","\uE713","\uE896","\uE8F1","\uE9D5"};
   for(int i=0;i<names.Length;i++) {
    string name=names[i];var panel=new StackPanel{Orientation=Orientation.Horizontal};
    panel.Children.Add(new TextBlock{Text=glyphs[i],FontFamily=new FontFamily("Segoe MDL2 Assets"),FontSize=16,Width=30,VerticalAlignment=VerticalAlignment.Center});
    panel.Children.Add(Text(name,13,null,false));
    var b=Btn(name,()=>Navigate(name));b.Content=panel;b.HorizontalContentAlignment=HorizontalAlignment.Left;b.Margin=new Thickness(0,0,0,5);b.Padding=new Thickness(14,12,10,12);
    b.BorderThickness=new Thickness(0);nav.Add(name,b);navigation.Children.Add(b);
   }
   side.Children.Add(new ScrollViewer{Content=navigation,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled});body.Children.Add(side);
   var main=new Grid {Margin=new Thickness(30,14,30,18)};main.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});main.RowDefinitions.Add(new RowDefinition());main.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});Grid.SetColumn(main,1);body.Children.Add(main);
   heading=Text("",27,null,true);subtitle=Text("",12,"#8F9BB5");
   var head=new DockPanel{Margin=new Thickness(0,0,0,23)};
   var refresh=Btn("Refresh system",()=>RefreshHardware());refresh.VerticalAlignment=VerticalAlignment.Center;DockPanel.SetDock(refresh,Dock.Right);head.Children.Add(refresh);
   head.Children.Add(Stack(heading,Gap(5),subtitle));main.Children.Add(head);
   content=new ContentControl {HorizontalContentAlignment=HorizontalAlignment.Stretch};
   var scroll=new ScrollViewer{Content=content,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled,Padding=new Thickness(0,0,6,0)};Grid.SetRow(scroll,1);main.Children.Add(scroll);
   progress=new ProgressBar {Height=2,IsIndeterminate=true,Foreground=accent,Background=Hex("#20283A"),Visibility=Visibility.Collapsed,Margin=new Thickness(0,0,0,8)};
   status=Text("Ready",11,"#8F9BB5");var bottom=Stack(progress,status);bottom.Margin=new Thickness(0,13,0,0);Grid.SetRow(bottom,2);main.Children.Add(bottom);
   Content=new Border{BorderBrush=Hex("#283147"),BorderThickness=new Thickness(1),Child=outer};
  }
  void BuildDashboard() {
   var page=Page("Dashboard");
   heroCpu=Text("Detecting processor...",12,"#D7C9FF");heroGpu=Text("Detecting graphics...",12,"#D7C9FF");
   var heroLeft=Stack(Label("YOUR COMPETITIVE SETUP"),Gap(12),Text("Ready for your next match.",29,null,true),Gap(9),Text("A clear view of your hardware, settings and next steps.",13,"#C4BED7"),Gap(20),heroCpu,Gap(4),heroGpu);
   peripheralHero=Text("Detecting connected devices...",19,null,true);peripheralSummary=Text("Reading Windows input interfaces",11,"#C6B6E5");
   var heroRight=Stack(Pill("LIVE PERIPHERALS"),Gap(14),peripheralHero,Gap(9),peripheralSummary,Gap(10),Text("Polling rate: check device software",11,"#A89DBC"),Buttons(Btn("View devices",()=>Navigate("Timers & input"))));
   var hero=Card(Columns(new UIElement[]{heroLeft,heroRight},2.8,1),25);hero.Background=new LinearGradientBrush(Color.FromRgb(43,30,67),Color.FromRgb(22,24,40),0);hero.BorderBrush=Hex("#43305F");page.Children.Add(hero);page.Children.Add(Gap(18));
   cpuValue=Text("--",29,null,true);chart=new Canvas {Height=75,ClipToBounds=true,Margin=new Thickness(0,14,0,0)};chart.SizeChanged+=(s,e)=>DrawChart();
   var cpuHead=new DockPanel();var live=Pill("LIVE","#8DE1CA","#16352F");DockPanel.SetDock(live,Dock.Right);cpuHead.Children.Add(live);cpuHead.Children.Add(Label("CPU UTILIZATION"));
   var cpu=Card(Stack(cpuHead,Gap(8),cpuValue,chart,Text("Last 90 seconds  /  updates every 2s",10,"#77849E")));
   ramValue=Text("--",23,null,true);ramValue.TextAlignment=TextAlignment.Center;ramDetail=Text("Reading memory...",11,"#8F9BB5");
   var ring=new Grid {Height=100,Width=100,HorizontalAlignment=HorizontalAlignment.Center,Margin=new Thickness(0,10,0,9)};
   ring.Children.Add(new Ellipse{Stroke=Hex("#2A3047"),StrokeThickness=8,Margin=new Thickness(5)});
   ramArc=new System.Windows.Shapes.Path{Stroke=accent,StrokeThickness=8,StrokeStartLineCap=PenLineCap.Round,StrokeEndLineCap=PenLineCap.Round};ring.Children.Add(ramArc);ramValue.VerticalAlignment=VerticalAlignment.Center;ring.Children.Add(ramValue);
   var ram=Card(Stack(Label("MEMORY IN USE"),ring,ramDetail));
   gpuTitle=Text("Detecting GPU",18,null,true);gpuDetail=Text("Detecting display",12,"#A2ABC1");
   var gpu=Card(Stack(Label("GRAPHICS & DISPLAY"),Gap(20),gpuTitle,Gap(13),gpuDetail,Gap(16),Pill("PER-GAME TUNING")));
   page.Children.Add(Columns(new UIElement[]{cpu,ram,gpu},1.7,1,1.25));page.Children.Add(Gap(23));
   page.Children.Add(Text("Make your next change count",18,null,true));page.Children.Add(Gap(13));
   powerValue=Text("Reading active plan...",12,"#A2ABC1");backupValue=Text("No saved changes yet",12,"#A2ABC1");
   var power=Card(Stack(Label("01  /  PERFORMANCE"),Gap(9),Text("Switches & presets",16,null,true),Gap(8),powerValue,Buttons(Btn("Open switches",()=>Navigate("Performance"),true))));
   var timers=Card(Stack(Label("02  /  TIMERS & INPUT"),Gap(9),Text("Start with automatic timers",16,null,true),Gap(8),Text("Start from Windows defaults.",12,"#A2ABC1"),Buttons(Btn("View recommendation",()=>Navigate("Timers & input")))));
   var backups=Card(Stack(Label("03  /  RECOVERY"),Gap(9),Text("Keep a way back",16,null,true),Gap(8),backupValue,Buttons(Btn("Open backups",()=>Navigate("Backups")))));
   page.Children.Add(Columns(new UIElement[]{power,timers,backups}));
  }
  void BuildPerformance() { BuildSwitchboard(); }
  void BuildTimers() {
   var page=Page("Timers & input");
   var intro=InfoCard("Automatic timing is the recommended baseline","On Windows 11, let Windows and each game choose timer behavior. A blanket 0.5 ms request is not a proven latency improvement. Your mouse polling interval is a separate measurement.","BASELINE TO COMPARE",Btn("Why this recommendation?",()=>ShowTimerGuide()),Btn("Microsoft timer documentation",()=>OpenUri("https://learn.microsoft.com/en-us/windows/win32/api/timeapi/nf-timeapi-timebeginperiod")));
   intro.BorderBrush=Hex("#594377");page.Children.Add(intro);page.Children.Add(Gap(16));
   timerStatus=Text("Boot overrides have not been inspected. Administrator access is required.",13,"#A2ABC1");
   page.Children.Add(Card(Stack(Label("BOOT TIMER CONFIGURATION"),Gap(10),timerStatus,Gap(12),Text("Checks useplatformclock, useplatformtick, disabledynamictick and numproc. Restore removes those overrides after a backup; it does not disable security features. Encrypted OS volumes block automatic changes.",12,"#8F9BB5"),Buttons(Btn("Inspect timers",()=>InspectTimers(),true),Btn("Restore automatic timers",()=>Action("Restore automatic timers","Reset-BootOverrides",true)),Btn("Undo timer change",()=>Action("Restore saved boot settings","Undo-Boot",true))))));
   page.Children.Add(Gap(16));
   BuildPeripheralCards(page);
  }
  void BuildDebloat() { BuildAppManager(); }
  void BuildBackups() {
   var page=Page("Backups");
   page.Children.Add(InfoCard("Restore points & Reset","Create a Windows restore point before experimenting. Reset saved tweaks restores reversible changes from this release, newest first; a conflict stops the reset. Restore legacy boot/power snapshots individually below. Removed apps/files and changes from older release folders need their own recovery.","RECOVERY CENTER",Btn("Create restore point",()=>Action("Create Windows restore point","New-ReviewedRestorePoint",true),true),Btn("Reset saved tweaks",()=>Action("Reset saved KKxtti tweaks","Reset-KKxttiSavedSettings",true)),Btn("System Protection",()=>OpenUri(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"System32","SystemPropertiesProtection.exe")))));page.Children.Add(Gap(16));
   page.Children.Add(InfoCard("Back up before experimenting","Switches and presets save your exact previous preferences. Power changes save the active plan. Timer changes export BCD. App removal and temp deletion cannot be undone here.","RECOVERY",Btn("Export boot backup",()=>Action("Export boot configuration","$b=Backup-Boot; $b.State.Values | Format-List | Out-Host; Write-Host ('Backup: '+$b.Directory)",true)),Btn("Export NVIDIA driver",()=>Action("Export NVIDIA driver","Export-DisplayDrivers",true)),Btn("Open saved files",()=>OpenState())));
   page.Children.Add(Gap(20));page.Children.Add(Text("Saved changes",18,null,true));page.Children.Add(Gap(12));backupsList=new StackPanel();page.Children.Add(backupsList);
  }
  void BuildActivity() {
   var page=Page("Activity");
   page.Children.Add(Text("Your activity this session",20,null,true));page.Children.Add(Gap(9));page.Children.Add(Text("Completed actions, cancellations and errors appear here. Save a copy before closing if you need it later.",13,"#A2ABC1"));page.Children.Add(Gap(16));
   activity=new TextBox{IsReadOnly=true,TextWrapping=TextWrapping.Wrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Height=430,FontFamily=new FontFamily("Consolas"),FontSize=12,Padding=new Thickness(16),AcceptsReturn=true};AutomationProperties.SetName(activity,"Activity log");page.Children.Add(activity);
   page.Children.Add(Buttons(Btn("Save activity log",()=>SaveActivity()),Btn("Read asset audit",()=>OpenLocal("ASSET AUDIT.txt")),Btn("Read verification",()=>OpenLocal("VERIFICATION.txt"))));
  }
  void Navigate(string name) {
   currentPage=name; content.Content=pages[name];heading.Text=name=="Dashboard"?"Your performance dashboard":name;
   var subtitles=new Dictionary<string,string>{
    {"Dashboard","Welcome back. A little clarity before your next session."},{"Performance","Focused controls, with room to compare and roll back."},
    {"Timers & input","Windows timing, mouse polling and keyboard response."},{"Games","Working game controls and profiles for Fortnite and Rainbow Six Siege."},
    {"Benchmarks","Compare frame-time captures before keeping a tweak."},{"Network","Measure your connection and compare reversible adapter settings."},{"Debloat","Less clutter. You choose what goes."},{"System tools","Reviewed actions, compatibility and the full screenshot checklist."},{"App installer","Choose your apps and inspect their download sources."},{"Backups","Review saved states and restore an earlier change."},{"Activity","A clear record of what happened."}};
   subtitle.Text=subtitles[name];
   foreach(var pair in nav){pair.Value.Background=pair.Key==name?Hex("#2B2340"):Brushes.Transparent;pair.Value.Foreground=pair.Key==name?accent:muted;}
   if(name=="Backups") RefreshBackups();
   if(name=="Debloat"&&!loadedApps&&!busy) LoadManagedApps();
   if(name=="Performance"&&!controlsLoaded&&!busy) LoadControls();
   if(name=="App installer"&&!installersLoaded&&!busy) LoadInstallers();
   if(name=="System tools"&&!systemLoaded&&!busy) LoadSystemControls();
   if(name=="Network"&&!networkLoaded&&!busy) LoadNetwork();
   if(name=="Games"&&!gameLoaded&&!busy) LoadGames();
  }
  public void Log(string text) { if(closed)return;activity.AppendText("["+DateTime.Now.ToString("HH:mm:ss")+"] "+text+Environment.NewLine);activity.ScrollToEnd(); }
  bool RequireAdmin() {if(admin)return true;Notice("Administrator access needed","Use 'Run as administrator' in the sidebar, then choose this action again. Restarting the dashboard does not automatically apply it.");return false;}
  void SetBusy(bool value,string label) {busy=value;progress.Visibility=value?Visibility.Visible:Visibility.Collapsed;status.Text=label;status.Foreground=muted;if(networkAdapter!=null)networkAdapter.IsEnabled=!value;if(gameProfile!=null)gameProfile.IsEnabled=!value;}
  async void Work(string label,string command,Action<Collection<PSObject>> done=null,ActionBridge bridge=null,Dictionary<string,object> variables=null) {
   if(readOnlyPreview&&!PreviewAllows(command)){Notice("Read-only preview","Settings changes are disabled in this testing session.");return;}
   if(busy){Notice("An operation is running","Wait for it to finish before starting another action.");return;}
   var context=bridge??new ActionBridge(this);SetBusy(true,label+"...");Log(label+" started.");
   try {
    var result=await Task.Run(()=>Backend.Run(root,command,context,variables));
    if(done!=null)done(result);
    string outcome=context.Cancelled?"Cancelled": "Finished";
    Log(label+": "+outcome.ToLowerInvariant()+".");SetBusy(false,label+" / "+outcome);
    RefreshBackupCount(); if(currentPage=="Backups")RefreshBackups();
   } catch(Exception ex) {SetBusy(false,label+" / Could not complete");status.Foreground=Hex("#FFABA8");Log("ERROR: "+ex.Message);Notice("Could not complete this action",ex.Message);}
  }
  void Action(string label,string command,bool needsAdmin=false,string answer="") {
   if(needsAdmin&&!RequireAdmin())return;
   var bridge=new ActionBridge(this){Answer=answer};
   Work(label,command,result=> {if(command.Contains("Power"))RefreshPowerLabel();},bridge);
  }
  void RefreshPowerLabel() {
   // Refresh after the action completes, without overlapping the action worker.
   Dispatcher.BeginInvoke(new Action(()=> {
    if(busy||closed)return;
    Work("Refresh active plan","Invoke-Native 'powercfg.exe' @('/getactivescheme')",r=> {if(r.Count>0)powerValue.Text=PowerName(r[0].ToString());});
   }),DispatcherPriority.Background);
  }
  static string Value(PSObject item,string name,string fallback="Unavailable") {
   var p=item.Properties[name];return p!=null&&p.Value!=null&&!String.IsNullOrWhiteSpace(p.Value.ToString())?p.Value.ToString():fallback;
  }
  static string PowerName(string text) {int n=text.IndexOf('('),end=text.LastIndexOf(')');return n>=0&&end>n?text.Substring(n+1,end-n-1):text.Trim();}
  void RefreshHardware() {
   peripheralDirty=true;
   Work("Read system information",@"
$cpu=Get-CimInstance Win32_Processor | Select-Object -First 1
$gpu=Get-CimInstance Win32_VideoController | Where-Object Name -match 'NVIDIA' | Select-Object -First 1
if(-not $gpu){$gpu=Get-CimInstance Win32_VideoController | Select-Object -First 1}
$os=Get-CimInstance Win32_OperatingSystem
[pscustomobject]@{Cpu=$cpu.Name.Trim();Gpu=$gpu.Name;Display=('{0} x {1}  /  {2} Hz' -f $gpu.CurrentHorizontalResolution,$gpu.CurrentVerticalResolution,$gpu.CurrentRefreshRate);Power=(Invoke-Native 'powercfg.exe' @('/getactivescheme'));OS=$os.Caption}
",r=> {
    if(r.Count==0)throw new InvalidOperationException("Windows returned no system information.");
    heroCpu.Text=Value(r[0],"Cpu").Replace("AMD Ryzen 7 ","RYZEN 7 ").Replace(" 8-Core Processor","");
    heroGpu.Text=Value(r[0],"Gpu").Replace("NVIDIA GeForce ","");
    gpuTitle.Text=Value(r[0],"Gpu").Replace("NVIDIA GeForce ","");gpuDetail.Text=Value(r[0],"Display");powerValue.Text=PowerName(Value(r[0],"Power"));
   });
  }
  void InspectTimers() {
   if(!RequireAdmin())return;
   Work("Inspect boot timers","Get-BootState",r=> {
    if(r.Count==0)return;var values=PSObject.AsPSObject(r[0].Properties["Values"].Value);var lines=new List<string>();
    foreach(string key in new[]{"useplatformclock","useplatformtick","disabledynamictick","numproc"})lines.Add(key+"   /   "+Value(values,key,"Automatic (no override)"));
    timerStatus.Text=String.Join("\n\n",lines);Log(timerStatus.Text);
   });
  }
  static string FriendlyName(string name) {
   var map=new Dictionary<string,string>{
    {"Clipchamp.Clipchamp","Clipchamp"},{"Microsoft.BingNews","Microsoft News"},{"Microsoft.BingWeather","Weather"},{"Microsoft.GetHelp","Get Help"},{"Microsoft.Getstarted","Windows Tips"},
    {"Microsoft.MicrosoftSolitaireCollection","Solitaire Collection"},{"Microsoft.MicrosoftOfficeHub","Microsoft 365 hub"},{"Microsoft.People","People"},{"Microsoft.SkypeApp","Skype"},
    {"Microsoft.WindowsFeedbackHub","Feedback Hub"},{"Microsoft.WindowsMaps","Windows Maps"},{"Microsoft.YourPhone","Phone Link"},{"Microsoft.ZuneMusic","Media Player"},{"Microsoft.ZuneVideo","Movies & TV"},
    {"Microsoft.Microsoft3DViewer","3D Viewer"},{"Microsoft.MixedReality.Portal","Mixed Reality Portal"},{"Microsoft.PowerAutomateDesktop","Power Automate"},{"Microsoft.WindowsAlarms","Windows Clock"},
    {"Microsoft.WindowsSoundRecorder","Sound Recorder"},{"Microsoft.XboxGamingOverlay","Xbox Game Bar"}};
   return map.ContainsKey(name)?map[name]:name;
  }
  DirectoryInfo[] SavedFolders() {
   string state=System.IO.Path.Combine(root,"State");return Directory.Exists(state)?new DirectoryInfo(state).GetDirectories().OrderByDescending(d=>d.Name).ToArray():new DirectoryInfo[0];
  }
  void RestoreFolder(string path,string kind) {if(kind=="boot"&&!RequireAdmin())return;var bridge=new ActionBridge(this){BackupPath=path};Work("Restore "+kind+" backup",kind=="boot"?"Undo-Boot":"Undo-Power",null,bridge);}
  public string ChooseBackup(string kind) {
   var dirs=SavedFolders().Where(d=>d.Name.StartsWith(kind+"-")&&(File.Exists(System.IO.Path.Combine(d.FullName,"before.json")) || File.Exists(System.IO.Path.Combine(d.FullName,"transaction.json")))).ToArray();
   if(dirs.Length==0){Notice("No saved state yet","There is no "+kind+" backup to restore. Apply a change or export a backup first.");return null;}
   string answer=null;var panel=Stack(Text("Choose a saved state",22,null,true),Gap(9),Text("The exact values will be reviewed before anything changes.",13,"#A2ABC1"),Gap(18));
   var dialog=Dialog(panel,650);
   foreach(var dir in dirs){var b=Btn(dir.Name,()=>{answer=dir.FullName;dialog.DialogResult=true;});b.Margin=new Thickness(0,0,0,7);panel.Children.Add(b);}
   panel.Children.Add(Buttons(Btn("Cancel",()=>dialog.Close())));dialog.ShowDialog();return answer;
  }
  Window Dialog(UIElement body,double width=670) {
   var dialog=new Window {Owner=this,Title="KKxtti / Review",Width=width,SizeToContent=SizeToContent.Height,MaxHeight=SystemParameters.WorkArea.Height-50,WindowStartupLocation=WindowStartupLocation.CenterOwner,WindowStyle=WindowStyle.None,ResizeMode=ResizeMode.NoResize,Background=Hex("#141A28"),Foreground=ink,FontFamily=FontFamily,FontSize=13,ShowInTaskbar=false};
   dialog.Resources=Resources;var scroll=new ScrollViewer {Content=body,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,MaxHeight=Math.Max(460,SystemParameters.WorkArea.Height-130)};
   dialog.Content=new Border {Child=scroll,Padding=new Thickness(28),BorderThickness=new Thickness(1),BorderBrush=Hex("#645080"),CornerRadius=new CornerRadius(10)};
   dialog.PreviewKeyDown+=(s,e)=>{if(e.Key==Key.Escape){dialog.Close();e.Handled=true;}};
   return dialog;
  }
  void Notice(string title,string message) {
   var panel=Stack(Pill("KKXTTI DEBLOAT UTILITY"),Gap(17),Text(title,23,null,true),Gap(14),Text(message,14,"#BCC5DA"),Gap(12));var dialog=Dialog(panel);var close=Btn("Got it",()=>dialog.Close(),true);close.IsDefault=true;panel.Children.Add(Buttons(close));dialog.ShowDialog();
  }
  public bool ConfirmOperation(string message,string word,string preview) {
   var panel=Stack(Pill("REVIEW BEFORE APPLYING"),Gap(16),Text("Confirm this action",24,null,true),Gap(13),Text(message,14,"#C3CCDF"));
   if(!String.IsNullOrWhiteSpace(preview)) {
    panel.Children.Add(Gap(16));panel.Children.Add(Label("PREVIEW / CURRENT VALUES"));panel.Children.Add(Gap(7));
    var box=new TextBox{Text=preview,IsReadOnly=true,TextWrapping=TextWrapping.Wrap,MaxHeight=170,MinHeight=70,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,FontFamily=new FontFamily("Consolas"),FontSize=11,Padding=new Thickness(10)};
    AutomationProperties.SetName(box,"Action preview");panel.Children.Add(box);
   }
   panel.Children.Add(Gap(19));panel.Children.Add(Text("Type "+word+" to continue",12,"#B69AFF",true));panel.Children.Add(Gap(8));
   var input=new TextBox{Height=40,Padding=new Thickness(10),FontSize=14};AutomationProperties.SetName(input,"Confirmation word");panel.Children.Add(input);
   var dialog=Dialog(panel);bool confirmed=false;
   var apply=Btn("Confirm action",()=>{confirmed=true;dialog.DialogResult=true;},true);apply.IsEnabled=false;apply.IsDefault=true;
   input.TextChanged+=(s,e)=>apply.IsEnabled=input.Text==word;
   var cancel=Btn("Cancel",()=>dialog.Close());panel.Children.Add(Buttons(apply,cancel));dialog.Loaded+=(s,e)=>input.Focus();dialog.ShowDialog();return confirmed;
  }
  void ShowTimerGuide() {Notice("A timer is not your mouse polling rate","Microsoft documents process-specific timer behavior on modern Windows. A request in a timer utility is not proof of lower game latency. Finer resolution also has scheduling and power costs.\n\nFor this PC, use automatic timing as the baseline. Inspect the four boot overrides, then back up and restore defaults only if needed. Compare the same game scenes before keeping a change.\n\nMouse reporting rate is separate from Windows timers; review it in the device software. No fixed resolution has been benchmarked as best on this system.\n\nSource: Microsoft timeBeginPeriod documentation, linked on this page.");}
  void ShowInputGuide(bool keyboard) {
   if(keyboard)Notice("Apex Pro TKL 2023","Use SteelSeries GG / Engine to review firmware and per-key actuation. Rapid Trigger is supported on your 2023 model.\n\nTry Rapid Trigger on movement keys first. A 0.4-1.0 mm initial actuation is a starting experiment, not a measured optimum; raise it if resting fingers cause accidental inputs. Keep a more deliberate actuation on utility keys.\n\nRapid Trigger is distinct from Rapid Tap / SOCD automation. Check your game's current competitive rules before enabling input automation. This utility does not program macros or change keyboard firmware.\n\nSource: SteelSeries 'What is Rapid Trigger?' support article. The full notes include links.");
   else Notice("G Pro X Superlight 2","Keep 2000 Hz as your baseline. Compare 1000 Hz only if repeated fast swipes worsen frame times. Test higher polling separately if you want to explore it; a larger number is not automatically the best result.\n\n2000 Hz means a nominal 0.5 ms reporting interval. It does not mean 0.5 ms total input delay, and it does not require forcing Windows timer resolution to 0.5 ms.\n\nUse Logitech G HUB to review the selected report rate and official firmware. Keep a comfortable DPI and adjust in-game sensitivity to preserve your preferred cm/360. This dashboard does not change device firmware or polling.\n\nSource: Logitech's PRO X SUPERLIGHT 2 product documentation.");
  }
  void ShowGame(bool siege) {
   Notice(siege?"Rainbow Six Siege / starting profile":"Fortnite / starting profile",siege?
    "1080p native. V-Sync off for your chosen adaptive-sync-off setup.\n\nUse the current supported renderer. Try Reflex if exposed by the current build, then compare Boost separately. Reduce expensive effects while preserving useful player shadows and visibility.\n\nCompare unlimited with sustainable caps in demanding scenes. Keep Secure Boot, TPM and Core Isolation needed for Shieldguard's relevant competitive modes.\n\nNo profile is silently applied. Read the full guide for sources, test method and rollback planning.":
    "Performance rendering (DX12 in the current Epic guide). Fullscreen, native 1080p, 100% 3D resolution, low textures/meshes and Near view distance.\n\nStart with Reflex On + Boost. Compare On separately if sustained heat or clock behavior warrants it.\n\nWarm shaders first. Compare unlimited with caps such as 240 / 300 / 360 only where your demanding scenes can sustain them. Do not choose 237 just because the monitor is 240 Hz with adaptive sync off.\n\nNo profile is silently applied. Read the full guide for Epic/NVIDIA sources and the benchmark method.");
  }
  void OpenUri(string target) {try{Process.Start(new ProcessStartInfo(target){UseShellExecute=true});Log("Opened: "+target);}catch(Exception ex){Notice("Could not open",ex.Message);}}
  void OpenSystem(string name) {OpenUri(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),name));}
  void OpenLocal(string name) {string path=System.IO.Path.Combine(root,name);if(!File.Exists(path)){Notice("File missing",path);return;}OpenUri(path);}
  void OpenState() {string path=System.IO.Path.Combine(root,"State");Directory.CreateDirectory(path);OpenUri(path);}
  void SaveActivity() {string dir=System.IO.Path.Combine(root,"State","activity");Directory.CreateDirectory(dir);string path=System.IO.Path.Combine(dir,DateTime.Now.ToString("yyyyMMdd-HHmmss")+".txt");File.WriteAllText(path,activity.Text);status.Text="Activity saved: "+path;Log("Saved activity log.");}
  void OpenTrace() {
   if(!RequireAdmin())return;
   if(!ConfirmOperation("Opens an interactive console to record Defender scan activity. Reproduce the stutter, then return to that console and press Enter to stop. The trace stays local and can contain file paths. Protection settings are not changed.","RECORD",""))return;
   string path=System.IO.Path.Combine(root,"source","Record scan activity.ps1");
   try{Process.Start(new ProcessStartInfo(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"WindowsPowerShell\\v1.0\\powershell.exe"),"-NoProfile -ExecutionPolicy RemoteSigned -NoExit -File \""+path+"\""){UseShellExecute=true,WindowStyle=ProcessWindowStyle.Normal});Log("Opened interactive scan-activity recorder.");}catch(Exception ex){Notice("Could not start the recorder",ex.Message);}
  }
  void Elevate() {
   if(readOnlyPreview){Notice("Read-only preview","Administrator restart is disabled in this testing session.");return;}
   if(admin){Notice("Administrator access is active","Advanced actions are available. Switches apply directly and save undo. Batch presets and removals show a review first.");return;}
   if(busy){Notice("An operation is running","Wait for it to finish before restarting as administrator.");return;}
   try{Process.Start(new ProcessStartInfo(System.IO.Path.Combine(root,"KKxtti debloat utility.exe")){UseShellExecute=true,Verb="runas",WorkingDirectory=root});Close();}catch(System.ComponentModel.Win32Exception ex){if(ex.NativeErrorCode!=1223)Notice("Could not restart",ex.Message);}
  }
  [StructLayout(LayoutKind.Sequential)] struct MemoryStatus {public uint Length,Load;public ulong TotalPhys,AvailPhys,TotalPage,AvailPage,TotalVirtual,AvailVirtual,AvailExtended;}
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GlobalMemoryStatusEx(ref MemoryStatus value);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetSystemTimes(out ulong idle,out ulong kernel,out ulong user);
  void TickMonitor() {
   ulong idle,kernel,user;
   if(GetSystemTimes(out idle,out kernel,out user)) {
    if(priorKernel!=0) {ulong total=(kernel-priorKernel)+(user-priorUser);double cpu=total==0?0:100.0*(total-(idle-priorIdle))/total;cpu=Math.Max(0,Math.Min(100,cpu));cpuValue.Text=cpu.ToString("0")+"%";cpuSamples.Add(cpu);if(cpuSamples.Count>45)cpuSamples.RemoveAt(0);DrawChart();}
    priorIdle=idle;priorKernel=kernel;priorUser=user;
   } else cpuValue.Text="Unavailable";
   var memory=new MemoryStatus();memory.Length=(uint)Marshal.SizeOf(memory);
   if(GlobalMemoryStatusEx(ref memory)) {
    double used=100.0*(memory.TotalPhys-memory.AvailPhys)/memory.TotalPhys;ramValue.Text=used.ToString("0")+"%";
    ramDetail.Text=((memory.TotalPhys-memory.AvailPhys)/1073741824.0).ToString("0.0")+" / "+(memory.TotalPhys/1073741824.0).ToString("0.0")+" GB in use";
    double angle=Math.Min(99.9,Math.Max(.1,used))*Math.PI*2/100;
    var figure=new PathFigure{StartPoint=new Point(50,10)};figure.Segments.Add(new ArcSegment(new Point(50+40*Math.Sin(angle),50-40*Math.Cos(angle)),new Size(40,40),0,angle>Math.PI,SweepDirection.Clockwise,true));ramArc.Data=new PathGeometry(new[]{figure});
   } else {ramValue.Text="--";ramDetail.Text="Memory reading unavailable";}
  }
  void DrawChart() {
   if(chart==null)return;chart.Children.Clear();double w=chart.ActualWidth,h=chart.Height;
   if(w<1||cpuSamples.Count<2)return;
   for(int i=1;i<4;i++) chart.Children.Add(new Line{X1=0,X2=w,Y1=h*i/4,Y2=h*i/4,Stroke=Hex("#263047"),StrokeThickness=.7});
   var poly=new Polyline{Stroke=accent,StrokeThickness=2,StrokeLineJoin=PenLineJoin.Round};
   for(int i=0;i<cpuSamples.Count;i++)poly.Points.Add(new Point(w*i/44,h-5-cpuSamples[i]*(h-10)/100));
   var fill=new Polygon{Fill=new LinearGradientBrush(Color.FromArgb(50,182,154,255),Color.FromArgb(0,182,154,255),90)};
   fill.Points.Add(new Point(0,h));foreach(var point in poly.Points)fill.Points.Add(point);fill.Points.Add(new Point(poly.Points.Last().X,h));chart.Children.Add(fill);chart.Children.Add(poly);
   var dot=new Ellipse{Width=6,Height=6,Fill=accent};Canvas.SetLeft(dot,poly.Points.Last().X-3);Canvas.SetTop(dot,poly.Points.Last().Y-3);chart.Children.Add(dot);
  }
  const string Styles=@"
<ResourceDictionary xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
 <Style x:Key='Button' TargetType='Button'>
  <Setter Property='Background' Value='#222B40'/><Setter Property='Foreground' Value='#D8E0EF'/><Setter Property='BorderBrush' Value='#34405B'/><Setter Property='BorderThickness' Value='1'/><Setter Property='FontSize' Value='12'/><Setter Property='FontWeight' Value='SemiBold'/>
  <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='Button'><Border x:Name='Face' Background='{TemplateBinding Background}' BorderBrush='{TemplateBinding BorderBrush}' BorderThickness='{TemplateBinding BorderThickness}' CornerRadius='7' Padding='{TemplateBinding Padding}'><ContentPresenter HorizontalAlignment='{TemplateBinding HorizontalContentAlignment}' VerticalAlignment='Center'/></Border><ControlTemplate.Triggers><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='Face' Property='BorderBrush' Value='#B69AFF'/><Setter TargetName='Face' Property='Opacity' Value='0.85'/></Trigger><Trigger Property='IsKeyboardFocused' Value='True'><Setter TargetName='Face' Property='BorderBrush' Value='#EEE6FF'/><Setter TargetName='Face' Property='BorderThickness' Value='2'/></Trigger><Trigger Property='IsEnabled' Value='False'><Setter TargetName='Face' Property='Opacity' Value='0.4'/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter>
 </Style>
 <Style x:Key='PrimaryButton' TargetType='Button' BasedOn='{StaticResource Button}'><Setter Property='Background' Value='#B69AFF'/><Setter Property='Foreground' Value='#1B122F'/><Setter Property='BorderBrush' Value='#C6B0FF'/></Style>
 <Style x:Key='CaptionButton' TargetType='Button' BasedOn='{StaticResource Button}'><Setter Property='Background' Value='Transparent'/><Setter Property='BorderThickness' Value='0'/><Setter Property='Padding' Value='8'/></Style>
 <Style TargetType='TextBox'><Setter Property='Background' Value='#0E1421'/><Setter Property='Foreground' Value='#D7E0F1'/><Setter Property='BorderBrush' Value='#36435D'/><Setter Property='CaretBrush' Value='#CBB7FF'/><Setter Property='SelectionBrush' Value='#7954B4'/><Setter Property='BorderThickness' Value='1'/></Style>
 <Style TargetType='ScrollBar'><Setter Property='Width' Value='8'/><Setter Property='Background' Value='#111827'/><Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ScrollBar'><Track x:Name='PART_Track' IsDirectionReversed='True'><Track.Thumb><Thumb><Thumb.Template><ControlTemplate TargetType='Thumb'><Border Background='#39425A' CornerRadius='3' Width='5' HorizontalAlignment='Center'/></ControlTemplate></Thumb.Template></Thumb></Track.Thumb></Track></ControlTemplate></Setter.Value></Setter></Style>
 <Style TargetType='CheckBox'><Setter Property='Foreground' Value='#D7E0F1'/><Setter Property='Template'><Setter.Value><ControlTemplate TargetType='CheckBox'><StackPanel Orientation='Horizontal'><Border x:Name='Box' Width='20' Height='20' BorderBrush='#6C7792' BorderThickness='1' CornerRadius='4' Background='#151D2C'><TextBlock x:Name='Mark' Text='&#x2713;' Foreground='#201335' FontWeight='Bold' HorizontalAlignment='Center' Visibility='Hidden'/></Border><ContentPresenter Margin='8,0,0,0'/></StackPanel><ControlTemplate.Triggers><Trigger Property='IsChecked' Value='True'><Setter TargetName='Box' Property='Background' Value='#B69AFF'/><Setter TargetName='Mark' Property='Visibility' Value='Visible'/></Trigger><Trigger Property='IsKeyboardFocused' Value='True'><Setter TargetName='Box' Property='BorderBrush' Value='White'/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
 <Style TargetType='ComboBoxItem'><Setter Property='Foreground' Value='#D7E0F1'/><Setter Property='Background' Value='#171E2E'/><Setter Property='Padding' Value='10,8'/><Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ComboBoxItem'><Border x:Name='Choice' Background='{TemplateBinding Background}' Padding='{TemplateBinding Padding}'><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property='IsHighlighted' Value='True'><Setter TargetName='Choice' Property='Background' Value='#403056'/></Trigger><Trigger Property='IsSelected' Value='True'><Setter TargetName='Choice' Property='Background' Value='#302543'/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
 <Style TargetType='ComboBox'><Setter Property='Foreground' Value='#D7E0F1'/><Setter Property='Background' Value='#1B2334'/><Setter Property='BorderBrush' Value='#3F4A64'/><Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ComboBox'><Grid><ToggleButton Focusable='False' IsChecked='{Binding IsDropDownOpen,Mode=TwoWay,RelativeSource={RelativeSource TemplatedParent}}'><ToggleButton.Template><ControlTemplate TargetType='ToggleButton'><Border Background='#1B2334' BorderBrush='#3F4A64' BorderThickness='1' CornerRadius='6'><TextBlock Text='&#x2304;' Foreground='#CBB7FF' HorizontalAlignment='Right' VerticalAlignment='Center' Margin='0,0,12,0'/></Border></ControlTemplate></ToggleButton.Template></ToggleButton><ContentPresenter Margin='12,5,35,5' VerticalAlignment='Center' IsHitTestVisible='False' Content='{TemplateBinding SelectionBoxItem}' ContentTemplate='{TemplateBinding SelectionBoxItemTemplate}' TextElement.Foreground='#D7E0F1'/><Popup x:Name='PART_Popup' Placement='Bottom' IsOpen='{TemplateBinding IsDropDownOpen}' AllowsTransparency='True' Focusable='False'><Border Background='#171E2E' BorderBrush='#766091' BorderThickness='1' CornerRadius='5' MinWidth='{Binding ActualWidth,RelativeSource={RelativeSource TemplatedParent}}' MaxHeight='320'><ScrollViewer CanContentScroll='True'><ItemsPresenter/></ScrollViewer></Border></Popup></Grid><ControlTemplate.Triggers><Trigger Property='IsEnabled' Value='False'><Setter Property='Opacity' Value='0.45'/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
</ResourceDictionary>";
 }
}
