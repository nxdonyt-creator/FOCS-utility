﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Management.Automation;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace KKxtti {
 public sealed class ControlItem {
  public string Id,Name,Group,Description,Note,State,Risk,Source,Evidence;
  public bool RequiresAdmin,Supported,Selected;
 }
 public sealed class ManagedApp {
  public string Name,Package,Identity,Group,Description;
  public bool Protected,Suggested,Selected;
 }
 public sealed partial class Dashboard {
  readonly List<ControlItem> controls=new List<ControlItem>();
  readonly List<ManagedApp> managedApps=new List<ManagedApp>();
  StackPanel controlList,managedList;
  TextBox controlSearch,managedSearch;
  TextBlock controlSummary,managedSummary,selectionSummary;
  Button uninstall,applySelected,clearSelected;
  string controlCategory="All",appCategory="Removable";
  bool controlsLoaded;
  readonly Dictionary<string,Button> controlFilters=new Dictionary<string,Button>();
  readonly Dictionary<string,Button> appFilters=new Dictionary<string,Button>();

  void BuildSwitchboard() {
   var page=Page("Performance");
   BuildRegistryReview(page);
   BuildProfileTools(page);
   page.Children.Add(Columns(new UIElement[]{
    Preset("01", "Gaming essentials", "Game Mode on. Windows game recording off.", "Review 2 settings", new[]{"game-mode","no-capture"}),
    Preset("02", "Quiet Windows", "Fewer tips, suggestions and personalized promotions.", "Review 5 settings", new[]{"no-ads","no-tailored","no-tips","no-welcome","no-settings-suggestions"}),
    Preset("03", "Clean desktop", "Visible file extensions, compact Explorer, simpler taskbar.", "Review 4 settings", new[]{"extensions","compact","no-search","no-taskview"})
   }));
   page.Children.Add(Gap(22));
   page.Children.Add(Text("Your switches. Your setup.",21,null,true));page.Children.Add(Gap(7));
   controlSummary=Text("Reading your Windows preferences…",12,"#A2ABC1");page.Children.Add(controlSummary);
   page.Children.Add(Gap(13));
   page.Children.Add(Buttons(Btn("Edge debloat preset",()=>ReviewPreset("Edge debloat",new[]{"edge-startup","edge-background","edge-shopping","edge-rewards","edge-personalization","edge-default-prompt","edge-promotions","edge-games-menu"})),Btn("Brave debloat preset",()=>ReviewPreset("Brave debloat",new[]{"brave-rewards","brave-wallet","brave-vpn","brave-ai","brave-news","brave-stats","brave-p3a","brave-discovery"})),Btn("Reduce desktop animations",()=>ReviewPreset("Reduce desktop visual effects",new[]{"no-transparency","no-animation","no-taskbar-animation","no-selection-fade","no-icon-shadow"}))));
   controlSearch=new TextBox{Height=38,Padding=new Thickness(12,8,12,8),ToolTip="Find a setting"};AutomationProperties.SetName(controlSearch,"Find a setting");
   controlSearch.TextChanged+=(s,e)=>RenderControls();
   page.Children.Add(Columns(new UIElement[]{SearchField(controlSearch,"Search settings…"),Btn("Refresh",()=>LoadControls()),Btn("Undo latest change",()=>UndoLatest(),true)},3,1,1.4));
   page.Children.Add(FilterBar(new[]{"All","Gaming","Privacy","Desktop","Browsers","Network","System"},controlFilters,controlCategory,name=>{controlCategory=name;RenderControls();}));
   applySelected=Btn("Review selected controls",()=>ReviewSelectedControls(),true);clearSelected=Btn("Clear selection",()=>{foreach(var c in controls)c.Selected=false;RenderControls();});
   page.Children.Add(Buttons(applySelected,clearSelected));
   controlList=new StackPanel();page.Children.Add(controlList);page.Children.Add(Gap(16));
   page.Children.Add(Columns(new UIElement[]{
    InfoCard("Power plan", "Compare plans with your exact previous plan saved for undo.", "EXPERIMENT", Btn("Try Balanced",()=>Action("Balanced power plan","Set-TestPowerPlan",false,"1")),Btn("High performance",()=>Action("High performance plan","Set-TestPowerPlan",false,"2")),Btn("Undo plan",()=>Action("Restore power plan","Undo-Power"))),
    InfoCard("NVIDIA profiles", "Tune driver settings per game. Export profiles before changing them.", "DRIVER TOOLS", Btn("Profile Inspector",()=>Action("Open Profile Inspector","Open-Inspector")),Btn("Export driver",()=>Action("Export NVIDIA driver","Export-DisplayDrivers",true)))
   }));
  }
  Border Preset(string number,string title,string description,string label,string[] ids) {
   var detail=Text(description,12,"#A2ABC1");detail.MinHeight=34;
   return Card(Stack(Label(number+"  /  PRESET"),Gap(12),Text(title,18,null,true),Gap(8),detail,Buttons(Btn(label,()=>ReviewPreset(title,ids),true))),18);
  }
  Grid SearchField(TextBox box,string placeholder) {
   var grid=new Grid();grid.Children.Add(box);var hint=Text(placeholder,12,"#8895B0");hint.Margin=new Thickness(13,0,0,0);hint.VerticalAlignment=VerticalAlignment.Center;hint.IsHitTestVisible=false;grid.Children.Add(hint);
   box.TextChanged+=(s,e)=>hint.Visibility=String.IsNullOrEmpty(box.Text)?Visibility.Visible:Visibility.Collapsed;return grid;
  }
  WrapPanel FilterBar(string[] names,Dictionary<string,Button> dictionary,string selected,Action<string> action) {
   var panel=new WrapPanel{Margin=new Thickness(0,12,0,13)};
   foreach(string name in names) {var b=Btn(name,()=>{foreach(var pair in dictionary)pair.Value.Background=pair.Key==name?Hex("#38294F"):Hex("#1B2334");action(name);});b.Margin=new Thickness(0,0,7,5);b.Padding=new Thickness(14,8,14,8);b.Background=Hex(name==selected?"#38294F":"#1B2334");dictionary.Add(name,b);panel.Children.Add(b);}
   return panel;
  }
  void LoadControls() {if(busy)return;Work("Read switch states","Get-ControlStates",r=>{ReadControls(r);RenderControls();});}
  void ReadControls(Collection<PSObject> result) {
   var selected=new HashSet<string>(controls.Where(c=>c.Selected).Select(c=>c.Id));
   controls.Clear();foreach(var r in result)controls.Add(new ControlItem{Id=Value(r,"Id"),Name=Value(r,"Name"),Group=Value(r,"Group"),Description=Value(r,"Description"),Note=Value(r,"Note"),State=Value(r,"State"),Risk=Value(r,"Risk"),Source=Value(r,"Source"),Evidence=Value(r,"Evidence"),RequiresAdmin=Boolean.Parse(Value(r,"RequiresAdmin","False")),Supported=Boolean.Parse(Value(r,"Supported","False")),Selected=selected.Contains(Value(r,"Id"))});controlsLoaded=true;
  }
  void RenderControls() {
   if(controlList==null)return;controlList.Children.Clear();
   controlSummary.Text=controlsLoaded?controls.Count+" controls  ·  "+controls.Count(c=>c.Supported)+" eligible by Windows edition/build  ·  "+controls.Count(c=>c.Selected)+" selected  ·  Saved configuration; benefit must be measured":"Use Refresh to read your Windows preferences.";
   if(applySelected!=null){applySelected.IsEnabled=controls.Any(c=>c.Selected&&c.Supported);applySelected.Content="Review selected ("+controls.Count(c=>c.Selected)+")";}
   var filtered=controls.Where(c=>(controlCategory=="All"||c.Group==controlCategory)&&(c.Name+" "+c.Description).IndexOf(controlSearch.Text,StringComparison.OrdinalIgnoreCase)>=0).ToList();
   for(int i=0;i<filtered.Count;i+=2) {
    UIElement left=SwitchCard(filtered[i]);UIElement right=i+1<filtered.Count?SwitchCard(filtered[i+1]):new Border();
    var row=Columns(new[]{left,right});row.Margin=new Thickness(0,0,0,10);controlList.Children.Add(row);
   }
   if(controlsLoaded&&filtered.Count==0)controlList.Children.Add(Card(Text("No settings match this search.",14,"#A2ABC1")));
  }
  Border SwitchCard(ControlItem item) {
   var toggle=new ToggleButton {Width=48,Height=26,IsChecked=item.State=="On",IsEnabled=item.Supported,Cursor=Cursors.Hand,Style=(Style)XamlReader.Parse(SwitchStyle)};
   AutomationProperties.SetName(toggle,item.Name);toggle.ToolTip="Apply "+item.Name+". Undo saves your previous values.";
   var title=Text(item.Name,14,null,true);title.Margin=new Thickness(0,0,14,0);
   var head=new DockPanel();DockPanel.SetDock(toggle,Dock.Right);head.Children.Add(toggle);head.Children.Add(title);
   toggle.Click+=(s,e)=>{bool enabled=toggle.IsChecked==true;toggle.IsChecked=item.State=="On";if(busy)return;ReviewControlChange(new[]{item},enabled,item.Name);};
   var details=Btn("Details",()=>Notice(item.Name,item.Description+"\n\n"+item.Note+"\n\n"+item.Risk+"  /  "+item.Evidence+"\n"+item.Source+"\n\nUndo restores previous registry values. It cannot recover data deleted by Windows or an app. On / Off means saved configuration, not a verified performance gain."));details.Padding=new Thickness(8,4,8,4);details.FontSize=10;
   var source=Btn("Source",()=>OpenUri(item.Source));source.Padding=new Thickness(8,4,8,4);source.FontSize=10;
   var selection=new CheckBox{Content="Select",IsChecked=item.Selected,IsEnabled=item.Supported,Foreground=muted,FontSize=11,VerticalAlignment=VerticalAlignment.Center,HorizontalAlignment=HorizontalAlignment.Left};AutomationProperties.SetName(selection,"Select "+item.Name);
   selection.Checked+=(s,e)=>{item.Selected=true;UpdateControlSelection();};selection.Unchecked+=(s,e)=>{item.Selected=false;UpdateControlSelection();};
   var foot=new DockPanel();var detailButtons=new StackPanel{Orientation=Orientation.Horizontal};detailButtons.Children.Add(source);detailButtons.Children.Add(details);DockPanel.SetDock(detailButtons,Dock.Right);foot.Children.Add(detailButtons);foot.Children.Add(selection);
   var desc=Text(item.Description,12,"#A2ABC1");desc.MinHeight=33;
   return Card(Stack(head,Gap(8),Text(item.State+"  ·  "+item.Risk+(item.RequiresAdmin?"  ·  Admin":""),10,item.Supported?"#C5B3E8":"#FFC79F"),Gap(8),desc,Gap(9),foot),16);
  }
  bool Review(string title,string message,string[] lines,string label) {
   var panel=Stack(Pill("REVIEW"),Gap(14),Text(title,23,null,true),Gap(10),Text(message,13,"#BAC4DA"),Gap(15));
   foreach(string line in lines)panel.Children.Add(new Border{Padding=new Thickness(12,8,12,8),Margin=new Thickness(0,0,0,5),Background=Hex("#0E1421"),CornerRadius=new CornerRadius(5),Child=Text(line,13)});
   var dialog=Dialog(panel);bool accepted=false;
   panel.Children.Add(Buttons(Btn(label,()=>{accepted=true;dialog.Close();},true),Btn("Cancel",()=>dialog.Close())));dialog.ShowDialog();return accepted;
  }
  void ReviewPreset(string title,string[] ids) {
   if(busy)return;if(!controlsLoaded){LoadControls();return;}
   var selected=controls.Where(c=>ids.Contains(c.Id)).ToArray();
   ReviewControlChange(selected,true,title);
  }
  void UpdateControlSelection(){if(applySelected==null)return;int count=controls.Count(c=>c.Selected);applySelected.IsEnabled=count>0;applySelected.Content="Review selected ("+count+")";controlSummary.Text=controls.Count+" controls  ·  "+controls.Count(c=>c.Supported)+" eligible by Windows edition/build  ·  "+count+" selected  ·  Saved configuration; benefit must be measured";}
  void ReviewSelectedControls(){if(busy)return;ReviewControlChange(controls.Where(c=>c.Selected&&c.Supported).ToArray(),true,"Selected controls");}
  void ReviewControlChange(ControlItem[] items,bool enabled,string title){
   if(readOnlyPreview){Notice("Read-only preview","Settings changes are disabled in this testing session.");return;}
   if(items.Length==0||busy)return;if(items.Any(c=>!c.Supported)){Notice("Unsupported setting","This selection contains a setting unavailable on this edition/build. Review its details.");return;}
   if(items.Any(c=>c.RequiresAdmin)&&!RequireAdmin())return;
   if(!Review(title,"Review every selected change. Your original values are saved together. Off restores an explicit opposite preference or removes the override; Undo restores the original registry values. Deleted data, including Recall snapshots, cannot be recovered by Undo. System policies may need a restart.",items.Select(c=>c.Name+"  →  "+(enabled?"On":"Off")+"\n"+c.Risk+" / "+c.Note).ToArray(),"Apply reviewed changes"))return;
   if(items.Any(c=>c.Risk=="High impact")&&!ConfirmOperation("This change can break IPv6-dependent Windows features, VPNs and connectivity. It is excluded from presets. Use it only for a diagnosed issue and retain a working recovery path.","CHANGE",""))return;
   ApplyControls(items.Select(c=>c.Id).ToArray(),enabled,title);
  }
  async void ApplyControls(string[] ids,bool enabled,string title,string undoId=null) {
   if(busy)return;SetBusy(true,title+"…");controlList.IsEnabled=false;Log(title+" started.");
   try {
    var vars=new Dictionary<string,object>{{"ControlIds",ids},{"ControlEnabled",enabled},{"UndoId",undoId}};
    var result=await Task.Run(()=>Backend.Run(root,undoId==null?"Set-ControlSettings -Ids $ControlIds -Enabled $ControlEnabled":"Undo-ControlSettings -Id $UndoId",new ActionBridge(this),vars));
    string outcome=result.Count>0?Value(result[0],"Status"):"Completed";Log(title+": "+outcome+". Saved in Backups.");status.Text=title+" / "+outcome;
   } catch(Exception ex) {Log("ERROR: "+ex.Message);Notice("Change could not complete",ex.Message);status.Text=title+" / Could not complete";}
   {
    try{var states=await Task.Run(()=>Backend.Run(root,"Get-ControlStates",new ActionBridge(this)));ReadControls(states);RenderControls();}catch(Exception ex){controlsLoaded=false;controls.Clear();RenderControls();Log("Could not refresh: "+ex.Message);}
    controlList.IsEnabled=true;SetBusy(false,status.Text);RefreshBackupCount();if(currentPage=="Backups")RefreshBackups();
   }
  }
  void UndoLatest() {
   if(busy)return;Work("Read latest saved change","Get-ControlHistory | Where-Object Status -eq 'Applied' | Select-Object -First 1",r=>{
    if(r.Count==0){Notice("Nothing to undo yet","Change a switch or apply a preset to create a saved state.");return;}
    string id=Value(r[0],"Id");Dispatcher.BeginInvoke(new Action(()=>UndoSettings(id)));
   });
  }
  void UndoSettings(string id) {
   if(busy)return;
   if(Review("Restore previous settings","Restores the registry values saved before this change. Deleted data cannot be recovered. If a newer change affects the same setting, KKxtti stops before overwriting it.",new[]{id},"Restore settings"))ApplyControls(new string[0],false,"Restore settings",id);
  }
  void BuildAppManager() {
   var page=Page("Debloat");
   page.Children.Add(Columns(new UIElement[]{Card(Stack(Pill("WINDOWS APPS"),Gap(10),Text("Keep what you use.",25,null,true),Gap(7),Text("A real inventory for your Windows account. Choose apps individually or start with the extras preset.",13,"#A2ABC1")),20),Card(Stack(Label("QUICK SELECTION"),Gap(10),Text("Start with optional extras",16,null,true),Gap(7),Text("Leaves your photos, notes, editors and gaming tools unselected.",12,"#A2ABC1"),Buttons(Btn("Select extras",()=>SelectExtras(),true),Btn("Clear",()=>ClearManagedSelection()))),20)},1.2,1));
   page.Children.Add(Gap(18));managedSummary=Text("Reading installed Windows apps…",13,"#A2ABC1");page.Children.Add(managedSummary);page.Children.Add(Gap(10));
   managedSearch=new TextBox{Height=39,Padding=new Thickness(12,8,12,8),ToolTip="Search installed Windows apps"};AutomationProperties.SetName(managedSearch,"Search installed Windows apps");managedSearch.TextChanged+=(s,e)=>RenderManagedApps();
   page.Children.Add(Columns(new UIElement[]{SearchField(managedSearch,"Search installed Windows apps…"),Btn("Refresh inventory",()=>LoadManagedApps())},4,1));
   page.Children.Add(FilterBar(new[]{"Removable","Extras","Media","Tools","Connectivity","Gaming","Protected"},appFilters,appCategory,name=>{appCategory=name;RenderManagedApps();}));
   selectionSummary=Text("Nothing selected",13,"#C4B0EF");uninstall=Btn("Review removal",()=>ReviewRemoval(),true);uninstall.IsEnabled=false;
   var bar=new DockPanel();var actionButtons=Buttons(uninstall,Btn("Select visible",()=>SelectManagedVisible()));actionButtons.Margin=new Thickness(0);DockPanel.SetDock(actionButtons,Dock.Right);bar.Children.Add(actionButtons);selectionSummary.VerticalAlignment=VerticalAlignment.Center;bar.Children.Add(selectionSummary);page.Children.Add(Card(bar,14));page.Children.Add(Gap(10));
   managedList=new StackPanel();page.Children.Add(Card(new ScrollViewer{Content=managedList,MaxHeight=385,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled},4));page.Children.Add(Gap(10));
   page.Children.Add(Text("Removal affects this account. Saved lists record what was removed; they do not back up app data. Protected items show dependencies and apps outside the reviewed catalog.",11,"#929EB8"));
   page.Children.Add(Buttons(Btn("Clean old temporary files",()=>Action("Old temporary-file cleanup","Clear-OldUserTemp")),Btn("Removal records",()=>OpenState())));
  }
  void LoadManagedApps() {
   if(busy)return;var selected=new HashSet<string>(managedApps.Where(a=>a.Selected).Select(a=>a.Package));
   Work("Read installed Windows apps","Get-ManagedApps | Sort-Object Name",r=>{managedApps.Clear();foreach(var p in r){bool protect=Boolean.Parse(Value(p,"Protected","True"));managedApps.Add(new ManagedApp{Name=Value(p,"Name"),Package=Value(p,"Package"),Identity=Value(p,"Identity"),Description=Value(p,"Description"),Group=Value(p,"Group"),Protected=protect,Suggested=Boolean.Parse(Value(p,"Suggested","False")),Selected=!protect&&selected.Contains(Value(p,"Package"))});}loadedApps=true;RenderManagedApps();});
  }
  IEnumerable<ManagedApp> VisibleManagedApps() {return managedApps.Where(a=>(appCategory=="Removable"?!a.Protected:a.Group==appCategory)&&(a.Name+" "+a.Identity+" "+a.Description).IndexOf(managedSearch.Text,StringComparison.OrdinalIgnoreCase)>=0);}
  void RenderManagedApps() {
   if(managedList==null)return;managedList.Children.Clear();var visible=VisibleManagedApps().ToList();
   managedSummary.Text=loadedApps?managedApps.Count+" installed  ·  "+managedApps.Count(a=>!a.Protected)+" removable  ·  "+managedApps.Count(a=>a.Protected)+" protected  ·  "+visible.Count+" in this view":"Use Refresh inventory to load your apps.";
   foreach(var a in visible) {
    var cb=new CheckBox{IsChecked=a.Selected,IsEnabled=!a.Protected,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(3,0,10,0),Opacity=a.Protected?.35:1};AutomationProperties.SetName(cb,"Select "+a.Name);
    cb.Checked+=(s,e)=>{a.Selected=true;UpdateManagedSelection();};cb.Unchecked+=(s,e)=>{a.Selected=false;UpdateManagedSelection();};
    var glyph=Text(a.Name.Substring(0,1).ToUpperInvariant(),19,"#D6C3FF",true);glyph.HorizontalAlignment=HorizontalAlignment.Center;glyph.VerticalAlignment=VerticalAlignment.Center;
    var icon=new Border{Background=Hex("#302543"),CornerRadius=new CornerRadius(9),Width=40,Height=40,Child=glyph,Margin=new Thickness(0,0,13,0),VerticalAlignment=VerticalAlignment.Center};
    var badge=Pill(a.Group,a.Protected?"#A2ABC1":"#CDBAFF",a.Protected?"#232B3B":"#302543");badge.VerticalAlignment=VerticalAlignment.Center;badge.Margin=new Thickness(12,0,3,0);
    var row=new DockPanel();DockPanel.SetDock(cb,Dock.Left);row.Children.Add(cb);DockPanel.SetDock(icon,Dock.Left);row.Children.Add(icon);DockPanel.SetDock(badge,Dock.Right);row.Children.Add(badge);
    var text=Stack(Text(a.Name,14,null,true),Gap(4),Text(a.Description,11,"#A2ABC1"));text.ToolTip=a.Identity+"\n"+a.Package;row.Children.Add(text);
    managedList.Children.Add(new Border{Child=row,Padding=new Thickness(13,12,13,12),BorderBrush=line,BorderThickness=new Thickness(0,0,0,1)});
   }
   if(visible.Count==0)managedList.Children.Add(new Border{Padding=new Thickness(25),Child=Text(loadedApps?"No apps match this view. Try another category or clear your search.":"Loading your installed apps…",14,"#A2ABC1")});
   UpdateManagedSelection();
  }
  void UpdateManagedSelection() {int count=managedApps.Count(a=>a.Selected&&!a.Protected);selectionSummary.Text=count==0?"Choose the apps you no longer use":count+" app"+(count==1?"":"s")+" selected across all categories";uninstall.Content=count==0?"Review removal":"Review removal ("+count+")";uninstall.IsEnabled=count>0;}
  void SelectExtras() {foreach(var a in managedApps)a.Selected=a.Suggested&&!a.Protected;RenderManagedApps();}
  void ClearManagedSelection() {foreach(var a in managedApps)a.Selected=false;RenderManagedApps();}
  void SelectManagedVisible() {foreach(var a in VisibleManagedApps())if(!a.Protected)a.Selected=true;RenderManagedApps();}
  void ReviewRemoval() {
   if(busy)return;var chosen=managedApps.Where(a=>a.Selected&&!a.Protected).ToArray();if(chosen.Length==0)return;
   if(!Review("Remove "+chosen.Length+" Windows app"+(chosen.Length==1?"":"s")+"?","Close these apps and save your work first. App settings and unsynced data may be lost. There is no automatic undo. A removal record is saved.",chosen.Select(a=>a.Name+" — "+a.Description).ToArray(),"Uninstall selected"))return;
   Work("Uninstall selected Windows apps","Remove-ManagedApps -Packages $AppPackages",r=>{
    var failed=r.Where(p=>Value(p,"Status")=="Failed").ToArray();int removed=r.Count-failed.Length;
    Log(removed+" apps removed; "+failed.Length+" failed.");foreach(var p in r)Log(Value(p,"Name")+": "+Value(p,"Status")+(Value(p,"Status")=="Failed"?" / "+Value(p,"Error"):""));
    Notice(failed.Length>0?"Some apps could not be removed":"Removal completed",removed+" removed. "+failed.Length+" failed."+(failed.Length>0?"\n\n"+String.Join("\n",failed.Select(p=>Value(p,"Name")+": "+Value(p,"Error"))):"\n\nThe inventory will refresh now."));
    loadedApps=false;Dispatcher.BeginInvoke(new Action(()=>LoadManagedApps()));
   },null,new Dictionary<string,object>{{"AppPackages",chosen.Select(a=>a.Package).ToArray()}});
  }
  const string SwitchStyle=@"<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='ToggleButton'><Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ToggleButton'><Border x:Name='Track' Background='#38435C' CornerRadius='13' BorderThickness='1' BorderBrush='#53617D'><Ellipse x:Name='Thumb' Width='18' Height='18' Fill='#CCD4E5' HorizontalAlignment='Left' Margin='3,0,3,0'/></Border><ControlTemplate.Triggers><Trigger Property='IsChecked' Value='True'><Setter TargetName='Track' Property='Background' Value='#AE86F5'/><Setter TargetName='Track' Property='BorderBrush' Value='#CBB0FF'/><Setter TargetName='Thumb' Property='HorizontalAlignment' Value='Right'/><Setter TargetName='Thumb' Property='Fill' Value='White'/></Trigger><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='Track' Property='BorderBrush' Value='White'/></Trigger><Trigger Property='IsKeyboardFocused' Value='True'><Setter TargetName='Track' Property='BorderBrush' Value='White'/><Setter TargetName='Track' Property='BorderThickness' Value='2'/></Trigger><Trigger Property='IsEnabled' Value='False'><Setter TargetName='Track' Property='Opacity' Value='0.45'/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>";
 }
}
