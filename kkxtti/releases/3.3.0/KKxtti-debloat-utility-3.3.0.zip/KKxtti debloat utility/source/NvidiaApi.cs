using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace KKxtti {
 // DWORD-only DRS bridge. Layouts/IDs are from NVIDIA's MIT-licensed NVAPI
 // headers (pack 4, 2048 UTF-16 chars, 4100-byte value unions). See SOURCES 3.2.
 public sealed class NvidiaValue {
  public bool Found,Local; public uint Value,Location; public string Profile;
 }
 public sealed class NvidiaSession : IDisposable {
  IntPtr module,session,profile; bool initialized; Query query;
  public string ProfileName {get;private set;}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr LoadLibraryEx(string name,IntPtr file,uint flags);
  [DllImport("kernel32.dll",CharSet=CharSet.Ansi)] static extern IntPtr GetProcAddress(IntPtr module,string name);
  [DllImport("kernel32.dll")] static extern bool FreeLibrary(IntPtr module);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr Query(uint id);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int NoArgs();
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Create(out IntPtr session);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int SessionCall(IntPtr session);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Find(IntPtr session,IntPtr app,out IntPtr profile,IntPtr application);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int ProfileCall(IntPtr session,IntPtr profile,IntPtr data);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Read(IntPtr session,IntPtr profile,uint id,IntPtr data);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Delete(IntPtr session,IntPtr profile,uint id);
  T Fn<T>(uint id) where T:class {IntPtr p=query(id);if(p==IntPtr.Zero)throw new InvalidOperationException("The installed NVIDIA driver does not expose the required DRS API.");return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;}
  static void Ok(int result){if(result!=0)throw new InvalidOperationException("NVIDIA profile operation failed (NVAPI "+result+"). No success is assumed; check the saved record.");}
  public const int SettingSize=12320,ApplicationSize=12296,ProfileSize=4116;
  static IntPtr Buffer(int size,bool version){var p=Marshal.AllocHGlobal(size);Marshal.Copy(new byte[size],0,p,size);if(version)Marshal.WriteInt32(p,size|(1<<16));return p;}
  public static bool Allowed(uint id){return id==0x1057EB71||id==0x00CE2691||id==0x00A879CF||id==0x10835002;}
  public NvidiaSession(string application) {
   if(application!="fortniteclient-win64-shipping.exe"&&application!="rainbowsix.exe"&&application!="rainbowsix_dx12.exe")throw new ArgumentException("Unsupported game application.");
   try {
    module=LoadLibraryEx(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"nvapi64.dll"),IntPtr.Zero,0x800);
    if(module==IntPtr.Zero)throw new InvalidOperationException("The installed NVIDIA x64 driver is unavailable. Install the official driver first.");
    IntPtr entry=GetProcAddress(module,"nvapi_QueryInterface");if(entry==IntPtr.Zero)throw new InvalidOperationException("NVIDIA driver interface is unavailable.");
    query=(Query)Marshal.GetDelegateForFunctionPointer(entry,typeof(Query));Ok(Fn<NoArgs>(0x0150e828)());initialized=true;
    Ok(Fn<Create>(0x0694d52e)(out session));Reload();
    IntPtr app=Buffer(4096,false),record=Buffer(ApplicationSize,true);
    try {byte[] text=Encoding.Unicode.GetBytes(application);Marshal.Copy(text,0,app,text.Length);int result=Fn<Find>(0xeee566b2)(session,app,out profile,record);if(result==-166||result==-163)throw new InvalidOperationException("No existing NVIDIA game profile was found. Update the official driver or use NVIDIA Control Panel to add the game, then refresh.");Ok(result);}finally{Marshal.FreeHGlobal(app);Marshal.FreeHGlobal(record);}
    if(profile==IntPtr.Zero)throw new InvalidOperationException("NVIDIA returned no game profile.");
    IntPtr info=Buffer(ProfileSize,true);try{Ok(Fn<ProfileCall>(0x61cd6fd6)(session,profile,info));ProfileName=Marshal.PtrToStringUni(IntPtr.Add(info,4),2048).TrimEnd('\0');}finally{Marshal.FreeHGlobal(info);}
   }catch{Dispose();throw;}
  }
  public void Reload(){Ok(Fn<SessionCall>(0x375dbd6b)(session));}
  public NvidiaValue Get(uint id) {
   if(!Allowed(id))throw new ArgumentException("Unsupported NVIDIA setting.");IntPtr data=Buffer(SettingSize,true);
   try {int r=Fn<Read>(0x73bf8338)(session,profile,id,data);if(r==-160)return new NvidiaValue{Found=false,Local=false,Profile=ProfileName};Ok(r);
    if(Marshal.ReadInt32(data,4104)!=0)throw new InvalidOperationException("Expected a DWORD NVIDIA setting.");uint location=unchecked((uint)Marshal.ReadInt32(data,4108));
    return new NvidiaValue{Found=true,Local=location==0&&Marshal.ReadInt32(data,4112)==0,Value=unchecked((uint)Marshal.ReadInt32(data,8220)),Location=location,Profile=ProfileName};
   }finally{Marshal.FreeHGlobal(data);}
  }
  public void Set(uint id,uint value) {
   if(!Allowed(id))throw new ArgumentException("Unsupported NVIDIA setting.");IntPtr data=Buffer(SettingSize,true);
   try{Marshal.WriteInt32(data,4100,unchecked((int)id));Marshal.WriteInt32(data,8220,unchecked((int)value));Ok(Fn<ProfileCall>(0x577dd202)(session,profile,data));}finally{Marshal.FreeHGlobal(data);}
  }
  public void Remove(uint id){if(!Allowed(id))throw new ArgumentException("Unsupported NVIDIA setting.");Ok(Fn<Delete>(0xe4a26362)(session,profile,id));}
  public void Save(){Ok(Fn<SessionCall>(0xfcbc7e14)(session));}
  public void Dispose(){if(session!=IntPtr.Zero){try{Fn<SessionCall>(0xdad9cff8)(session);}catch{}session=IntPtr.Zero;}if(initialized){try{Fn<NoArgs>(0xd22bdd7e)();}catch{}initialized=false;}if(module!=IntPtr.Zero){FreeLibrary(module);module=IntPtr.Zero;}}
 }
 public static class PowerRead {
  [DllImport("powrprof.dll")] static extern uint PowerReadACValueIndex(IntPtr root,ref Guid scheme,ref Guid subgroup,ref Guid setting,out uint value);
  public static uint Read(string scheme,string subgroup,string setting){Guid a=new Guid(scheme),b=new Guid(subgroup),c=new Guid(setting);uint value;uint code=PowerReadACValueIndex(IntPtr.Zero,ref a,ref b,ref c,out value);if(code!=0)throw new InvalidOperationException("Power setting is unavailable (Windows "+code+").");return value;}
 }
}
