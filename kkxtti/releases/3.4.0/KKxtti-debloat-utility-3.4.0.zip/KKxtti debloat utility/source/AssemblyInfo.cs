﻿using System.Reflection;
[assembly: AssemblyTitle("KKxtti debloat utility")]
[assembly: AssemblyDescription("Reviewed Windows controls, debloat and app installation with a purple interface")]
[assembly: AssemblyProduct("KKxtti debloat utility")]
[assembly: AssemblyVersion("3.4.0.0")]
[assembly: AssemblyFileVersion("3.4.0.0")]
