#requires -Version 5.1
param([string]$OutputPath)
$ErrorActionPreference='Stop'
if(-not $OutputPath){$OutputPath=Join-Path (Split-Path -Parent $PSScriptRoot) 'KKxtti debloat utility.exe'}
$framework=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$compiler=Join-Path $framework 'csc.exe'
$automation=Get-ChildItem -LiteralPath (Join-Path $env:WINDIR 'Microsoft.NET\assembly\GAC_MSIL\System.Management.Automation') -Recurse -Filter System.Management.Automation.dll | Select-Object -First 1 -ExpandProperty FullName
if(-not $automation){throw 'Windows PowerShell 5.1 assembly not found.'}
$references=@('System.dll','System.Web.Extensions.dll','System.Core.dll','System.Xaml.dll',(Join-Path $framework 'Microsoft.VisualBasic.dll'),"$framework\WPF\WindowsBase.dll","$framework\WPF\PresentationCore.dll","$framework\WPF\PresentationFramework.dll",$automation)
$arguments=@('/nologo','/target:winexe','/platform:x64','/optimize+',('/out:'+$OutputPath),('/win32manifest:'+(Join-Path $PSScriptRoot 'app.manifest')))
foreach($reference in $references){$arguments+=('/reference:'+$reference)}
$arguments+='/reference:System.Windows.Forms.dll'
$arguments+='/reference:System.Drawing.dll'
$arguments+=(Join-Path $PSScriptRoot 'Dashboard.cs')
$arguments+=(Join-Path $PSScriptRoot 'AssemblyInfo.cs')
$arguments+=(Join-Path $PSScriptRoot 'ControlCenter.cs')
$arguments+=(Join-Path $PSScriptRoot 'NetworkPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'FrameAnalysis.cs')
$arguments+=(Join-Path $PSScriptRoot 'BenchmarkPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'GamePage.cs')
$arguments+=(Join-Path $PSScriptRoot 'HistoryPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'SystemPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'InstallerPage.cs')
$arguments+=(Join-Path $PSScriptRoot 'NvidiaApi.cs')
$arguments+=(Join-Path $PSScriptRoot 'ProfilePage.cs')
$arguments+=(Join-Path $PSScriptRoot 'PeripheralPage.cs')
& $compiler $arguments
if($LASTEXITCODE -ne 0){throw 'Dashboard compilation failed.'}
